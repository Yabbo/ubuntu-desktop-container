#!/bin/bash
DIR=$(python -c "import os; print(os.path.realpath('$1'))")
"${DIR}"/mm.sh install
sudo mkdir -p /usr/local/bin
sudo rm -f /usr/local/bin/mm
sudo ln -s "${DIR}/mm.sh" /usr/local/bin/mm
mm help
which mm