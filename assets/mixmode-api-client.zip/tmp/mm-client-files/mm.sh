#!/usr/bin/env bash

DIR="$(dirname "$(readlink "$0")")"
export PYTHONWARNINGS="ignore:Unverified HTTPS request"

function print_Default() {
  cat << EOF_HELP_TEXT
--- Mixmode API Client ---
# install dependencies
mm install

# authenticate. the token is stored in api.conf file if successful
mm auth --username username --password password --endpoint endpoint # authenticate and cache the token locally

# refresh the authentication token
mm refresh # update the cached token by extending it's expiration by 7 days

# compile but do not execute a query
mm suggest <query> <O_SENSOR|O_INDICATORS|O_EVENTS> <tz>
mm suggest --pql_query=<query> --search_type=[O_SENSOR|O_INDICATORS|O_EVENTS] --timezone=[tz]

# execute a query and print result to standard out
mm query <query> <O_SENSOR|O_INDICATORS|O_EVENTS> <tz>
mm query --pql_query=<query> --search_type=[O_SENSOR|O_INDICATORS|O_EVENTS] --timezone=[tz]
mm stream <query> <O_SENSOR|O_INDICATORS|O_EVENTS> <tz>
mm stream --pql_query=<query> --search_type=[O_SENSOR|O_INDICATORS|O_EVENTS] --timezone=[tz]

# export a large result set into hourly files
mm export <query> <O_SENSOR|O_INDICATORS|O_EVENTS> <tz> <path>

# export a large result set into hourly files in the background
nohup mm export <query> <O_SENSOR|O_INDICATORS|O_EVENTS> <tz> <path> &

# upload a directory into an smf profile
mm rsync --tenantname 'name of tenant' --profilename 'name of profile' --localpath 'path to files on local file system' --remotepath 'relative path to files in profile' --generate_script true|false whether or not to create __load__.bro script that reads all of the intel files in remote_path --delete true|false whether to delete files on remote that do not exist on local system

# list users
mm users # list users
mm create_users path_to_csv_file.csv # create all users from csv file
mm create_user --username UNAME --password PW --permissions COMMA_SEPERATED_LIST_OF_PERMISSIONS

# list tenants
mm tenants # list tenants

# list sensors
mm sensors # list sensors
mm sensor_config --tenantname X --sensorname Y
mm create_sensor --vlan_tag c_tag --tenantname c_tenant_name --tenantdesc c_tenant_desc --tenantlabel c_tenant_label --sensorname c_sensor_name --sensordesc c_sensor_desc --sensorlabel c_sensor_label --profilename c_profile_name
mm create_sensors path_to_csv_file.csv
mm vlan_import path_to_csv_file.csv

# add a script profile to all sensor profiles, and publish
mm smf_script --profilename c_profile_name

# download a PCAP file
mm ndr --tenantid # --sensorid # --limitbytes # --limitpkts # --query [BPF query]

# import/export user defined rules
mm export_rules --outputfile /path/to/output/file.json
mm import_rules --inputfile /path/to/input/file.json --overwrite [true|false]

# import/export user bookmarks
mm export_bookmarks --outputfile /path/to/output/file.json
mm import_bookmarks --inputfile /path/to/input/file.json --overwrite [true|false]

# upload enrichments
mm upload_enrichments --inputfile /path/to/input/file.csv --enrichment_name <name of existing enrichment>

# incident response workflow (irw)
# assign all security events matching <query> to user <username>
mm irw assign <query> <timezone> <username>

# unassign all security events matching <query> to user <username>
mm irw unassign <query> <timezone>

# mark all events matching <query> as "closed"
mm irw status <query> <timezone> "closed"

# mark all events matching <query> as "open"
mm irw status <query> <timezone> "open"

EOF_HELP_TEXT

}

function ensure_line_exists() {
  grep -qE "$1" $3 >/dev/null 2>&1 && sed "s/$1/$2/" -i $3 || echo "$2" >>$3
}

function random_string() {
  dd status=none bs=18 count=1 if=/dev/urandom | base64 | tr +/ _.
}

function remove_quotes() {
  echo "$1" | sed -e 's/^"//' -e 's/"$//'
}

function update_Config() {
  cat >"${DIR}"/api.conf <<EOF
MIXMODE_ENDPOINT=${MIXMODE_ENDPOINT}
MIXMODE_TOKEN=${MIXMODE_TOKEN}

EOF
}

function install_pip3() {
  which curl || (
    echo "no curl in path"
    exit 1
  )
  curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
  python3 get-pip.py
}
function install_cmd() {
  which python3 || (
    echo "no python in path"
    exit 1
  )
  which pip3 || install_pip3
  pip3 install virtualenv --user
  pushd "${DIR}"/python/client
  rm -rf ./env
  python3 -m virtualenv env
  source ./env/bin/activate
  python setup.py install
  # swagger-codegen will overwrite changes made to the client/requirments.txt and client/setup.py files.
  pip install "certifi>=2017.4.17" "six>=1.10" "python_dateutil>=2.5.3" "setuptools>=21.0.0" "urllib3>=1.26,<2.0.0"
  popd
}
function activate_env() {
  source "${DIR}"/python/client/env/bin/activate
}
function auth_cmd() {
  activate_env
  export MIXMODE_TOKEN=$(python "${DIR}"/python/auth.py "$@" | grep token | awk -F\" '{print $4}')
  while [ $# -gt 0 ]; do
    case $1 in
    --endpoint)
      shift
      export MIXMODE_ENDPOINT=$1
      ;;
    esac
    shift
  done
  update_Config
}
function refresh_cmd() {
  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env
  resp=$(python "${DIR}"/python/refresh.py "$@" | grep token)
  if [[ "$?" != 0 ]]; then
    echo "refresh failed"
    exit 1
  fi

  export MIXMODE_TOKEN=$(echo $resp | awk -F\" '{print $4}')
  if [[ "$?" != 0 ]]; then
    echo "token parse failed"
    exit 1
  fi

  [[ ! -z "$MIXMODE_TOKEN" ]] && update_Config

}
function query_cmd() {
  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env
  if [[ "$@" =~ --pql_query ]]; then
    python "${DIR}"/python/pql.py "$@"
  else
    python "${DIR}"/python/pql.py --pql_query="$1" --search_type="$2" --timezone="$3"
  fi
}
function suggest_cmd() {
  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env
  if [[ "$@" =~ --pql_query ]]; then
    python "${DIR}"/python/suggest.py "$@"
  else
    python "${DIR}"/python/suggest.py --pql_query="$1" --search_type="$2" --timezone="$3"
  fi
}
function tenants_cmd() {
  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env
  python "${DIR}"/python/tenants.py "$@"
}
function smf_script_cmd() {
  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env
  python "${DIR}"/python/smf_script_profile.py "$@"
}
function sensors_cmd() {
  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env
  python "${DIR}"/python/sensors.py "$@"
}
function rules_cmd() {
  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env
  python "${DIR}"/python/rules.py "$@"
}
function sensor_config_cmd() {
  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env
  python "${DIR}"/python/sensor_config.py "$@"
}
function stream_cmd() {
  set -a
  . "${DIR}"/api.conf
  set +a
  curl -G -ks -X GET -H "x-mixmode-api-token: ${MIXMODE_TOKEN}" \
    --data-urlencode "query=${1}" \
    --data-urlencode "timezone=${3}" \
    --data-urlencode "searchType=${2}" \
    "https://${MIXMODE_ENDPOINT}/v1/search/stream"
  echo ""
}
function gql_cmd() {
  set -a
  . "${DIR}"/api.conf
  set +a
  curl -ks -X POST -H "x-mixmode-api-token: ${MIXMODE_TOKEN}" -H "Content-Type: application/json" \
    --data-binary @- \
    "https://${MIXMODE_ENDPOINT}/v1/graphql"
  echo ""
}

function export_cmd() {
  # create output_dir and ensure it's empty
  mkdir -p "${4}" || true
  if [ "$(ls -A $4)" ]; then
    echo "output_dir $4 is not empty, exiting..."
    exit 1
  fi
  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env
  python "${DIR}"/python/export.py "$@"
}

function ndr_cmd() {
  set -a
  . "${DIR}"/api.conf
  set +a

  export MIXMODE_LIMITPKTS=${MIXMODE_LIMITPKTS:-0}
  export MIXMODE_LIMITBYTES=${MIXMODE_LIMITBYTES:-0}

  while [ $# -gt 0 ]; do
    case $1 in
    --limitpkts)
      shift
      export MIXMODE_LIMITPKTS=${1:-0}
      ;;
    --limitbytes)
      shift
      export MIXMODE_LIMITBYTES=${1:-0}
      ;;
    --tenantid)
      shift
      export MIXMODE_TENANTID=$1
      ;;
    --sensorid)
      shift
      export MIXMODE_SENSORID=$1
      ;;
    --query)
      shift
      export MIXMODE_BPF_QUERY=$1
      ;;
    --output)
      shift
      export MIXMODE_NDR_OUT=$1
      ;;
    esac
    shift
  done

  curl -ks -X POST -H "x-mixmode-api-token: ${MIXMODE_TOKEN}" \
    -H "accept: application/json" -H "Content-Type: application/json" \
    "https://${MIXMODE_ENDPOINT}/v1/tenants/${MIXMODE_TENANTID}/smf/sensors/${MIXMODE_SENSORID}/reachback/ndr" \
    -d"{\"description\":\"description\",\"guid\":\"00000000-0000-0000-0000-000000000000\",\"limitbytes\":${MIXMODE_LIMITBYTES},\"limitpkts\":${MIXMODE_LIMITPKTS},\"name\":\"name\",\"rule\":\"${MIXMODE_BPF_QUERY}\"}" \
    -o ${MIXMODE_NDR_OUT}
}
function rsync_cmd() {
  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env
  python "${DIR}"/python/rsync.py "$@"
}
function splunk_cmd() {
  set -a
  . "${DIR}"/api.conf
  set +a
  f="/tmp/$(basename ${0}).splunk.$$"
  while read -r line; do echo "{\"sourcetype\": \"${SPLUNK_SOURCETYPE}\", \"event\": ${line}}"; done >${f}
  curl -ks -X POST \
    --header "Authorization: Splunk ${SPLUNK_KEY}" \
    --header "Content-Type: application/json" \
    --data @"${f}" \
    "${SPLUNK_ENDPOINT}"
  rm -f ${f}
}
function reputation_cmd() {
  curl -ks -X GET --user ${1}:${2} \
    "https://ticloud-aws1-api.reversinglabs.com/api/databrowser/malware_presence/query/md5/${3}?format=json&extended=true"
  #    | python -m json.tool
}
function parse_json_cmd() {
  cmd='import sys, json; o = json.load(sys.stdin);'
  for var in "$@"; do
    if [ "$1" -eq "$1" ] 2>/dev/null; then
      cmd="${cmd} print(json.dumps(o[${var}]));"
    else
      cmd="${cmd} print(json.dumps(o[\"${var}\"]));"
    fi
  done
  python -c "${cmd}"
}
function apply_smf_updates_cmd() {
  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env
  python "${DIR}"/python/apply_smf_updates.py "$@"
}
function reauthenticate_sensors_cmd() {
  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env
  python "${DIR}"/python/reauthenticate_sensors.py "$@"
}
function hotfix_cmd() {
  for PORT in ${1}; do
    echo "Sensor Port: ${PORT}"
    CMD=${2}
    QUIET=-i
    if [[ -n ${3} ]] ; then QUIET=-q ; fi
    SCRIPT=/tmp/hf.$$
    cat >${SCRIPT} <<EOF
      mkdir -p /data/export/selcap/log
      ${CMD} > /data/export/selcap/log/hf.log
EOF
    HASH=$(md5sum ${SCRIPT} | awk '{print $1}')
    curl -s -i -X POST -F "file=@${SCRIPT}" -F "exec=sh" -F "md5=${HASH}" http://localhost:${PORT}/v2/hotfix >/dev/null
    curl -s ${QUIET} -X GET "http://localhost:${PORT}/selcap/log/hf.log"
    cat >${SCRIPT} <<EOF
      rm -rf /data/export/selcap/log
EOF
    HASH=$(md5sum ${SCRIPT} | awk '{print $1}')
    curl -s -i -X POST -F "file=@${SCRIPT}" -F "exec=sh" -F "md5=${HASH}" http://localhost:${PORT}/v2/hotfix >/dev/null
    echo
    rm ${SCRIPT}
  done
}
function copy_to_sensor_cmd() {
  PORTS="${1}"
  FILE="${2}"
  DEST="${3}"
  FILEHASH=$(md5sum ${FILE} | awk '{print $1}')
  for PORT in ${PORTS}; do
    echo "Sensor Port: ${PORT}"
    curl -s -X POST -F "file=@${FILE}" -F "md5=${FILEHASH}" http://localhost:${PORT}/v2/hotfix >/dev/null
  done
  hotfix_cmd "${PORTS}" "mv -f /opt/mixmode/updates/${FILE} ${DEST}/." -q >/dev/null
}
function token_cmd() {
  pushd /tmp
  npm install -g jsonwebtoken
  node <<EOF
    var jwt = require("jsonwebtoken");
    jwt.verify("$1", "$2", function(err,ses) {
        if(err) {console.log(JSON.stringify(err, null, "\t"));} else {console.log(JSON.stringify(ses, null, "\t"));}
    });
EOF
  popd
}
function create_sensors_cmd() {
  cat "$1" | tr -d "\r" | awk 'NF' | (
    IFS=, read -r c_hdr__tag c_hdr__tenant_name c_hdr__tenant_desc c_hdr__tenant_label c_hdr__sensor_name c_hdr__sensor_desc c_hdr__sensor_label c_hdr__profile_name
    while IFS=, read -r c_tag c_tenant_name c_tenant_desc c_tenant_label c_sensor_name c_sensor_desc c_sensor_label c_profile_name; do
      c_tag=$(remove_quotes "$c_tag")
      c_tenant_name=$(remove_quotes "$c_tenant_name")
      c_tenant_desc=$(remove_quotes "$c_tenant_desc")
      c_tenant_label=$(remove_quotes "$c_tenant_label")
      c_sensor_name=$(remove_quotes "$c_sensor_name")
      c_sensor_desc=$(remove_quotes "$c_sensor_desc")
      c_sensor_label=$(remove_quotes "$c_sensor_label")
      c_profile_name=$(remove_quotes "$c_profile_name")

      mm create_sensor --vlan_tag "$c_tag" --tenantname "$c_tenant_name" --tenantdesc "$c_tenant_desc" --tenantlabel "$c_tenant_label" --sensorname "$c_sensor_name" --sensordesc "$c_sensor_desc" --sensorlabel "$c_sensor_label" --profilename "$c_profile_name"

    done
  )
}

function ndr_stats_cmd() {

  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env
  python "${DIR}"/python/ndr_stats.py "$@"

}
function sensor_metrics_cmd() {

  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env
  python "${DIR}"/python/sensor_metrics.py "$@"

}
function create_sensor_cmd() {

  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env

  python "${DIR}"/python/create_sensor.py "$@"

}

function users_cmd() {

  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env
  python "${DIR}"/python/users.py "$@"

}
function create_user_cmd() {

  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env

  python "${DIR}"/python/create_user.py "$@"

}
function create_users_cmd() {
  cat "$1" | tr -d "\r" | awk 'NF' | (
    IFS=, read -r c_uname_hdr c_permissions_hdr
    while IFS=, read -r c_uname c_permissions; do
      c_uname=$(remove_quotes "$c_uname")
      c_permissions=$(remove_quotes "$c_permissions")

      mm create_user --username "${c_uname}" --permissions "${c_permissions}"

    done
  )
}
function sensor_report_cmd() {

  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env

  python "${DIR}"/python/sensor_report.py "$@"
}

function factory_reset_cmd() {

  if ((MIXMODE_PROVIDERID > 999)); then
    echo "Politely refusing to factory reset a production provider id, please speak to operations..."
    echo "exiting without doing anything"
    [[ "$0" == "$BASH_SOURCE" ]] && exit 1 || return 1 # handle exits from shell or function but don't exit interactive shell
  fi

  echo "THIS WILL PERMANENTLY DELETE ALL DATA AND IS NOT UNDOABLE!!! Are you sure?"
  read -p "[type Y or y to permanently reset this deployment]: " -n 1 -r
  echo ""
  echo "user typed ${REPLY}"
  if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Cancelled by user"
    [[ "$0" == "$BASH_SOURCE" ]] && exit 1 || return 1 # handle exits from shell or function but don't exit interactive shell
  fi

  echo ""
  read -p "Please type 'DELETE ALL OF THE DATA FOR ${MIXMODE_API_SERVER_HOSTNAME}' to continue..." REPLY
  echo ""
  if [ "$REPLY" != "DELETE ALL OF THE DATA FOR ${MIXMODE_API_SERVER_HOSTNAME}" ]; then
    echo "Cancelled by user"
    [[ "$0" == "$BASH_SOURCE" ]] && exit 1 || return 1 # handle exits from shell or function but don't exit interactive shell
  fi

  if [[ ! -f "/etc/profile.d/mixmode.sh" ]]; then
    echo "Must be run on server"
    [[ "$0" == "$BASH_SOURCE" ]] && exit 1 || return 1 # handle exits from shell or function but don't exit interactive shell
  fi

  . /etc/profile.d/mixmode.sh
  mm auth --user provider --password "${MIXMODE_LDAP_PASS}" --endpoint "${MIXMODE_API_SERVER_HOSTNAME}"

  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env

  # exit on first failure
  set -e

  python "${DIR}"/python/factory_reset.py "$@"
  rm -rf /opt/mixmode/etc/smf/local/* /etc/cron.d/MM_rule_* /opt/mixmode/uploads/*

  . /etc/profile.d/mixmode.sh
  export RDSHOST="${MIXMODE_POSTGRES_HOST}"
  if [ "${MIXMODE_DEPLOYMENT_TYPE}" == "enterprise" ]; then
    export PGPASSWORD="${MIXMODE_POSTGRES_PASSWORD}"
    PSQL_ARGS="host=$RDSHOST port=$MIXMODE_POSTGRES_PORT dbname=$MIXMODE_POSTGRES_DB user=$MIXMODE_POSTGRES_USER"
  else
    export PGPASSWORD="$(aws rds generate-db-auth-token --hostname $RDSHOST --port $MIXMODE_POSTGRES_PORT --region $AWS_DEFAULT_REGION --username $MIXMODE_POSTGRES_USER)"
    PSQL_ARGS="host=$RDSHOST port=$MIXMODE_POSTGRES_PORT sslmode=verify-full sslrootcert=/etc/ssl/rds-combined-ca-bundle.pem dbname=$MIXMODE_POSTGRES_DB user=$MIXMODE_POSTGRES_USER"
  fi

  psql "${PSQL_ARGS}" <<EOF
BEGIN;
 drop type if exists ai_job_ids cascade;
 drop type if exists s3_eventids cascade;
 -- before 6.22
 DROP table if exists "ConfigurationResources" cascade;
 DROP table if exists "Dashboards" cascade;
 DROP table if exists "Drafts" cascade;
 DROP table if exists "Events" cascade;
 DROP table if exists "Heartbeats" cascade;
 DROP table if exists "Histories" cascade;
 DROP table if exists "IdBookmarks" cascade;
 DROP table if exists "Indicators" cascade;
 DROP table if exists "Notifications" cascade;
 DROP table if exists "NotificationUsers" cascade;
 DROP table if exists "NotificationCategories" cascade;
 DROP table if exists "NotificationSeverities" cascade;
 DROP table if exists "NotificationTypes" cascade;
 DROP table if exists "Notifications_v1" cascade;
 DROP table if exists "Packages" cascade;
 DROP table if exists "PqlBookmarks" cascade;
 DROP table if exists "Profiles" cascade;
 DROP table if exists "Permissions" cascade;
 DROP table if exists "Rules" cascade;
 DROP table if exists "S3Buckets" cascade;
 DROP table if exists "SensorPackage" cascade;
 DROP table if exists "SensorRule" cascade;
 DROP table if exists "Sensors" cascade;
 DROP table if exists "SensorTransports" cascade;
 DROP table if exists "SequelizeMeta" cascade;
 DROP table if exists "TenantRule" cascade;
 DROP table if exists "Tenants" cascade;
 DROP table if exists "UserPermission" cascade;
 DROP table if exists "Users" cascade;
 DROP table if exists "Roles" cascade;
 DROP table if exists "RolePermission" cascade;
 -- after 6.22
 drop table if exists "Histories" cascade;
 drop table if exists "Drafts" cascade;
 drop table if exists "Profiles" cascade;
 drop table if exists "NotificationCategories" cascade;
 drop table if exists "NotificationSeverities" cascade;
 drop table if exists "NotificationTypes" cascade;
 drop table if exists "NotificationUsers" cascade;
 drop table if exists "Heartbeats" cascade;
 drop table if exists "Dashboards" cascade;
 drop table if exists "SensorTransports" cascade;
 drop table if exists "Events" cascade;
 drop table if exists "Indicators" cascade;
 drop table if exists "NotificationInstances" cascade;
 drop table if exists "ConfigurationResources" cascade;
 drop table if exists "IdBookmarks" cascade;
 drop table if exists "PqlBookmarks" cascade;
 drop table if exists "S3Buckets" cascade;
 drop table if exists "TenantRule" cascade;
 drop table if exists "Rules" cascade;
 drop table if exists "SensorRule" cascade;
 drop table if exists "Packages" cascade;
 drop table if exists "SensorPackage" cascade;
 drop table if exists "Sensors" cascade;
 drop table if exists "AI_FeatureCatalog" cascade;
 drop table if exists "AI_Job" cascade;
 drop table if exists "UserPermission" cascade;
 drop table if exists "Users" cascade;
 drop table if exists "UserRole_v2" cascade;
 drop table if exists "Roles_v2" cascade;
 drop table if exists "SequelizeMeta" cascade;
 drop table if exists "RolePermission" cascade;
 drop table if exists "Tenants" cascade;
 drop table if exists "Permissions" cascade;
 drop table if exists "TenantPermission" cascade;
 drop table if exists "Entities" cascade;
 drop table if exists "AI_S3Event" cascade;
 drop table if exists "AI_FileIngest" cascade;
 drop table if exists "Alerts" cascade;
 drop table if exists "AlertTypes" cascade;
 drop table if exists "AlertAudits" cascade;
 drop table if exists "AlertEntity" cascade;
 drop table if exists "AlertIndicator" cascade;
 drop table if exists "AlertUser" cascade;
 drop table if exists "Killchains" cascade;
 drop table if exists "ReportingSummary" cascade;
 COMMIT;

EOF

  ensure_line_exists "MIXMODE_LDAP_PASS=.*" "MIXMODE_LDAP_PASS=\"$(random_string)\"" /opt/mixmode/env
  ensure_line_exists "MIXMODE_SESSION_PASS=.*" "MIXMODE_SESSION_PASS=\"$(random_string)\"" /opt/mixmode/env

  /opt/mixmode/etc/puppet/puppet.sh apply /opt/mixmode/etc/puppet/

  rm -f "${DIR}"/api.conf
}

function psql_cmd() {
  . /etc/profile.d/mixmode.sh
  export RDSHOST="${MIXMODE_POSTGRES_HOST}"
  if [ "${MIXMODE_DEPLOYMENT_TYPE}" == "enterprise" ]; then
    export PGPASSWORD="${MIXMODE_POSTGRES_PASSWORD}"
    PSQL_ARGS="host=$RDSHOST port=$MIXMODE_POSTGRES_PORT dbname=$MIXMODE_POSTGRES_DB user=$MIXMODE_POSTGRES_USER"
  else
    export PGPASSWORD="$(aws rds generate-db-auth-token --hostname $RDSHOST --port $MIXMODE_POSTGRES_PORT --region $AWS_DEFAULT_REGION --username $MIXMODE_POSTGRES_USER)"
    PSQL_ARGS="host=$RDSHOST port=$MIXMODE_POSTGRES_PORT sslmode=verify-full sslrootcert=/etc/ssl/rds-combined-ca-bundle.pem dbname=$MIXMODE_POSTGRES_DB user=$MIXMODE_POSTGRES_USER"
  fi
  psql "${PSQL_ARGS}" $@
}
function export_rules_cmd() {

  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env

  python "${DIR}"/python/export_rules.py "$@"
}
function import_rules_cmd() {

  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env

  python "${DIR}"/python/import_rules.py "$@"
}
function export_bookmarks_cmd() {

  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env

  python "${DIR}"/python/export_bookmarks.py "$@"
}
function import_bookmarks_cmd() {

  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env

  python "${DIR}"/python/import_bookmarks.py "$@"
}
function upload_enrichments_cmd() {

  set -a
  . "${DIR}"/api.conf
  set +a
  activate_env

  python "${DIR}"/python/upload_enrichments.py "$@"
}
function version_cmd() {
  . "${DIR}"/version.conf
  echo "${BUILD_VERSION_MAJOR}.${BUILD_VERSION_MINOR}.${BUILD_VERSION_ITERATION}-${BUILD_VERSION_BUILDNUMBER}"
}
function aws_resources_cmd() {
  activate_env
  set -a
  . "${DIR}"/api.conf
  . /opt/mixmode/env
  set +a
  python "${DIR}"/python/aws_resources_cmd.py "$@"
}
function irw_cmd() {
  activate_env
  set -a
  . "${DIR}"/api.conf
  . /opt/mixmode/env
  set +a
  read -r -d '' IRW_USAGE << EOM_IRW_USAGE
Error: missing arguments
USAGE:
mm irw assign <query> <timezone> <username>
mm irw unassign <query> <timezone>
mm irw status <query> <timezone> <open|closed>
EOM_IRW_USAGE

  cmd="$1"
  shift
  case "$cmd" in
  assign)
    python "${DIR}"/python/irw_assign_cmd.py --pql_query="$1" --timezone="$2" --username="$3"
    ;;
  unassign)
    python "${DIR}"/python/irw_unassign_cmd.py --pql_query="$1" --timezone="$2"
    ;;
  status)
    python "${DIR}"/python/irw_status_cmd.py --pql_query="$1" --timezone="$2" --status="$3"
    ;;
  "")
    echo "$IRW_USAGE"
    exit 1
    ;;
  *)
    echo "$IRW_USAGE"
    exit 1
    ;;
  esac
}

cmd="$1"
shift
case "$cmd" in
"") print_Default "$@" ;;
install) install_cmd "$@" ;;
auth) auth_cmd "$@" ;;
refresh) refresh_cmd "$@" ;;
query) query_cmd "$@" ;;
suggest) suggest_cmd "$@" ;;
stream) stream_cmd "$@" ;;
export) export_cmd "$@" ;;
ndr) ndr_cmd "$@" ;;
rsync) rsync_cmd "$@" ;;
splunk) splunk_cmd "$@" ;;
reputation) reputation_cmd "$@" ;;
tenants) tenants_cmd "$@" ;;
smf_script) smf_script_cmd "$@" ;;
sensors) sensors_cmd "$@" ;;
rules) rules_cmd "$@" ;;
sensor_config) sensor_config_cmd "$@" ;;
parse_json) parse_json_cmd "$@" ;;
hotfix) hotfix_cmd "$@" ;;
apply_smf_updates) apply_smf_updates_cmd "$@" ;;
reauthenticate_sensors) reauthenticate_sensors_cmd "$@" ;;
token) token_cmd "$@" ;;
create_sensor) create_sensor_cmd "$@" ;;
sensor_metrics) sensor_metrics_cmd "$@" ;;
ndr_stats) ndr_stats_cmd "$@" ;;
vlan_import) create_sensors_cmd "$@" ;;
create_sensors) create_sensors_cmd "$@" ;;
users) users_cmd "$@" ;;
create_user) create_user_cmd "$@" ;;
create_users) create_users_cmd "$@" ;;
factory_reset) factory_reset_cmd "$@" ;;
sensor_report) sensor_report_cmd "$@" ;;
psql) psql_cmd "$@" ;;
export_rules) export_rules_cmd "$@" ;;
import_rules) import_rules_cmd "$@" ;;
export_bookmarks) export_bookmarks_cmd "$@" ;;
import_bookmarks) import_bookmarks_cmd "$@" ;;
upload_enrichments) upload_enrichments_cmd "$@" ;;
version) version_cmd "$@" ;;
gql) gql_cmd "$@" ;;
aws_resources) aws_resources_cmd "$@" ;;
copy_to_sensor) copy_to_sensor_cmd "$@" ;;
irw) irw_cmd "$@" ;;
*) print_Default "$@" ;;
esac
