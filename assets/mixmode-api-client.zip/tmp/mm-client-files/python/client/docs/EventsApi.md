# mixmode_api.EventsApi

All URIs are relative to *https://api.mixmode.ai/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**set_event_assigned**](EventsApi.md#set_event_assigned) | **POST** /tenants/{TenantId}/events/{EventId}/assign/{username} | Assign event to user.
[**set_event_status**](EventsApi.md#set_event_status) | **POST** /tenants/{TenantId}/events/{EventId}/status/{eventStatus} | Set an event status.


# **set_event_assigned**
> Event set_event_assigned(tenant_id, event_id, username)

Assign event to user.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EventsApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
event_id = 56 # int | The id of the object to retrieve.
username = 'username_example' # str | A User unique identifier.

try:
    # Assign event to user.
    api_response = api_instance.set_event_assigned(tenant_id, event_id, username)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EventsApi->set_event_assigned: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **event_id** | **int**| The id of the object to retrieve. | 
 **username** | **str**| A User unique identifier. | 

### Return type

[**Event**](Event.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_event_status**
> Event set_event_status(tenant_id, event_id, event_status)

Set an event status.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EventsApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
event_id = 56 # int | The id of the object to retrieve.
event_status = 'event_status_example' # str | Status of event.

try:
    # Set an event status.
    api_response = api_instance.set_event_status(tenant_id, event_id, event_status)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EventsApi->set_event_status: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **event_id** | **int**| The id of the object to retrieve. | 
 **event_status** | **str**| Status of event. | 

### Return type

[**Event**](Event.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

