# RuleResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Unique Identifier representing a document | 
**created_at** | **datetime** | Creation timestamp | [optional] 
**updated_at** | **datetime** | Update timestamp | [optional] 
**name** | **str** | The name of an object | 
**description** | **str** | A description of an object | [optional] 
**labels** | **list[str]** | A list of labels. | [optional] 
**threshold** | **int** | If query result counts exceed this number, the rule will fire. | 
**threshold_operator** | **str** | The operator to use when comparing threshold with query result count. | [default to 'greater_than']
**enabled** | **bool** | Whether or not rule is disabled. Disabled rules will not execute. | [optional] [default to True]
**email_send** | **bool** | Whether or not to send an email report when this rule creates 1 or more indicators. | [optional] 
**email_recipients** | **str** | Comma separated list of email recipients. If blank/empty will default to user who created this rule. | [optional] 
**status** | **str** | Current status of the rule. | [optional] [default to 'idle']
**data** | [**RuleMetadata**](RuleMetadata.md) |  | [optional] 
**sensors** | [**list[Sensor]**](Sensor.md) | An array of Sensors. | [optional] 
**tenants** | [**list[Tenant]**](Tenant.md) | An array of Tenants. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


