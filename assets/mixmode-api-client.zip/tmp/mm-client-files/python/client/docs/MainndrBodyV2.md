# MainndrBodyV2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **str** |  | [optional] 
**guid** | **str** |  | [optional] 
**limitbytes** | **int** |  | [optional] 
**limitpkts** | **int** |  | [optional] 
**name** | **str** |  | [optional] 
**rule** | **str** |  | [optional] 
**expiration** | **str** |  | [optional] 
**storagepath** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


