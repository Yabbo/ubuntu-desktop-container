# NotificationCategory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | The name of an object | 
**description** | **str** | A description of an object | [optional] 
**labels** | **list[str]** | A list of labels. | [optional] 
**id** | **int** | Unique Identifier representing a document | 
**created_at** | **datetime** | Creation timestamp | [optional] 
**updated_at** | **datetime** | Update timestamp | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


