# SensorMetricsResults

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**compiled** | **object** |  | [optional] 
**context** | [**SensorMetricsResultsContext**](SensorMetricsResultsContext.md) |  | [optional] 
**tenants** | [**list[TenantSensorMetric]**](TenantSensorMetric.md) | A list of tenant metrics | [optional] 
**sensors** | [**list[SensorMetric]**](SensorMetric.md) | A list of tenant sensor metrics | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


