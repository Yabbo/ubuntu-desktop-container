# GitStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**not_added** | **list[str]** | list of files modified but not added | [optional] 
**conflicted** | **list[str]** | list of files in conflict | [optional] 
**created** | **list[str]** | list of files created | [optional] 
**deleted** | **list[str]** | list of files deleted | [optional] 
**modified** | **list[str]** | list of files modified | [optional] 
**renamed** | **list[object]** | list of files renamed | [optional] 
**ahead** | **int** | # of files ahead | [optional] 
**behind** | **int** | # of files behind | [optional] 
**current** | **str** | current branch | [optional] 
**tracking** | **str** | tracking remote branch | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


