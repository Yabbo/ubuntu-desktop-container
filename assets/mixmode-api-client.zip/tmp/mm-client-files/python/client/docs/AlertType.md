# AlertType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | The name of an object | 
**description** | **str** | A description of an object | [optional] 
**labels** | **list[str]** | A list of labels. | [optional] 
**key** | **str** |  | 
**category** | **str** |  | 
**remediation_documentation** | **str** |  | [optional] 
**mitre_tactic_id** | **str** |  | [optional] 
**mitre_tactic_description** | **str** |  | [optional] 
**mitre_tactic_url** | **str** |  | [optional] 
**mitre_tactic_name** | **str** |  | [optional] 
**weight** | **int** |  | 
**units** | **str** |  | [optional] 
**profile_types** | **list[str]** | A list of profile types this alert type applies to. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


