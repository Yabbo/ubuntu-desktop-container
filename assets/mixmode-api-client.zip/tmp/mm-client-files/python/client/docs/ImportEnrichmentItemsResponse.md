# ImportEnrichmentItemsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** | The overall status of importing the data. | [optional] 
**succeeded** | **float** | The number of records successfully imported from the file. | [optional] 
**failed** | **float** | The number of records unsuccessfully imported from the file. | [optional] 
**total** | **float** | The total number of records read from the file. | [optional] 
**errors** | **list[str]** | An array of errors about the processing of the imported file. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


