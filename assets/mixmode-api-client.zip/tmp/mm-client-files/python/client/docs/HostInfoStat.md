# HostInfoStat

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**boot_time** | **int** |  | [optional] 
**hostid** | **str** |  | [optional] 
**hostname** | **str** |  | [optional] 
**kernel_version** | **str** |  | [optional] 
**os** | **str** |  | [optional] 
**platform** | **str** |  | [optional] 
**platform_family** | **str** |  | [optional] 
**platform_version** | **str** |  | [optional] 
**procs** | **int** |  | [optional] 
**uptime** | **int** |  | [optional] 
**virtualization_permission** | **str** |  | [optional] 
**virtualization_system** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


