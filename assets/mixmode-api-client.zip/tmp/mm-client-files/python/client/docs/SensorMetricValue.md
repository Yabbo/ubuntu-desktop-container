# SensorMetricValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ts** | **int** |  | [optional] 
**bytes_recv** | **float** |  | [optional] 
**document_count** | **float** |  | [optional] 
**mbps** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


