# Heartbeat

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**timestamp** | **datetime** | The RFC3339 timestamp of the heartbeat, as a string. | [optional] 
**sys_stats** | **object** | An object containing the results of querying various system metrics from the sensor. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


