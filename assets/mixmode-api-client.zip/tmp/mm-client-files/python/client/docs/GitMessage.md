# GitMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hash** | **str** | The SHA hash of the commit. | [optional] 
**_date** | **str** | The date of the commit. | [optional] 
**message** | **str** | The commit message. | [optional] 
**author_name** | **str** | The commit author. | [optional] 
**author_email** | **str** | The commit author email. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


