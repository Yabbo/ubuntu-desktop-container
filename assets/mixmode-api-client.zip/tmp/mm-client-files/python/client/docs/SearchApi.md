# mixmode_api.SearchApi

All URIs are relative to *https://api.mixmode.ai/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**bulk_query**](SearchApi.md#bulk_query) | **POST** /search/bulk | Execute multiple queries in a single transaction.
[**check_pcap_for_event**](SearchApi.md#check_pcap_for_event) | **HEAD** /tenants/{TenantId}/smf/sensors/{SensorId}/events/{EventId}/pcap | Check existence of pcap for event.
[**check_pcap_for_indicator**](SearchApi.md#check_pcap_for_indicator) | **HEAD** /tenants/{TenantId}/smf/sensors/{SensorId}/indicators/{IndicatorId}/pcap | Check existence of pcap for indicator.
[**check_pcap_for_log**](SearchApi.md#check_pcap_for_log) | **HEAD** /tenants/{TenantId}/smf/sensors/{SensorId}/logs/{LogId}/pcap | Check existence of pcap for log.
[**dictionary**](SearchApi.md#dictionary) | **GET** /search/dictionary | Return a dictionary for the attributes in the schema for SearchType.
[**get_event**](SearchApi.md#get_event) | **GET** /tenants/{TenantId}/events/{EventId} | Get event by id.
[**get_events**](SearchApi.md#get_events) | **GET** /search/events | Execute a PQL query and return the results.
[**get_history**](SearchApi.md#get_history) | **GET** /search/history | Queries the system and returns a filtered, sorted, paged list of queries that have been executed.
[**get_indicator**](SearchApi.md#get_indicator) | **GET** /tenants/{TenantId}/indicators/{IndicatorId} | Get indicator by id.
[**get_indicators**](SearchApi.md#get_indicators) | **GET** /search/indicators | Execute a PQL query and return the results.
[**get_logs**](SearchApi.md#get_logs) | **GET** /search/logs | Execute a PQL query and return the results.
[**get_pcap_for_event**](SearchApi.md#get_pcap_for_event) | **GET** /tenants/{TenantId}/smf/sensors/{SensorId}/events/{EventId}/pcap | Get pcap for event.
[**get_pcap_for_indicator**](SearchApi.md#get_pcap_for_indicator) | **GET** /tenants/{TenantId}/smf/sensors/{SensorId}/indicators/{IndicatorId}/pcap | Get pcap for indicator.
[**get_pcap_for_log**](SearchApi.md#get_pcap_for_log) | **GET** /tenants/{TenantId}/smf/sensors/{SensorId}/logs/{LogId}/pcap | Get pcap for log.
[**prepare_pcap_for_event**](SearchApi.md#prepare_pcap_for_event) | **GET** /tenants/{TenantId}/smf/sensors/{SensorId}/events/{EventId}/pcap/prepare | Prepare pcap query for event.
[**prepare_pcap_for_indicator**](SearchApi.md#prepare_pcap_for_indicator) | **GET** /tenants/{TenantId}/smf/sensors/{SensorId}/indicators/{IndicatorId}/pcap/prepare | Prepare pcap query for indicator.
[**prepare_pcap_for_log**](SearchApi.md#prepare_pcap_for_log) | **GET** /tenants/{TenantId}/smf/sensors/{SensorId}/logs/{LogId}/pcap/prepare | Prepare pcap query for log.
[**query**](SearchApi.md#query) | **GET** /search/query | Execute a PQL query and return the results.
[**query_to_csv**](SearchApi.md#query_to_csv) | **GET** /search/query/csv | Execute a PQL query and return the results as a CSV file.
[**query_to_json**](SearchApi.md#query_to_json) | **GET** /search/query/json | Execute a PQL query and return the results as a JSON array payload.
[**sensor_metrics**](SearchApi.md#sensor_metrics) | **GET** /search/sensor/metrics | Get all sensor metrics in this timerange.
[**stream_search**](SearchApi.md#stream_search) | **GET** /search/stream | Execute a PQL query and stream the results.
[**suggest**](SearchApi.md#suggest) | **GET** /search/suggest | Compile a query, and provide suggestions.


# **bulk_query**
> BulkQueryResult bulk_query(bulk_query)

Execute multiple queries in a single transaction.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
bulk_query = mixmode_api.BulkQuery() # BulkQuery | A list of queries to execute in a single transaction.

try:
    # Execute multiple queries in a single transaction.
    api_response = api_instance.bulk_query(bulk_query)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchApi->bulk_query: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bulk_query** | [**BulkQuery**](BulkQuery.md)| A list of queries to execute in a single transaction. | 

### Return type

[**BulkQueryResult**](BulkQueryResult.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **check_pcap_for_event**
> check_pcap_for_event(tenant_id, sensor_id, event_id, limitpkts=limitpkts, limitbytes=limitbytes)

Check existence of pcap for event.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
event_id = 56 # int | The id of the object to retrieve.
limitpkts = 56 # int | The maximum number of packets to return. (optional)
limitbytes = 56 # int | The maximum number of bytes to return. (optional)

try:
    # Check existence of pcap for event.
    api_instance.check_pcap_for_event(tenant_id, sensor_id, event_id, limitpkts=limitpkts, limitbytes=limitbytes)
except ApiException as e:
    print("Exception when calling SearchApi->check_pcap_for_event: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **event_id** | **int**| The id of the object to retrieve. | 
 **limitpkts** | **int**| The maximum number of packets to return. | [optional] 
 **limitbytes** | **int**| The maximum number of bytes to return. | [optional] 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **check_pcap_for_indicator**
> check_pcap_for_indicator(tenant_id, sensor_id, indicator_id, limitpkts=limitpkts, limitbytes=limitbytes)

Check existence of pcap for indicator.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
indicator_id = 56 # int | The id of the object to retrieve.
limitpkts = 56 # int | The maximum number of packets to return. (optional)
limitbytes = 56 # int | The maximum number of bytes to return. (optional)

try:
    # Check existence of pcap for indicator.
    api_instance.check_pcap_for_indicator(tenant_id, sensor_id, indicator_id, limitpkts=limitpkts, limitbytes=limitbytes)
except ApiException as e:
    print("Exception when calling SearchApi->check_pcap_for_indicator: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **indicator_id** | **int**| The id of the object to retrieve. | 
 **limitpkts** | **int**| The maximum number of packets to return. | [optional] 
 **limitbytes** | **int**| The maximum number of bytes to return. | [optional] 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **check_pcap_for_log**
> check_pcap_for_log(tenant_id, sensor_id, log_id, limitpkts=limitpkts, limitbytes=limitbytes)

Check existence of pcap for log.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
log_id = 'log_id_example' # str | The id of the object to retrieve.
limitpkts = 56 # int | The maximum number of packets to return. (optional)
limitbytes = 56 # int | The maximum number of bytes to return. (optional)

try:
    # Check existence of pcap for log.
    api_instance.check_pcap_for_log(tenant_id, sensor_id, log_id, limitpkts=limitpkts, limitbytes=limitbytes)
except ApiException as e:
    print("Exception when calling SearchApi->check_pcap_for_log: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **log_id** | **str**| The id of the object to retrieve. | 
 **limitpkts** | **int**| The maximum number of packets to return. | [optional] 
 **limitbytes** | **int**| The maximum number of bytes to return. | [optional] 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **dictionary**
> Dictionary dictionary(timezone, context=context, search_type=search_type)

Return a dictionary for the attributes in the schema for SearchType.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
timezone = 'timezone_example' # str | The timezone for parsing date/time statements in the mixmode query language.
context = [56] # list[int] | A list of sensor ids to query. (optional)
search_type = 'O_SENSOR' # str | The data source to query. (optional) (default to O_SENSOR)

try:
    # Return a dictionary for the attributes in the schema for SearchType.
    api_response = api_instance.dictionary(timezone, context=context, search_type=search_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchApi->dictionary: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **timezone** | **str**| The timezone for parsing date/time statements in the mixmode query language. | 
 **context** | [**list[int]**](int.md)| A list of sensor ids to query. | [optional] 
 **search_type** | **str**| The data source to query. | [optional] [default to O_SENSOR]

### Return type

[**Dictionary**](Dictionary.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_event**
> SearchResults get_event(tenant_id, event_id)

Get event by id.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
event_id = 56 # int | The id of the object to retrieve.

try:
    # Get event by id.
    api_response = api_instance.get_event(tenant_id, event_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchApi->get_event: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **event_id** | **int**| The id of the object to retrieve. | 

### Return type

[**SearchResults**](SearchResults.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_events**
> SearchResults get_events(query, timezone, context=context)

Execute a PQL query and return the results.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
query = 'query_example' # str | The query, in the mixmode query language.
timezone = 'timezone_example' # str | The timezone for parsing date/time statements in the mixmode query language.
context = [56] # list[int] | A list of sensor ids to query. (optional)

try:
    # Execute a PQL query and return the results.
    api_response = api_instance.get_events(query, timezone, context=context)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchApi->get_events: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**| The query, in the mixmode query language. | 
 **timezone** | **str**| The timezone for parsing date/time statements in the mixmode query language. | 
 **context** | [**list[int]**](int.md)| A list of sensor ids to query. | [optional] 

### Return type

[**SearchResults**](SearchResults.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_history**
> PagedHistories get_history(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of queries that have been executed.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of queries that have been executed.
    api_response = api_instance.get_history(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchApi->get_history: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedHistories**](PagedHistories.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_indicator**
> SearchResults get_indicator(tenant_id, indicator_id)

Get indicator by id.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
indicator_id = 56 # int | The id of the object to retrieve.

try:
    # Get indicator by id.
    api_response = api_instance.get_indicator(tenant_id, indicator_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchApi->get_indicator: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **indicator_id** | **int**| The id of the object to retrieve. | 

### Return type

[**SearchResults**](SearchResults.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_indicators**
> SearchResults get_indicators(query, timezone, context=context)

Execute a PQL query and return the results.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
query = 'query_example' # str | The query, in the mixmode query language.
timezone = 'timezone_example' # str | The timezone for parsing date/time statements in the mixmode query language.
context = [56] # list[int] | A list of sensor ids to query. (optional)

try:
    # Execute a PQL query and return the results.
    api_response = api_instance.get_indicators(query, timezone, context=context)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchApi->get_indicators: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**| The query, in the mixmode query language. | 
 **timezone** | **str**| The timezone for parsing date/time statements in the mixmode query language. | 
 **context** | [**list[int]**](int.md)| A list of sensor ids to query. | [optional] 

### Return type

[**SearchResults**](SearchResults.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_logs**
> SearchResults get_logs(query, timezone, context=context)

Execute a PQL query and return the results.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
query = 'query_example' # str | The query, in the mixmode query language.
timezone = 'timezone_example' # str | The timezone for parsing date/time statements in the mixmode query language.
context = [56] # list[int] | A list of sensor ids to query. (optional)

try:
    # Execute a PQL query and return the results.
    api_response = api_instance.get_logs(query, timezone, context=context)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchApi->get_logs: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**| The query, in the mixmode query language. | 
 **timezone** | **str**| The timezone for parsing date/time statements in the mixmode query language. | 
 **context** | [**list[int]**](int.md)| A list of sensor ids to query. | [optional] 

### Return type

[**SearchResults**](SearchResults.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_pcap_for_event**
> get_pcap_for_event(tenant_id, sensor_id, event_id, limitpkts=limitpkts, limitbytes=limitbytes)

Get pcap for event.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
event_id = 56 # int | The id of the object to retrieve.
limitpkts = 56 # int | The maximum number of packets to return. (optional)
limitbytes = 56 # int | The maximum number of bytes to return. (optional)

try:
    # Get pcap for event.
    api_instance.get_pcap_for_event(tenant_id, sensor_id, event_id, limitpkts=limitpkts, limitbytes=limitbytes)
except ApiException as e:
    print("Exception when calling SearchApi->get_pcap_for_event: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **event_id** | **int**| The id of the object to retrieve. | 
 **limitpkts** | **int**| The maximum number of packets to return. | [optional] 
 **limitbytes** | **int**| The maximum number of bytes to return. | [optional] 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/octet-stream

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_pcap_for_indicator**
> get_pcap_for_indicator(tenant_id, sensor_id, indicator_id, limitpkts=limitpkts, limitbytes=limitbytes)

Get pcap for indicator.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
indicator_id = 56 # int | The id of the object to retrieve.
limitpkts = 56 # int | The maximum number of packets to return. (optional)
limitbytes = 56 # int | The maximum number of bytes to return. (optional)

try:
    # Get pcap for indicator.
    api_instance.get_pcap_for_indicator(tenant_id, sensor_id, indicator_id, limitpkts=limitpkts, limitbytes=limitbytes)
except ApiException as e:
    print("Exception when calling SearchApi->get_pcap_for_indicator: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **indicator_id** | **int**| The id of the object to retrieve. | 
 **limitpkts** | **int**| The maximum number of packets to return. | [optional] 
 **limitbytes** | **int**| The maximum number of bytes to return. | [optional] 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/octet-stream

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_pcap_for_log**
> get_pcap_for_log(tenant_id, sensor_id, log_id, limitpkts=limitpkts, limitbytes=limitbytes)

Get pcap for log.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
log_id = 'log_id_example' # str | The id of the object to retrieve.
limitpkts = 56 # int | The maximum number of packets to return. (optional)
limitbytes = 56 # int | The maximum number of bytes to return. (optional)

try:
    # Get pcap for log.
    api_instance.get_pcap_for_log(tenant_id, sensor_id, log_id, limitpkts=limitpkts, limitbytes=limitbytes)
except ApiException as e:
    print("Exception when calling SearchApi->get_pcap_for_log: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **log_id** | **str**| The id of the object to retrieve. | 
 **limitpkts** | **int**| The maximum number of packets to return. | [optional] 
 **limitbytes** | **int**| The maximum number of bytes to return. | [optional] 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/octet-stream

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **prepare_pcap_for_event**
> MainndrBodyV2 prepare_pcap_for_event(tenant_id, sensor_id, event_id, limitpkts=limitpkts, limitbytes=limitbytes)

Prepare pcap query for event.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
event_id = 56 # int | The id of the object to retrieve.
limitpkts = 56 # int | The maximum number of packets to return. (optional)
limitbytes = 56 # int | The maximum number of bytes to return. (optional)

try:
    # Prepare pcap query for event.
    api_response = api_instance.prepare_pcap_for_event(tenant_id, sensor_id, event_id, limitpkts=limitpkts, limitbytes=limitbytes)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchApi->prepare_pcap_for_event: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **event_id** | **int**| The id of the object to retrieve. | 
 **limitpkts** | **int**| The maximum number of packets to return. | [optional] 
 **limitbytes** | **int**| The maximum number of bytes to return. | [optional] 

### Return type

[**MainndrBodyV2**](MainndrBodyV2.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **prepare_pcap_for_indicator**
> MainndrBodyV2 prepare_pcap_for_indicator(tenant_id, sensor_id, indicator_id, limitpkts=limitpkts, limitbytes=limitbytes)

Prepare pcap query for indicator.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
indicator_id = 56 # int | The id of the object to retrieve.
limitpkts = 56 # int | The maximum number of packets to return. (optional)
limitbytes = 56 # int | The maximum number of bytes to return. (optional)

try:
    # Prepare pcap query for indicator.
    api_response = api_instance.prepare_pcap_for_indicator(tenant_id, sensor_id, indicator_id, limitpkts=limitpkts, limitbytes=limitbytes)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchApi->prepare_pcap_for_indicator: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **indicator_id** | **int**| The id of the object to retrieve. | 
 **limitpkts** | **int**| The maximum number of packets to return. | [optional] 
 **limitbytes** | **int**| The maximum number of bytes to return. | [optional] 

### Return type

[**MainndrBodyV2**](MainndrBodyV2.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **prepare_pcap_for_log**
> MainndrBodyV2 prepare_pcap_for_log(tenant_id, sensor_id, log_id, limitpkts=limitpkts, limitbytes=limitbytes)

Prepare pcap query for log.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
log_id = 'log_id_example' # str | The id of the object to retrieve.
limitpkts = 56 # int | The maximum number of packets to return. (optional)
limitbytes = 56 # int | The maximum number of bytes to return. (optional)

try:
    # Prepare pcap query for log.
    api_response = api_instance.prepare_pcap_for_log(tenant_id, sensor_id, log_id, limitpkts=limitpkts, limitbytes=limitbytes)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchApi->prepare_pcap_for_log: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **log_id** | **str**| The id of the object to retrieve. | 
 **limitpkts** | **int**| The maximum number of packets to return. | [optional] 
 **limitbytes** | **int**| The maximum number of bytes to return. | [optional] 

### Return type

[**MainndrBodyV2**](MainndrBodyV2.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query**
> SearchResults query(query, timezone, context=context, search_type=search_type)

Execute a PQL query and return the results.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
query = 'query_example' # str | The query, in the mixmode query language.
timezone = 'timezone_example' # str | The timezone for parsing date/time statements in the mixmode query language.
context = [56] # list[int] | A list of sensor ids to query. (optional)
search_type = 'O_SENSOR' # str | The data source to query. (optional) (default to O_SENSOR)

try:
    # Execute a PQL query and return the results.
    api_response = api_instance.query(query, timezone, context=context, search_type=search_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchApi->query: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**| The query, in the mixmode query language. | 
 **timezone** | **str**| The timezone for parsing date/time statements in the mixmode query language. | 
 **context** | [**list[int]**](int.md)| A list of sensor ids to query. | [optional] 
 **search_type** | **str**| The data source to query. | [optional] [default to O_SENSOR]

### Return type

[**SearchResults**](SearchResults.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_to_csv**
> query_to_csv(query, timezone, context=context, search_type=search_type)

Execute a PQL query and return the results as a CSV file.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
query = 'query_example' # str | The query, in the mixmode query language.
timezone = 'timezone_example' # str | The timezone for parsing date/time statements in the mixmode query language.
context = [56] # list[int] | A list of sensor ids to query. (optional)
search_type = 'O_SENSOR' # str | The data source to query. (optional) (default to O_SENSOR)

try:
    # Execute a PQL query and return the results as a CSV file.
    api_instance.query_to_csv(query, timezone, context=context, search_type=search_type)
except ApiException as e:
    print("Exception when calling SearchApi->query_to_csv: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**| The query, in the mixmode query language. | 
 **timezone** | **str**| The timezone for parsing date/time statements in the mixmode query language. | 
 **context** | [**list[int]**](int.md)| A list of sensor ids to query. | [optional] 
 **search_type** | **str**| The data source to query. | [optional] [default to O_SENSOR]

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: text/csv

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_to_json**
> query_to_json(query, timezone, context=context, search_type=search_type)

Execute a PQL query and return the results as a JSON array payload.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
query = 'query_example' # str | The query, in the mixmode query language.
timezone = 'timezone_example' # str | The timezone for parsing date/time statements in the mixmode query language.
context = [56] # list[int] | A list of sensor ids to query. (optional)
search_type = 'O_SENSOR' # str | The data source to query. (optional) (default to O_SENSOR)

try:
    # Execute a PQL query and return the results as a JSON array payload.
    api_instance.query_to_json(query, timezone, context=context, search_type=search_type)
except ApiException as e:
    print("Exception when calling SearchApi->query_to_json: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**| The query, in the mixmode query language. | 
 **timezone** | **str**| The timezone for parsing date/time statements in the mixmode query language. | 
 **context** | [**list[int]**](int.md)| A list of sensor ids to query. | [optional] 
 **search_type** | **str**| The data source to query. | [optional] [default to O_SENSOR]

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **sensor_metrics**
> SensorMetricsResults sensor_metrics(query, timezone, windowsize=windowsize, search_type=search_type, context=context, include_tenant_metrics=include_tenant_metrics, include_sensor_metrics=include_sensor_metrics)

Get all sensor metrics in this timerange.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
query = 'query_example' # str | The query, in the mixmode query language.
timezone = 'timezone_example' # str | The timezone for parsing date/time statements in the mixmode query language.
windowsize = 60 # int | The window size in minutes. (optional) (default to 60)
search_type = 'O_SENSOR' # str | The data source to query. (optional) (default to O_SENSOR)
context = [56] # list[int] | A list of sensor ids to query. (optional)
include_tenant_metrics = false # bool |  (optional) (default to false)
include_sensor_metrics = false # bool |  (optional) (default to false)

try:
    # Get all sensor metrics in this timerange.
    api_response = api_instance.sensor_metrics(query, timezone, windowsize=windowsize, search_type=search_type, context=context, include_tenant_metrics=include_tenant_metrics, include_sensor_metrics=include_sensor_metrics)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchApi->sensor_metrics: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**| The query, in the mixmode query language. | 
 **timezone** | **str**| The timezone for parsing date/time statements in the mixmode query language. | 
 **windowsize** | **int**| The window size in minutes. | [optional] [default to 60]
 **search_type** | **str**| The data source to query. | [optional] [default to O_SENSOR]
 **context** | [**list[int]**](int.md)| A list of sensor ids to query. | [optional] 
 **include_tenant_metrics** | **bool**|  | [optional] [default to false]
 **include_sensor_metrics** | **bool**|  | [optional] [default to false]

### Return type

[**SensorMetricsResults**](SensorMetricsResults.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **stream_search**
> stream_search(query, timezone, context=context, search_type=search_type)

Execute a PQL query and stream the results.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
query = 'query_example' # str | The query, in the mixmode query language.
timezone = 'timezone_example' # str | The timezone for parsing date/time statements in the mixmode query language.
context = [56] # list[int] | A list of sensor ids to query. (optional)
search_type = 'O_SENSOR' # str | The data source to query. (optional) (default to O_SENSOR)

try:
    # Execute a PQL query and stream the results.
    api_instance.stream_search(query, timezone, context=context, search_type=search_type)
except ApiException as e:
    print("Exception when calling SearchApi->stream_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**| The query, in the mixmode query language. | 
 **timezone** | **str**| The timezone for parsing date/time statements in the mixmode query language. | 
 **context** | [**list[int]**](int.md)| A list of sensor ids to query. | [optional] 
 **search_type** | **str**| The data source to query. | [optional] [default to O_SENSOR]

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/octet-stream

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **suggest**
> SuggestResults suggest(query, timezone, context=context, search_type=search_type)

Compile a query, and provide suggestions.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SearchApi(mixmode_api.ApiClient(configuration))
query = 'query_example' # str | The query, in the mixmode query language.
timezone = 'timezone_example' # str | The timezone for parsing date/time statements in the mixmode query language.
context = [56] # list[int] | A list of sensor ids to query. (optional)
search_type = 'O_SENSOR' # str | The data source to query. (optional) (default to O_SENSOR)

try:
    # Compile a query, and provide suggestions.
    api_response = api_instance.suggest(query, timezone, context=context, search_type=search_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchApi->suggest: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**| The query, in the mixmode query language. | 
 **timezone** | **str**| The timezone for parsing date/time statements in the mixmode query language. | 
 **context** | [**list[int]**](int.md)| A list of sensor ids to query. | [optional] 
 **search_type** | **str**| The data source to query. | [optional] [default to O_SENSOR]

### Return type

[**SuggestResults**](SuggestResults.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

