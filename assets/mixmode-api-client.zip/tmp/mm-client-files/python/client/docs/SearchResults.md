# SearchResults

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**compiled** | **object** | The compiled query | [optional] 
**results** | **list[object]** | A list of results | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


