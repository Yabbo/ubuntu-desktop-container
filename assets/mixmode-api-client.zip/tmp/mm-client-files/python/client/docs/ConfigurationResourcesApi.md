# mixmode_api.ConfigurationResourcesApi

All URIs are relative to *https://api.mixmode.ai/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_configuration_resource**](ConfigurationResourcesApi.md#create_configuration_resource) | **POST** /tenants/{TenantId}/configuration | Create a new configuration.
[**create_provider_configuration_resource**](ConfigurationResourcesApi.md#create_provider_configuration_resource) | **POST** /configuration | Create a new configuration.
[**get_configuration_resources**](ConfigurationResourcesApi.md#get_configuration_resources) | **GET** /tenants/{TenantId}/configuration | Queries the system and returns a configuration metadata object.
[**get_provider_configuration_resources**](ConfigurationResourcesApi.md#get_provider_configuration_resources) | **GET** /configuration | Queries the system and returns a configuration metadata object.


# **create_configuration_resource**
> ConfigurationResource create_configuration_resource(tenant_id, configuration)

Create a new configuration.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.ConfigurationResourcesApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
configuration = mixmode_api.ConfigurationResourceAttributes() # ConfigurationResourceAttributes | A configuration is a logically related collection of attributes and their values.

try:
    # Create a new configuration.
    api_response = api_instance.create_configuration_resource(tenant_id, configuration)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ConfigurationResourcesApi->create_configuration_resource: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **configuration** | [**ConfigurationResourceAttributes**](ConfigurationResourceAttributes.md)| A configuration is a logically related collection of attributes and their values. | 

### Return type

[**ConfigurationResource**](ConfigurationResource.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_provider_configuration_resource**
> ConfigurationResource create_provider_configuration_resource(configuration)

Create a new configuration.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.ConfigurationResourcesApi(mixmode_api.ApiClient(configuration))
configuration = mixmode_api.ConfigurationResourceAttributes() # ConfigurationResourceAttributes | A configuration is a logically related collection of attributes and their values.

try:
    # Create a new configuration.
    api_response = api_instance.create_provider_configuration_resource(configuration)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ConfigurationResourcesApi->create_provider_configuration_resource: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **configuration** | [**ConfigurationResourceAttributes**](ConfigurationResourceAttributes.md)| A configuration is a logically related collection of attributes and their values. | 

### Return type

[**ConfigurationResource**](ConfigurationResource.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_configuration_resources**
> ConfigurationResource get_configuration_resources(tenant_id)

Queries the system and returns a configuration metadata object.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.ConfigurationResourcesApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 

try:
    # Queries the system and returns a configuration metadata object.
    api_response = api_instance.get_configuration_resources(tenant_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ConfigurationResourcesApi->get_configuration_resources: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 

### Return type

[**ConfigurationResource**](ConfigurationResource.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_provider_configuration_resources**
> ConfigurationResource get_provider_configuration_resources()

Queries the system and returns a configuration metadata object.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.ConfigurationResourcesApi(mixmode_api.ApiClient(configuration))

try:
    # Queries the system and returns a configuration metadata object.
    api_response = api_instance.get_provider_configuration_resources()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ConfigurationResourcesApi->get_provider_configuration_resources: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ConfigurationResource**](ConfigurationResource.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

