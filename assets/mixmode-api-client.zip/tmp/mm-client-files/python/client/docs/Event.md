# Event

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Unique Identifier representing a document | 
**created_at** | **datetime** | Creation timestamp | [optional] 
**updated_at** | **datetime** | Update timestamp | [optional] 
**event_id** | **int** |  | 
**event_title** | **str** |  | 
**tenant_name** | **str** |  | [optional] 
**tenant_id** | **int** |  | 
**sensor_name** | **str** |  | [optional] 
**sensor_id** | **int** |  | 
**assigned** | **str** |  | [optional] 
**killchain** | **str** |  | [optional] 
**impact** | **str** |  | [optional] 
**labels** | **list[str]** |  | [optional] 
**files** | **list[str]** |  | [optional] 
**affected_hosts** | **list[str]** |  | [optional] 
**status** | **str** |  | [optional] 
**count** | **float** |  | [optional] 
**risk_score** | **float** |  | [optional] 
**impact_score** | **float** |  | [optional] 
**ts** | **float** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


