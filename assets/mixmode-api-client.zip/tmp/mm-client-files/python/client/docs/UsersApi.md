# mixmode_api.UsersApi

All URIs are relative to *https://api.mixmode.ai/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add_user_to_permission**](UsersApi.md#add_user_to_permission) | **POST** /permissions/{PermissionId}/users/{username} | Create or Update a User. If the object has an userId, then an update is performed, otherwise a new object is created.
[**add_user_to_role**](UsersApi.md#add_user_to_role) | **POST** /roles/{RoleId}/users/{username} | Create or Update a User. If the object has an userId, then an update is performed, otherwise a new object is created.
[**authenticate_user**](UsersApi.md#authenticate_user) | **POST** /users/login | Authenticate a user.
[**authenticated_user**](UsersApi.md#authenticated_user) | **GET** /users/current | Return the currently authenticated user.
[**create_user**](UsersApi.md#create_user) | **POST** /users | Create a new user.
[**create_user_configuration**](UsersApi.md#create_user_configuration) | **POST** /users/configurations | Create a new user configuration.
[**delete_user**](UsersApi.md#delete_user) | **DELETE** /users/user/{username} | Delete a single user by unique identifier.
[**delete_user_configuration_from_user**](UsersApi.md#delete_user_configuration_from_user) | **DELETE** /users/configurations/{UserConfigurationId} | Delete a single bookmark by unique identifier.
[**delete_user_from_permission**](UsersApi.md#delete_user_from_permission) | **DELETE** /permissions/{PermissionId}/users/{username} | Delete a single user by unique identifier.
[**delete_user_from_role**](UsersApi.md#delete_user_from_role) | **DELETE** /roles/{RoleId}/users/{username} | Delete a single user by unique identifier.
[**disable_user**](UsersApi.md#disable_user) | **POST** /users/user/{username}/disable | Disable a user.
[**forgot_user_password**](UsersApi.md#forgot_user_password) | **POST** /users/forgot | Request a reset for a users password.
[**get_permission_users**](UsersApi.md#get_permission_users) | **GET** /permissions/{PermissionId}/users | Queries the system and returns a filtered, sorted, paged list of user metadata objects.
[**get_role_users**](UsersApi.md#get_role_users) | **GET** /roles/{RoleId}/users | Queries the system and returns a filtered, sorted, paged list of user metadata objects.
[**get_tenant_admin_users**](UsersApi.md#get_tenant_admin_users) | **GET** /tenants/{TenantId}/users/admin | Queries the system and returns a filtered, sorted, paged list of user metadata objects for users that have admin permissions for this tenant.
[**get_tenant_analyst_users**](UsersApi.md#get_tenant_analyst_users) | **GET** /tenants/{TenantId}/users/analyst | Queries the system and returns a filtered, sorted, paged list of user metadata objects for users that have analyst permissions for this tenant.
[**get_user**](UsersApi.md#get_user) | **GET** /users/user/{username} | Get a single user by unique identifier.
[**get_user_configuration**](UsersApi.md#get_user_configuration) | **GET** /users/configurations/{UserConfigurationId} | Get a user configuration by id.
[**get_user_configurations**](UsersApi.md#get_user_configurations) | **GET** /users/configurations | Queries the system and returns a filtered, sorted, paged list of user configuration metadata objects.
[**get_user_invite_link**](UsersApi.md#get_user_invite_link) | **GET** /users/user/{username}/link | Return the link to give a new or existing user to set or reset their password.
[**get_users**](UsersApi.md#get_users) | **GET** /users | Queries the system and returns a filtered, sorted, paged list of user metadata objects.
[**refresh_user**](UsersApi.md#refresh_user) | **GET** /users/refresh | Refresh a user token by adding 30 days.
[**reset_user_password**](UsersApi.md#reset_user_password) | **POST** /users/reset | Reset a users password.
[**unauthenticate_user**](UsersApi.md#unauthenticate_user) | **POST** /users/logout | Logout a user.
[**update_user**](UsersApi.md#update_user) | **POST** /users/user/{username} | Create or Update a User. If the object has an userId, then an update is performed, otherwise a new object is created.
[**upsert_user_configuration**](UsersApi.md#upsert_user_configuration) | **POST** /users/configurations/{UserConfigurationId} | Create or Update a User Configuration. If the object has an id, then an update is performed, otherwise a new object is created.


# **add_user_to_permission**
> PostResponse add_user_to_permission(username, permission_id)

Create or Update a User. If the object has an userId, then an update is performed, otherwise a new object is created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
username = 'username_example' # str | A User unique identifier.
permission_id = 'permission_id_example' # str | 

try:
    # Create or Update a User. If the object has an userId, then an update is performed, otherwise a new object is created.
    api_response = api_instance.add_user_to_permission(username, permission_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->add_user_to_permission: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **str**| A User unique identifier. | 
 **permission_id** | **str**|  | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **add_user_to_role**
> PostResponse add_user_to_role(username, role_id)

Create or Update a User. If the object has an userId, then an update is performed, otherwise a new object is created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
username = 'username_example' # str | A User unique identifier.
role_id = 'role_id_example' # str | 

try:
    # Create or Update a User. If the object has an userId, then an update is performed, otherwise a new object is created.
    api_response = api_instance.add_user_to_role(username, role_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->add_user_to_role: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **str**| A User unique identifier. | 
 **role_id** | **str**|  | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **authenticate_user**
> ApiToken authenticate_user(user_credentials)

Authenticate a user.

Return a token to be passed in x-mixmode-api-token header for subsequent authorizations.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = mixmode_api.UsersApi()
user_credentials = mixmode_api.UserCredentials() # UserCredentials | A mixmode user credentials.

try:
    # Authenticate a user.
    api_response = api_instance.authenticate_user(user_credentials)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->authenticate_user: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_credentials** | [**UserCredentials**](UserCredentials.md)| A mixmode user credentials. | 

### Return type

[**ApiToken**](ApiToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **authenticated_user**
> User authenticated_user()

Return the currently authenticated user.

Return the currently authenticated user.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))

try:
    # Return the currently authenticated user.
    api_response = api_instance.authenticated_user()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->authenticated_user: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**User**](User.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_user**
> PostResponse create_user(user_with_permissions)

Create a new user.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
user_with_permissions = mixmode_api.UserWithPermissions() # UserWithPermissions | A mixmode user email address and permissions.

try:
    # Create a new user.
    api_response = api_instance.create_user(user_with_permissions)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->create_user: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_with_permissions** | [**UserWithPermissions**](UserWithPermissions.md)| A mixmode user email address and permissions. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_user_configuration**
> UserConfiguration create_user_configuration(configuration)

Create a new user configuration.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
configuration = mixmode_api.UserConfigurationAttributes() # UserConfigurationAttributes | A configuration is a logically related collection of attributes and their values.

try:
    # Create a new user configuration.
    api_response = api_instance.create_user_configuration(configuration)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->create_user_configuration: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **configuration** | [**UserConfigurationAttributes**](UserConfigurationAttributes.md)| A configuration is a logically related collection of attributes and their values. | 

### Return type

[**UserConfiguration**](UserConfiguration.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_user**
> delete_user(username)

Delete a single user by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
username = 'username_example' # str | A User unique identifier.

try:
    # Delete a single user by unique identifier.
    api_instance.delete_user(username)
except ApiException as e:
    print("Exception when calling UsersApi->delete_user: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **str**| A User unique identifier. | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_user_configuration_from_user**
> delete_user_configuration_from_user(user_configuration_id)

Delete a single bookmark by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
user_configuration_id = 'user_configuration_id_example' # str | 

try:
    # Delete a single bookmark by unique identifier.
    api_instance.delete_user_configuration_from_user(user_configuration_id)
except ApiException as e:
    print("Exception when calling UsersApi->delete_user_configuration_from_user: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_configuration_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_user_from_permission**
> delete_user_from_permission(username, permission_id)

Delete a single user by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
username = 'username_example' # str | A User unique identifier.
permission_id = 'permission_id_example' # str | 

try:
    # Delete a single user by unique identifier.
    api_instance.delete_user_from_permission(username, permission_id)
except ApiException as e:
    print("Exception when calling UsersApi->delete_user_from_permission: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **str**| A User unique identifier. | 
 **permission_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_user_from_role**
> delete_user_from_role(username, role_id)

Delete a single user by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
username = 'username_example' # str | A User unique identifier.
role_id = 'role_id_example' # str | 

try:
    # Delete a single user by unique identifier.
    api_instance.delete_user_from_role(username, role_id)
except ApiException as e:
    print("Exception when calling UsersApi->delete_user_from_role: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **str**| A User unique identifier. | 
 **role_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **disable_user**
> PostResponse disable_user(username)

Disable a user.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
username = 'username_example' # str | A User unique identifier.

try:
    # Disable a user.
    api_response = api_instance.disable_user(username)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->disable_user: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **str**| A User unique identifier. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **forgot_user_password**
> PostResponse forgot_user_password(email_address)

Request a reset for a users password.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = mixmode_api.UsersApi()
email_address = mixmode_api.EmailAddress() # EmailAddress | A mixmode user email address.

try:
    # Request a reset for a users password.
    api_response = api_instance.forgot_user_password(email_address)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->forgot_user_password: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **email_address** | [**EmailAddress**](EmailAddress.md)| A mixmode user email address. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_permission_users**
> PagedUserNames get_permission_users(permission_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of user metadata objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
permission_id = 'permission_id_example' # str | 
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of user metadata objects.
    api_response = api_instance.get_permission_users(permission_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->get_permission_users: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **permission_id** | **str**|  | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedUserNames**](PagedUserNames.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_role_users**
> PagedUserNames get_role_users(role_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of user metadata objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
role_id = 'role_id_example' # str | 
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of user metadata objects.
    api_response = api_instance.get_role_users(role_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->get_role_users: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **role_id** | **str**|  | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedUserNames**](PagedUserNames.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_tenant_admin_users**
> PagedUsers get_tenant_admin_users(tenant_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of user metadata objects for users that have admin permissions for this tenant.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of user metadata objects for users that have admin permissions for this tenant.
    api_response = api_instance.get_tenant_admin_users(tenant_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->get_tenant_admin_users: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedUsers**](PagedUsers.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_tenant_analyst_users**
> PagedUsers get_tenant_analyst_users(tenant_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of user metadata objects for users that have analyst permissions for this tenant.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of user metadata objects for users that have analyst permissions for this tenant.
    api_response = api_instance.get_tenant_analyst_users(tenant_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->get_tenant_analyst_users: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedUsers**](PagedUsers.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_user**
> User get_user(username)

Get a single user by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
username = 'username_example' # str | A User unique identifier.

try:
    # Get a single user by unique identifier.
    api_response = api_instance.get_user(username)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->get_user: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **str**| A User unique identifier. | 

### Return type

[**User**](User.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_user_configuration**
> UserConfiguration get_user_configuration(user_configuration_id)

Get a user configuration by id.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
user_configuration_id = 'user_configuration_id_example' # str | 

try:
    # Get a user configuration by id.
    api_response = api_instance.get_user_configuration(user_configuration_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->get_user_configuration: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_configuration_id** | **str**|  | 

### Return type

[**UserConfiguration**](UserConfiguration.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_user_configurations**
> PagedUserConfigurations get_user_configurations(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of user configuration metadata objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of user configuration metadata objects.
    api_response = api_instance.get_user_configurations(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->get_user_configurations: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedUserConfigurations**](PagedUserConfigurations.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_user_invite_link**
> InviteUri get_user_invite_link(username)

Return the link to give a new or existing user to set or reset their password.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
username = 'username_example' # str | A User unique identifier.

try:
    # Return the link to give a new or existing user to set or reset their password.
    api_response = api_instance.get_user_invite_link(username)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->get_user_invite_link: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **str**| A User unique identifier. | 

### Return type

[**InviteUri**](InviteUri.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_users**
> PagedUsers get_users(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of user metadata objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of user metadata objects.
    api_response = api_instance.get_users(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->get_users: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedUsers**](PagedUsers.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **refresh_user**
> ApiToken refresh_user()

Refresh a user token by adding 30 days.

Return a token to be passed in x-mixmode-api-token header for subsequent authorizations.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'
# Configure API key authorization: SensorTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))

try:
    # Refresh a user token by adding 30 days.
    api_response = api_instance.refresh_user()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->refresh_user: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ApiToken**](ApiToken.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity), [SensorTokenSecurity](../README.md#SensorTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **reset_user_password**
> PostResponse reset_user_password(new_password)

Reset a users password.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiParameterTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
new_password = mixmode_api.NewPassword() # NewPassword | Change password for user.

try:
    # Reset a users password.
    api_response = api_instance.reset_user_password(new_password)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->reset_user_password: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **new_password** | [**NewPassword**](NewPassword.md)| Change password for user. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiParameterTokenSecurity](../README.md#ApiParameterTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **unauthenticate_user**
> PostResponse unauthenticate_user()

Logout a user.

End the users session.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))

try:
    # Logout a user.
    api_response = api_instance.unauthenticate_user()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->unauthenticate_user: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_user**
> PostResponse update_user(username, user)

Create or Update a User. If the object has an userId, then an update is performed, otherwise a new object is created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
username = 'username_example' # str | A User unique identifier.
user = mixmode_api.UserAttributes() # UserAttributes | A mixmode user.

try:
    # Create or Update a User. If the object has an userId, then an update is performed, otherwise a new object is created.
    api_response = api_instance.update_user(username, user)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->update_user: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **str**| A User unique identifier. | 
 **user** | [**UserAttributes**](UserAttributes.md)| A mixmode user. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **upsert_user_configuration**
> PostResponse upsert_user_configuration(user_configuration_id, configuration)

Create or Update a User Configuration. If the object has an id, then an update is performed, otherwise a new object is created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.UsersApi(mixmode_api.ApiClient(configuration))
user_configuration_id = 'user_configuration_id_example' # str | 
configuration = mixmode_api.UserConfigurationAttributes() # UserConfigurationAttributes | A configuration is a logically related collection of attributes and their values.

try:
    # Create or Update a User Configuration. If the object has an id, then an update is performed, otherwise a new object is created.
    api_response = api_instance.upsert_user_configuration(user_configuration_id, configuration)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UsersApi->upsert_user_configuration: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_configuration_id** | **str**|  | 
 **configuration** | [**UserConfigurationAttributes**](UserConfigurationAttributes.md)| A configuration is a logically related collection of attributes and their values. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

