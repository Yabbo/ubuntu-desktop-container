# MainsyncBodyV2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**profile_branch** | **str** |  | [optional] 
**profile_hash** | **str** |  | [optional] 
**profile_id** | **str** |  | [optional] 
**profile_url** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


