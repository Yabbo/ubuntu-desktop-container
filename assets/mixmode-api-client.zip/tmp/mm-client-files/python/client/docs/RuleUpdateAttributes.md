# RuleUpdateAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | The name of an object | 
**description** | **str** | A description of an object | [optional] 
**labels** | **list[str]** | A list of labels. | [optional] 
**threshold** | **int** | If query result counts exceed this number, the rule will fire. | 
**threshold_operator** | **str** | The operator to use when comparing threshold with query result count. | [default to 'greater_than']
**enabled** | **bool** | Whether or not rule is disabled. Disabled rules will not execute. | [optional] [default to True]
**data** | [**RuleMetadata**](RuleMetadata.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


