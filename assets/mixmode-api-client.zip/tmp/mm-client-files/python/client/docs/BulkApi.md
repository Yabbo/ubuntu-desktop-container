# mixmode_api.BulkApi

All URIs are relative to *https://api.mixmode.ai/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**acknowledge**](BulkApi.md#acknowledge) | **POST** /search/bulk/acknowledge | Acknowledge the records matching query results.
[**add_labels**](BulkApi.md#add_labels) | **POST** /search/bulk/labels/add | Add labels to records matching query results.
[**assign_to_user**](BulkApi.md#assign_to_user) | **POST** /search/bulk/assign/{username} | Assign user to records matching query results.
[**remove_labels**](BulkApi.md#remove_labels) | **POST** /search/bulk/labels/remove | Remove labels from records matching query results.
[**set_event_status**](BulkApi.md#set_event_status) | **POST** /search/bulk/status/{eventStatus} | Set the status of the matching events.
[**unacknowledge**](BulkApi.md#unacknowledge) | **POST** /search/bulk/unacknowledge | Unacknowledge the records matching query results.
[**unassign_from_user**](BulkApi.md#unassign_from_user) | **POST** /search/bulk/unassign | Unassign (remove) user from records matching query results.


# **acknowledge**
> SearchResults acknowledge(query, timezone, context=context, search_type=search_type)

Acknowledge the records matching query results.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.BulkApi(mixmode_api.ApiClient(configuration))
query = 'query_example' # str | The query, in the mixmode query language.
timezone = 'timezone_example' # str | The timezone for parsing date/time statements in the mixmode query language.
context = [56] # list[int] | A list of sensor ids to query. (optional)
search_type = 'O_NOTIFICATIONS' # str | The data source to query. (optional) (default to O_NOTIFICATIONS)

try:
    # Acknowledge the records matching query results.
    api_response = api_instance.acknowledge(query, timezone, context=context, search_type=search_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BulkApi->acknowledge: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**| The query, in the mixmode query language. | 
 **timezone** | **str**| The timezone for parsing date/time statements in the mixmode query language. | 
 **context** | [**list[int]**](int.md)| A list of sensor ids to query. | [optional] 
 **search_type** | **str**| The data source to query. | [optional] [default to O_NOTIFICATIONS]

### Return type

[**SearchResults**](SearchResults.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **add_labels**
> SearchResults add_labels(query, timezone, labels, context=context, search_type=search_type)

Add labels to records matching query results.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.BulkApi(mixmode_api.ApiClient(configuration))
query = 'query_example' # str | The query, in the mixmode query language.
timezone = 'timezone_example' # str | The timezone for parsing date/time statements in the mixmode query language.
labels = ['labels_example'] # list[str] | A list of labels
context = [56] # list[int] | A list of sensor ids to query. (optional)
search_type = 'O_EVENTS' # str | The data source to query. (optional) (default to O_EVENTS)

try:
    # Add labels to records matching query results.
    api_response = api_instance.add_labels(query, timezone, labels, context=context, search_type=search_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BulkApi->add_labels: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**| The query, in the mixmode query language. | 
 **timezone** | **str**| The timezone for parsing date/time statements in the mixmode query language. | 
 **labels** | [**list[str]**](str.md)| A list of labels | 
 **context** | [**list[int]**](int.md)| A list of sensor ids to query. | [optional] 
 **search_type** | **str**| The data source to query. | [optional] [default to O_EVENTS]

### Return type

[**SearchResults**](SearchResults.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **assign_to_user**
> SearchResults assign_to_user(query, timezone, username, context=context, search_type=search_type)

Assign user to records matching query results.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.BulkApi(mixmode_api.ApiClient(configuration))
query = 'query_example' # str | The query, in the mixmode query language.
timezone = 'timezone_example' # str | The timezone for parsing date/time statements in the mixmode query language.
username = 'username_example' # str | A User unique identifier.
context = [56] # list[int] | A list of sensor ids to query. (optional)
search_type = 'O_EVENTS' # str | The data source to query. (optional) (default to O_EVENTS)

try:
    # Assign user to records matching query results.
    api_response = api_instance.assign_to_user(query, timezone, username, context=context, search_type=search_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BulkApi->assign_to_user: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**| The query, in the mixmode query language. | 
 **timezone** | **str**| The timezone for parsing date/time statements in the mixmode query language. | 
 **username** | **str**| A User unique identifier. | 
 **context** | [**list[int]**](int.md)| A list of sensor ids to query. | [optional] 
 **search_type** | **str**| The data source to query. | [optional] [default to O_EVENTS]

### Return type

[**SearchResults**](SearchResults.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **remove_labels**
> SearchResults remove_labels(query, timezone, labels, context=context, search_type=search_type)

Remove labels from records matching query results.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.BulkApi(mixmode_api.ApiClient(configuration))
query = 'query_example' # str | The query, in the mixmode query language.
timezone = 'timezone_example' # str | The timezone for parsing date/time statements in the mixmode query language.
labels = ['labels_example'] # list[str] | A list of labels
context = [56] # list[int] | A list of sensor ids to query. (optional)
search_type = 'O_EVENTS' # str | The data source to query. (optional) (default to O_EVENTS)

try:
    # Remove labels from records matching query results.
    api_response = api_instance.remove_labels(query, timezone, labels, context=context, search_type=search_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BulkApi->remove_labels: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**| The query, in the mixmode query language. | 
 **timezone** | **str**| The timezone for parsing date/time statements in the mixmode query language. | 
 **labels** | [**list[str]**](str.md)| A list of labels | 
 **context** | [**list[int]**](int.md)| A list of sensor ids to query. | [optional] 
 **search_type** | **str**| The data source to query. | [optional] [default to O_EVENTS]

### Return type

[**SearchResults**](SearchResults.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_event_status**
> SearchResults set_event_status(query, timezone, event_status)

Set the status of the matching events.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.BulkApi(mixmode_api.ApiClient(configuration))
query = 'query_example' # str | The query, in the mixmode query language.
timezone = 'timezone_example' # str | The timezone for parsing date/time statements in the mixmode query language.
event_status = 'event_status_example' # str | Status of event.

try:
    # Set the status of the matching events.
    api_response = api_instance.set_event_status(query, timezone, event_status)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BulkApi->set_event_status: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**| The query, in the mixmode query language. | 
 **timezone** | **str**| The timezone for parsing date/time statements in the mixmode query language. | 
 **event_status** | **str**| Status of event. | 

### Return type

[**SearchResults**](SearchResults.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **unacknowledge**
> SearchResults unacknowledge(query, timezone, context=context, search_type=search_type)

Unacknowledge the records matching query results.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.BulkApi(mixmode_api.ApiClient(configuration))
query = 'query_example' # str | The query, in the mixmode query language.
timezone = 'timezone_example' # str | The timezone for parsing date/time statements in the mixmode query language.
context = [56] # list[int] | A list of sensor ids to query. (optional)
search_type = 'O_NOTIFICATIONS' # str | The data source to query. (optional) (default to O_NOTIFICATIONS)

try:
    # Unacknowledge the records matching query results.
    api_response = api_instance.unacknowledge(query, timezone, context=context, search_type=search_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BulkApi->unacknowledge: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**| The query, in the mixmode query language. | 
 **timezone** | **str**| The timezone for parsing date/time statements in the mixmode query language. | 
 **context** | [**list[int]**](int.md)| A list of sensor ids to query. | [optional] 
 **search_type** | **str**| The data source to query. | [optional] [default to O_NOTIFICATIONS]

### Return type

[**SearchResults**](SearchResults.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **unassign_from_user**
> SearchResults unassign_from_user(query, timezone, context=context, search_type=search_type)

Unassign (remove) user from records matching query results.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.BulkApi(mixmode_api.ApiClient(configuration))
query = 'query_example' # str | The query, in the mixmode query language.
timezone = 'timezone_example' # str | The timezone for parsing date/time statements in the mixmode query language.
context = [56] # list[int] | A list of sensor ids to query. (optional)
search_type = 'O_EVENTS' # str | The data source to query. (optional) (default to O_EVENTS)

try:
    # Unassign (remove) user from records matching query results.
    api_response = api_instance.unassign_from_user(query, timezone, context=context, search_type=search_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BulkApi->unassign_from_user: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**| The query, in the mixmode query language. | 
 **timezone** | **str**| The timezone for parsing date/time statements in the mixmode query language. | 
 **context** | [**list[int]**](int.md)| A list of sensor ids to query. | [optional] 
 **search_type** | **str**| The data source to query. | [optional] [default to O_EVENTS]

### Return type

[**SearchResults**](SearchResults.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

