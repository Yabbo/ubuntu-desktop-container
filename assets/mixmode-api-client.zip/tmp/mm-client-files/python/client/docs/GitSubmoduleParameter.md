# GitSubmoduleParameter

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | The name of the submodule. | 
**path** | **str** | The relative path from the root of the repository where the submodule should be created. | 
**profile_id** | **int** | The remote URL for the submodule. When adding an internal SMF profile as a submodule, use the profile ID as the URL. | 
**branch** | **str** | The branch for the submodule. Default is master | [optional] [default to 'master']

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


