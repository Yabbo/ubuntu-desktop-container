# IndicatorOverride

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Unique Identifier representing a document | 
**created_at** | **datetime** | Creation timestamp | [optional] 
**updated_at** | **datetime** | Update timestamp | [optional] 
**name** | **str** | The name of an object | 
**description** | **str** | A description of an object | [optional] 
**labels** | **list[str]** | A list of labels. | [optional] 
**enabled** | **bool** | Whether or not override is disabled. Disabled overrides will not execute. | [default to True]
**log** | **str** | The pattern to match in the log field of the indicator. | 
**key** | **str** | The pattern to match in the key field of the indicator. | 
**value** | **str** | The pattern to match in the value field of the indicator. | 
**severity** | **int** | The value to set the severity of the indicator to. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


