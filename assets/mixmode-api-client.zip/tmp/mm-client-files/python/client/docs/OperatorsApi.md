# mixmode_api.OperatorsApi

All URIs are relative to *https://api.mixmode.ai/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**delete_sensor_operator_override**](OperatorsApi.md#delete_sensor_operator_override) | **DELETE** /tenants/{TenantId}/smf/sensors/{SensorId}/operators/{OperatorId} | Delete a sensor operator override by unique identifier.
[**get_sensor_operator_overrides**](OperatorsApi.md#get_sensor_operator_overrides) | **GET** /tenants/{TenantId}/smf/sensors/{SensorId}/operators | Return all operators assigned to this sensor.
[**update_sensor_operator_override**](OperatorsApi.md#update_sensor_operator_override) | **POST** /tenants/{TenantId}/smf/sensors/{SensorId}/operators/{OperatorId} | Configure an operator behavior for a specific sensor.


# **delete_sensor_operator_override**
> delete_sensor_operator_override(tenant_id, sensor_id, operator_id)

Delete a sensor operator override by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.OperatorsApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
operator_id = 'operator_id_example' # str | An operator unique identifier.

try:
    # Delete a sensor operator override by unique identifier.
    api_instance.delete_sensor_operator_override(tenant_id, sensor_id, operator_id)
except ApiException as e:
    print("Exception when calling OperatorsApi->delete_sensor_operator_override: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **operator_id** | **str**| An operator unique identifier. | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_sensor_operator_overrides**
> PagedSensorOperatorOverrides get_sensor_operator_overrides(tenant_id, sensor_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Return all operators assigned to this sensor.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.OperatorsApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Return all operators assigned to this sensor.
    api_response = api_instance.get_sensor_operator_overrides(tenant_id, sensor_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OperatorsApi->get_sensor_operator_overrides: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedSensorOperatorOverrides**](PagedSensorOperatorOverrides.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_sensor_operator_override**
> PostResponse update_sensor_operator_override(tenant_id, sensor_id, operator_id, sensor_operator_override_body_parameter)

Configure an operator behavior for a specific sensor.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.OperatorsApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
operator_id = 'operator_id_example' # str | An operator unique identifier.
sensor_operator_override_body_parameter = mixmode_api.SensorOperatorOverrideBodyParameter() # SensorOperatorOverrideBodyParameter | An operator override configures the behavior of ai for a specific sensor.

try:
    # Configure an operator behavior for a specific sensor.
    api_response = api_instance.update_sensor_operator_override(tenant_id, sensor_id, operator_id, sensor_operator_override_body_parameter)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OperatorsApi->update_sensor_operator_override: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **operator_id** | **str**| An operator unique identifier. | 
 **sensor_operator_override_body_parameter** | [**SensorOperatorOverrideBodyParameter**](SensorOperatorOverrideBodyParameter.md)| An operator override configures the behavior of ai for a specific sensor. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

