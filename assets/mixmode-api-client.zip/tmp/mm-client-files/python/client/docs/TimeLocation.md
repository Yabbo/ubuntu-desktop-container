# TimeLocation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cache_end** | **int** |  | [optional] 
**cache_start** | **int** |  | [optional] 
**cache_zone** | [**Timezone**](Timezone.md) |  | [optional] 
**name** | **str** |  | [optional] 
**tx** | [**list[TimezoneTrans]**](TimezoneTrans.md) |  | [optional] 
**zone** | [**list[Timezone]**](Timezone.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


