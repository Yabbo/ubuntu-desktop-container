# DiskUsageStat

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**free** | **int** |  | [optional] 
**fstype** | **str** |  | [optional] 
**inodes_free** | **int** |  | [optional] 
**inodes_total** | **int** |  | [optional] 
**inodes_used** | **int** |  | [optional] 
**inodes_used_percent** | **float** |  | [optional] 
**path** | **str** |  | [optional] 
**total** | **int** |  | [optional] 
**used** | **int** |  | [optional] 
**used_percent** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


