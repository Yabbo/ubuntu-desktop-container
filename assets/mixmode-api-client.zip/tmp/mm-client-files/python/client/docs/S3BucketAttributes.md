# S3BucketAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**provider_id** | **int** | provider id | [optional] 
**tenant_id** | **int** | tenant id | [optional] 
**bucket_name** | **str** | bucket name | 
**file** | **str** | path to file in bucket | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


