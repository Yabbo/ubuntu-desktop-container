# GitCheckout

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parameters** | **list[str]** | A list of parameters | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


