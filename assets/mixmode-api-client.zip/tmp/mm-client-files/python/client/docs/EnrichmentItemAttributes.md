# EnrichmentItemAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pattern** | **str** | The pattern to match in the data. | 
**type** | **str** | The pattern to match in the data. | [default to 'IPV4']
**severity** | **int** | The asset severity score assigned to items that match this pattern | [optional] 
**labels** | **list[str]** | A list of labels. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


