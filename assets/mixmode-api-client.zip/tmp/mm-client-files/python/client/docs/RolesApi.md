# mixmode_api.RolesApi

All URIs are relative to *https://api.mixmode.ai/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add_role_to_user**](RolesApi.md#add_role_to_user) | **POST** /users/user/{username}/roles/{RoleId} | Create or Update a Role. If the object has an RoleId, then an update is performed, otherwise a new object is created.
[**add_user_to_role**](RolesApi.md#add_user_to_role) | **POST** /roles/{RoleId}/users/{username} | Create or Update a User. If the object has an userId, then an update is performed, otherwise a new object is created.
[**create_role**](RolesApi.md#create_role) | **POST** /roles | Create a new role.
[**delete_role**](RolesApi.md#delete_role) | **DELETE** /roles/{RoleId} | Delete a single role by unique identifier.
[**delete_role_from_user**](RolesApi.md#delete_role_from_user) | **DELETE** /users/user/{username}/roles/{RoleId} | Delete a single role by unique identifier.
[**delete_user_from_role**](RolesApi.md#delete_user_from_role) | **DELETE** /roles/{RoleId}/users/{username} | Delete a single user by unique identifier.
[**get_role**](RolesApi.md#get_role) | **GET** /roles/{RoleId} | Get a single role by unique identifier.
[**get_role_users**](RolesApi.md#get_role_users) | **GET** /roles/{RoleId}/users | Queries the system and returns a filtered, sorted, paged list of user metadata objects.
[**get_roles**](RolesApi.md#get_roles) | **GET** /roles | Queries the system and returns a filtered, sorted, paged list of role metadata objects.
[**get_user_roles**](RolesApi.md#get_user_roles) | **GET** /users/user/{username}/roles | Queries the system and returns a filtered, sorted, paged list of role metadata objects.
[**upsert_role**](RolesApi.md#upsert_role) | **POST** /roles/{RoleId} | Create or Update a Role. If the object has an RoleId, then an update is performed, otherwise a new object is created.


# **add_role_to_user**
> PostResponse add_role_to_user(username, role_id)

Create or Update a Role. If the object has an RoleId, then an update is performed, otherwise a new object is created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.RolesApi(mixmode_api.ApiClient(configuration))
username = 'username_example' # str | A User unique identifier.
role_id = 'role_id_example' # str | 

try:
    # Create or Update a Role. If the object has an RoleId, then an update is performed, otherwise a new object is created.
    api_response = api_instance.add_role_to_user(username, role_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RolesApi->add_role_to_user: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **str**| A User unique identifier. | 
 **role_id** | **str**|  | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **add_user_to_role**
> PostResponse add_user_to_role(username, role_id)

Create or Update a User. If the object has an userId, then an update is performed, otherwise a new object is created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.RolesApi(mixmode_api.ApiClient(configuration))
username = 'username_example' # str | A User unique identifier.
role_id = 'role_id_example' # str | 

try:
    # Create or Update a User. If the object has an userId, then an update is performed, otherwise a new object is created.
    api_response = api_instance.add_user_to_role(username, role_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RolesApi->add_user_to_role: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **str**| A User unique identifier. | 
 **role_id** | **str**|  | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_role**
> Role create_role(group)

Create a new role.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.RolesApi(mixmode_api.ApiClient(configuration))
group = mixmode_api.RoleAttributes() # RoleAttributes | A group is a logically related collection of users.

try:
    # Create a new role.
    api_response = api_instance.create_role(group)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RolesApi->create_role: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group** | [**RoleAttributes**](RoleAttributes.md)| A group is a logically related collection of users. | 

### Return type

[**Role**](Role.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_role**
> delete_role(role_id)

Delete a single role by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.RolesApi(mixmode_api.ApiClient(configuration))
role_id = 'role_id_example' # str | 

try:
    # Delete a single role by unique identifier.
    api_instance.delete_role(role_id)
except ApiException as e:
    print("Exception when calling RolesApi->delete_role: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **role_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_role_from_user**
> delete_role_from_user(username, role_id)

Delete a single role by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.RolesApi(mixmode_api.ApiClient(configuration))
username = 'username_example' # str | A User unique identifier.
role_id = 'role_id_example' # str | 

try:
    # Delete a single role by unique identifier.
    api_instance.delete_role_from_user(username, role_id)
except ApiException as e:
    print("Exception when calling RolesApi->delete_role_from_user: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **str**| A User unique identifier. | 
 **role_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_user_from_role**
> delete_user_from_role(username, role_id)

Delete a single user by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.RolesApi(mixmode_api.ApiClient(configuration))
username = 'username_example' # str | A User unique identifier.
role_id = 'role_id_example' # str | 

try:
    # Delete a single user by unique identifier.
    api_instance.delete_user_from_role(username, role_id)
except ApiException as e:
    print("Exception when calling RolesApi->delete_user_from_role: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **str**| A User unique identifier. | 
 **role_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_role**
> Role get_role(role_id)

Get a single role by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.RolesApi(mixmode_api.ApiClient(configuration))
role_id = 'role_id_example' # str | 

try:
    # Get a single role by unique identifier.
    api_response = api_instance.get_role(role_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RolesApi->get_role: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **role_id** | **str**|  | 

### Return type

[**Role**](Role.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_role_users**
> PagedUserNames get_role_users(role_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of user metadata objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.RolesApi(mixmode_api.ApiClient(configuration))
role_id = 'role_id_example' # str | 
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of user metadata objects.
    api_response = api_instance.get_role_users(role_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RolesApi->get_role_users: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **role_id** | **str**|  | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedUserNames**](PagedUserNames.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_roles**
> PagedRoles get_roles(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of role metadata objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.RolesApi(mixmode_api.ApiClient(configuration))
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of role metadata objects.
    api_response = api_instance.get_roles(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RolesApi->get_roles: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedRoles**](PagedRoles.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_user_roles**
> PagedRoles get_user_roles(username, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of role metadata objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.RolesApi(mixmode_api.ApiClient(configuration))
username = 'username_example' # str | A User unique identifier.
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of role metadata objects.
    api_response = api_instance.get_user_roles(username, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RolesApi->get_user_roles: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **str**| A User unique identifier. | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedRoles**](PagedRoles.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **upsert_role**
> PostResponse upsert_role(role_id, group)

Create or Update a Role. If the object has an RoleId, then an update is performed, otherwise a new object is created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.RolesApi(mixmode_api.ApiClient(configuration))
role_id = 'role_id_example' # str | 
group = mixmode_api.RoleAttributes() # RoleAttributes | A group is a logically related collection of users.

try:
    # Create or Update a Role. If the object has an RoleId, then an update is performed, otherwise a new object is created.
    api_response = api_instance.upsert_role(role_id, group)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RolesApi->upsert_role: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **role_id** | **str**|  | 
 **group** | [**RoleAttributes**](RoleAttributes.md)| A group is a logically related collection of users. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

