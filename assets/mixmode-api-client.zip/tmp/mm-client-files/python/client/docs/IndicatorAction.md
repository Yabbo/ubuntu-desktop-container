# IndicatorAction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**killchain** | **str** |  | [optional] 
**severity** | **float** |  | [optional] 
**impact** | **str** |  | [optional] 
**labels** | **list[str]** |  | [optional] 
**data** | [**IndicatorActionData**](IndicatorActionData.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


