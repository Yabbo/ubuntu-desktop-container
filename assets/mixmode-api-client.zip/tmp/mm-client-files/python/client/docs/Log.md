# Log

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**log_id** | **str** |  | 
**log_title** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


