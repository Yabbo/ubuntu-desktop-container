# MaindirBodyV2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **str** |  | [optional] 
**pagenum** | **int** |  | [optional] 
**pagesize** | **int** |  | [optional] 
**sortdatafield** | **str** |  | [optional] 
**sortorder** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


