# UserWithPermissions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **str** |  | 
**permissions** | [**list[Permission]**](Permission.md) | An array of permissions. | [optional] 
**roles** | [**list[Role]**](Role.md) | An array of roles. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


