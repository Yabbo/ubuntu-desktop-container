# AWSSensorTransportV1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** | The type of transport. | [optional] [default to 'aws_v1']
**delivery_stream_location** | **str** | AWS transport ID. | 
**aws_access_key_id** | **str** | AWS credentials. | 
**aws_secret_access_key** | **str** | AWS credentials. | 
**aws_region** | **str** | AWS credentials. | 
**aws_s3_sensor_bucket** | **str** | AWS s3 bucket. | 
**aws_session_token** | **str** | AWS session token. | [optional] 
**aws_session_token_expire** | **str** | AWS session token expiration time. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


