# UserAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **str** |  | 
**data** | **object** | Data for the User. | [optional] 
**last_login_timestamp** | **datetime** |  | [optional] 
**verified** | **bool** |  | [optional] 
**pwd_reset** | **bool** |  | [optional] 
**password_hash** | **str** |  | [optional] 
**controls** | **list[str]** | An array of controls. | [optional] 
**permissions** | [**list[Permission]**](Permission.md) | An array of permissions. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


