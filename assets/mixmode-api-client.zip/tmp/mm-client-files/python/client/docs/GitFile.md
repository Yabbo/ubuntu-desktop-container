# GitFile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**path** | **str** | A relative path to a file, including the filename, from the root of the repository. | 
**stats** | **object** | A stats object describing the files attributes (size, mtime, atime, etc). | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


