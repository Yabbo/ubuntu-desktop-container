# Killchain

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | The name of an object | 
**description** | **str** | A description of an object | [optional] 
**labels** | **list[str]** | A list of labels. | [optional] 
**mitre_id** | **str** | the mitre id of this object. | 
**mitre_tactic_id** | **str** | the mitre external id of this object. | [optional] 
**mitre_tactic_description** | **str** | the mitre description of this object. | [optional] 
**mitre_tactic_url** | **str** | the mitre external URL of this object. | [optional] 
**data** | **object** | The raw mitre data. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


