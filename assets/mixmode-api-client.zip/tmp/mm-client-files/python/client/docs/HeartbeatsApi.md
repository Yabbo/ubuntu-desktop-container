# mixmode_api.HeartbeatsApi

All URIs are relative to *https://api.mixmode.ai/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_sensor_heartbeat**](HeartbeatsApi.md#create_sensor_heartbeat) | **POST** /tenants/{TenantId}/smf/sensors/{SensorId}/heartbeats | Accept a sensor heartbeat from a sensor.
[**get_sensor_heartbeats**](HeartbeatsApi.md#get_sensor_heartbeats) | **GET** /tenants/{TenantId}/smf/sensors/{SensorId}/heartbeats | Return all heartbeats emitted from this sensor.


# **create_sensor_heartbeat**
> PostResponse create_sensor_heartbeat(tenant_id, sensor_id, sensor_heartbeat)

Accept a sensor heartbeat from a sensor.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'
# Configure API key authorization: SensorTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.HeartbeatsApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
sensor_heartbeat = mixmode_api.Heartbeat() # Heartbeat | A mixmode sensor heartbeat containing status information.

try:
    # Accept a sensor heartbeat from a sensor.
    api_response = api_instance.create_sensor_heartbeat(tenant_id, sensor_id, sensor_heartbeat)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling HeartbeatsApi->create_sensor_heartbeat: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **sensor_heartbeat** | [**Heartbeat**](Heartbeat.md)| A mixmode sensor heartbeat containing status information. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity), [SensorTokenSecurity](../README.md#SensorTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_sensor_heartbeats**
> PagedSensorHeartbeats get_sensor_heartbeats(tenant_id, sensor_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Return all heartbeats emitted from this sensor.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'
# Configure API key authorization: SensorTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.HeartbeatsApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Return all heartbeats emitted from this sensor.
    api_response = api_instance.get_sensor_heartbeats(tenant_id, sensor_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling HeartbeatsApi->get_sensor_heartbeats: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedSensorHeartbeats**](PagedSensorHeartbeats.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity), [SensorTokenSecurity](../README.md#SensorTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

