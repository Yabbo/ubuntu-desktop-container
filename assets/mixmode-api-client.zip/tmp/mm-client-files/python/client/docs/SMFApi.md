# mixmode_api.SMFApi

All URIs are relative to *https://api.mixmode.ai/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apply_profile_updates**](SMFApi.md#apply_profile_updates) | **POST** /tenants/{TenantId}/smf/updates | Apply all upstream changes to the selected profiles.
[**check_for_upstream_updates**](SMFApi.md#check_for_upstream_updates) | **POST** /tenants/{TenantId}/smf/update | Get upstream updates for all profiles. They will show up as available updates in any local profiles.
[**checkout_draft_file**](SMFApi.md#checkout_draft_file) | **POST** /tenants/{TenantId}/smf/drafts/{DraftId}/checkout | Checkout a file or path.
[**commit_draft**](SMFApi.md#commit_draft) | **POST** /tenants/{TenantId}/smf/drafts/{DraftId}/commit | Save changes made to this draft. Following this call, &#39;status&#39; will show no changes, and &#39;log&#39; will contain a new entry indicating what was saved and any message associated with the commit operation. Has no affect on the profile from which this draft was created.
[**create_profile**](SMFApi.md#create_profile) | **POST** /tenants/{TenantId}/smf/{profileType} | Create a new profile.
[**create_profile_draft**](SMFApi.md#create_profile_draft) | **POST** /tenants/{TenantId}/smf/profiles/{ProfileId}/drafts | Begin editing a draft
[**create_sensor**](SMFApi.md#create_sensor) | **POST** /tenants/{TenantId}/smf/sensors | Create a new sensor.
[**delete_draft**](SMFApi.md#delete_draft) | **DELETE** /tenants/{TenantId}/smf/drafts/{DraftId} | Permanently delete a draft. Will have no affect on the profile from which the draft was created.
[**delete_draft_file**](SMFApi.md#delete_draft_file) | **DELETE** /tenants/{TenantId}/smf/drafts/{DraftId}/files | Permanently remove a file from a draft based on it&#39;s relative path (&#39;*&#39;) from the root of the draft.
[**delete_profile**](SMFApi.md#delete_profile) | **DELETE** /tenants/{TenantId}/smf/profiles/{ProfileId} | Permanently delete a Profile and all of it&#39;s metadata.
[**delete_sensor**](SMFApi.md#delete_sensor) | **DELETE** /tenants/{TenantId}/smf/sensors/{SensorId} | Delete a single Sensor by unique identifier.
[**delete_submodule**](SMFApi.md#delete_submodule) | **DELETE** /tenants/{TenantId}/smf/drafts/{DraftId}/submodules | Permanently remove the profile referenced by the submodule from the draft.
[**diff_draft**](SMFApi.md#diff_draft) | **GET** /tenants/{TenantId}/smf/drafts/{DraftId}/diff | Check for upstream changes.
[**diff_profile**](SMFApi.md#diff_profile) | **GET** /tenants/{TenantId}/smf/profiles/{ProfileId}/diff | Check for upstream changes.
[**finalize_draft**](SMFApi.md#finalize_draft) | **POST** /tenants/{TenantId}/smf/drafts/{DraftId}/finalize | Commits all changes, performs an extensive validation test, and if validation succeeds, permanently merges the changes made to this draft into the profile from which it was created and deletes the draft. Following this call, if it succeeds, the draft unique identifier will no longer be valid.
[**fork_profile**](SMFApi.md#fork_profile) | **POST** /tenants/{TenantId}/smf/profiles/{ProfileId}/fork | Create a copy of a profile.
[**form_draft_file_upload**](SMFApi.md#form_draft_file_upload) | **POST** /tenants/{TenantId}/smf/drafts/{DraftId}/formupload | Form file upload. Accepts a form file upload named &#39;file&#39;.
[**get_all_profile_updates**](SMFApi.md#get_all_profile_updates) | **GET** /updates | Get a list of all profiles that have upstream changes.
[**get_all_profiles**](SMFApi.md#get_all_profiles) | **GET** /profiles | Queries the system and returns a filtered, sorted, paged list of Profile metadata objects.
[**get_all_sensors**](SMFApi.md#get_all_sensors) | **GET** /sensors | Queries the system and returns a filtered, sorted, paged list of sensor metadata objects.
[**get_dns_request**](SMFApi.md#get_dns_request) | **GET** /tenants/{TenantId}/smf/sensors/{SensorId}/dnsproxy | Proxy Sensor DNS requests through the platform API.
[**get_draft_file**](SMFApi.md#get_draft_file) | **GET** /tenants/{TenantId}/smf/drafts/{DraftId}/files | Retrieve the contents of a file based on it&#39;s relative path (&#39;*&#39;) from the root of the draft.
[**get_draft_file_list**](SMFApi.md#get_draft_file_list) | **GET** /tenants/{TenantId}/smf/drafts/{DraftId}/ls | Recursively list the files beneath a path &#39;*&#39; in the current draft. Return a filtered, sorted, paged list of file metadata objects.
[**get_draft_status**](SMFApi.md#get_draft_status) | **GET** /tenants/{TenantId}/smf/drafts/{DraftId}/status | Return a list of changes made to the draft since it was created from a profile. This is effetively the differences between the draft and the profile from which it was created.
[**get_draft_submodules**](SMFApi.md#get_draft_submodules) | **GET** /tenants/{TenantId}/smf/drafts/{DraftId}/submodules | Get Submodules
[**get_profile**](SMFApi.md#get_profile) | **GET** /tenants/{TenantId}/smf/profiles/{ProfileId} | Retrieve the metadata for a Profile by unique identifier.
[**get_profile_drafts**](SMFApi.md#get_profile_drafts) | **GET** /tenants/{TenantId}/smf/profiles/{ProfileId}/drafts | Return a filtered, sorted, paged list of draft metadata objects for drafts associated with this profile and the current logged on api user. Note that the profile metadata objects will also include a draftId attribute containing the id of any drafts for this profile that belong to the currently authenticated api user.
[**get_profile_file**](SMFApi.md#get_profile_file) | **GET** /tenants/{TenantId}/smf/profiles/{ProfileId}/files | Retrieve the contents of a file based on it&#39;s relative path (&#39;*&#39;) from the root of the profile.
[**get_profile_submodules**](SMFApi.md#get_profile_submodules) | **GET** /tenants/{TenantId}/smf/profiles/{ProfileId}/submodules | Return a filtered, sorted, paged list of submodule metadata objects for submodules that have been added to this profile.
[**get_profile_updates**](SMFApi.md#get_profile_updates) | **GET** /tenants/{TenantId}/smf/updates | Get a list of all profiles that have upstream changes.
[**get_profiles**](SMFApi.md#get_profiles) | **GET** /tenants/{TenantId}/smf/profiles | Queries the system and returns a filtered, sorted, paged list of Profile metadata objects.
[**get_profiles_by_type**](SMFApi.md#get_profiles_by_type) | **GET** /tenants/{TenantId}/smf/{profileType} | Queries the system by profile type and returns a filtered, sorted, paged list of Profile metadata objects.
[**get_sensor**](SMFApi.md#get_sensor) | **GET** /tenants/{TenantId}/smf/sensors/{SensorId} | Get a single Sensor by unique identifier.
[**get_sensor_configuration**](SMFApi.md#get_sensor_configuration) | **GET** /tenants/{TenantId}/smf/sensors/{SensorId}/configuration | Get initial sensor configuration. Call this method when you have deployed a sensor and added the sensor to the API. This method will return data that is used to provision the deployed sensor to make it operational with the mixmode platform.
[**get_sensor_file_proxy**](SMFApi.md#get_sensor_file_proxy) | **GET** /tenants/{TenantId}/smf/sensors/{SensorId}/file/download | Sensor api proxy.
[**get_sensors**](SMFApi.md#get_sensors) | **GET** /tenants/{TenantId}/smf/sensors | Queries the system and returns a filtered, sorted, paged list of sensor metadata objects.
[**get_smf_archive**](SMFApi.md#get_smf_archive) | **GET** /tenants/{TenantId}/smf/sensors/{SensorId}/archive | Get a tarfile containing the SMF profile for a specific sensor.  Removes the need to &#39;git clone&#39; in the sensor.
[**get_templates**](SMFApi.md#get_templates) | **GET** /tenants/{TenantId}/smf/templates | Returns all of the available templates available for profile creation.
[**get_wss_connection**](SMFApi.md#get_wss_connection) | **GET** /tenants/{TenantId}/smf/sensors/{SensorId}/wss_connect | Create a new WebSocket Server connection
[**lint_draft_file**](SMFApi.md#lint_draft_file) | **GET** /tenants/{TenantId}/smf/drafts/{DraftId}/lint/{lintType} | Perform validation of individual files based on their relative path (&#39;*&#39;) from the root of a draft. Returns a result indicating whether or not the referenced file passes the chosen validation.
[**list_profile_files**](SMFApi.md#list_profile_files) | **GET** /tenants/{TenantId}/smf/profiles/{ProfileId}/ls | Recursively list the files beneath a path &#39;*&#39; in the current profile. Return a filtered, sorted, paged list of file metadata objects.
[**log_draft**](SMFApi.md#log_draft) | **GET** /tenants/{TenantId}/smf/drafts/{DraftId}/log | Show a log of changes committed to the draft since it was created.
[**log_profile**](SMFApi.md#log_profile) | **GET** /tenants/{TenantId}/smf/profiles/{ProfileId}/log | Return a filtered, sorted, paged list of changes that have been applied to this profile since it was created.
[**move_draft_file**](SMFApi.md#move_draft_file) | **POST** /tenants/{TenantId}/smf/drafts/{DraftId}/move | Move a file from one directory to another.
[**processor_draft_file**](SMFApi.md#processor_draft_file) | **POST** /tenants/{TenantId}/smf/drafts/{DraftId}/processor/{processorType} | Perform processing of the file. This can be any transformation supported by the api.
[**push_draft**](SMFApi.md#push_draft) | **POST** /tenants/{TenantId}/smf/drafts/{DraftId}/push | Send any committed changes made to this draft up to the server where the draft is stored.
[**set_sensor_mode**](SMFApi.md#set_sensor_mode) | **POST** /tenants/{TenantId}/smf/sensors/{SensorId}/mode/{SensorMode} | Put the sensor into an operational mode.
[**set_sensor_profile**](SMFApi.md#set_sensor_profile) | **POST** /tenants/{TenantId}/smf/sensors/{SensorId}/profile/{ProfileId} | Associate a Profile with a sensor. Only a single profile can be associated with a sensor, and this profile should be of type &#39;sensor&#39;. Composition of profiles is handled by nesting additional profiles (as submodules) within the &#39;sensor&#39; profile.
[**set_upload_type**](SMFApi.md#set_upload_type) | **POST** /tenants/{TenantId}/smf/sensors/{SensorId}/upload/{UploadType} | Upload log files from a sensor.
[**sync_sensor**](SMFApi.md#sync_sensor) | **POST** /tenants/{TenantId}/smf/sensors/{SensorId}/sync | Sends a message to the sensor to update from the latest profile version stored on the server. Use this command when you have made changes to a profile and want those changes to be pushed to any affected sensors.
[**unset_sensor_profile**](SMFApi.md#unset_sensor_profile) | **DELETE** /tenants/{TenantId}/smf/sensors/{SensorId}/profile | Remove any profile from a sensor. This will make the sensor inoperational. A sensor should always have a profile associated with it to operate correctly.
[**update_draft**](SMFApi.md#update_draft) | **POST** /tenants/{TenantId}/smf/drafts/{DraftId}/update | Merge upstream changes into this draft. This is how to receive updates from MixMode.
[**update_draft_submodules**](SMFApi.md#update_draft_submodules) | **POST** /tenants/{TenantId}/smf/drafts/{DraftId}/updatesubmodules | Get the latest version of all submodules.
[**update_profile**](SMFApi.md#update_profile) | **POST** /tenants/{TenantId}/smf/profiles/{ProfileId}/update | Merge upstream changes into this profile. This is how to receive updates from MixMode.
[**upload_draft_archive**](SMFApi.md#upload_draft_archive) | **POST** /tenants/{TenantId}/smf/drafts/{DraftId}/archive | Upload an archive file to a path (&#39;*&#39;) relative to the root of the draft. The archive will be extracted into the path. This is the standard way to introduce new files into a profile.
[**upsert_draft_file**](SMFApi.md#upsert_draft_file) | **POST** /tenants/{TenantId}/smf/drafts/{DraftId}/files | Upload the file contents to a path (&#39;*&#39;) relative to the root of the draft. This is the standard way to introduce new files and/or update existing files into a profile.
[**upsert_draft_file_upload**](SMFApi.md#upsert_draft_file_upload) | **POST** /tenants/{TenantId}/smf/drafts/{DraftId}/upload | Upload a file to a path (&#39;*&#39;) relative to the root of the draft. This is the standard way to introduce new files into a profile.
[**upsert_draft_submodule**](SMFApi.md#upsert_draft_submodule) | **POST** /tenants/{TenantId}/smf/drafts/{DraftId}/submodules | Add a submodule
[**upsert_profile**](SMFApi.md#upsert_profile) | **POST** /tenants/{TenantId}/smf/profiles/{ProfileId} | Create or update a Profile. If the passed object has an id attribute, then an update is performed, otherwise a new Profile metadata object is created.
[**upsert_sensor**](SMFApi.md#upsert_sensor) | **POST** /tenants/{TenantId}/smf/sensors/{SensorId} | Create or Update a sensor. If the object has an sensorId, then an update is performed, otherwise a new object is created.
[**validate_draft**](SMFApi.md#validate_draft) | **POST** /tenants/{TenantId}/smf/drafts/{DraftId}/validate | Validate this draft against a bro instance. The returned results indicate whether or not the draft successfully parsed and executed within a bro environment.


# **apply_profile_updates**
> PostResponse apply_profile_updates(tenant_id, profile_ids_body_parameter)

Apply all upstream changes to the selected profiles.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
profile_ids_body_parameter = mixmode_api.ProfileIdsBodyParameter() # ProfileIdsBodyParameter | A list of profiles to apply updates to.

try:
    # Apply all upstream changes to the selected profiles.
    api_response = api_instance.apply_profile_updates(tenant_id, profile_ids_body_parameter)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->apply_profile_updates: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **profile_ids_body_parameter** | [**ProfileIdsBodyParameter**](ProfileIdsBodyParameter.md)| A list of profiles to apply updates to. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **check_for_upstream_updates**
> PostResponse check_for_upstream_updates(tenant_id)

Get upstream updates for all profiles. They will show up as available updates in any local profiles.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 

try:
    # Get upstream updates for all profiles. They will show up as available updates in any local profiles.
    api_response = api_instance.check_for_upstream_updates(tenant_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->check_for_upstream_updates: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **checkout_draft_file**
> checkout_draft_file(tenant_id, draft_id, checkout_body_parameter, path)

Checkout a file or path.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier
checkout_body_parameter = mixmode_api.GitCheckout() # GitCheckout | Parameters passed to git checkout.
path = 'path_example' # str | The path of a file or directory relative to the root of profile or draft.

try:
    # Checkout a file or path.
    api_instance.checkout_draft_file(tenant_id, draft_id, checkout_body_parameter, path)
except ApiException as e:
    print("Exception when calling SMFApi->checkout_draft_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 
 **checkout_body_parameter** | [**GitCheckout**](GitCheckout.md)| Parameters passed to git checkout. | 
 **path** | **str**| The path of a file or directory relative to the root of profile or draft. | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **commit_draft**
> GitCommit commit_draft(tenant_id, draft_id, git_commit_message_body_parameter)

Save changes made to this draft. Following this call, 'status' will show no changes, and 'log' will contain a new entry indicating what was saved and any message associated with the commit operation. Has no affect on the profile from which this draft was created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier
git_commit_message_body_parameter = mixmode_api.GitCommitMessage() # GitCommitMessage | A git commit message

try:
    # Save changes made to this draft. Following this call, 'status' will show no changes, and 'log' will contain a new entry indicating what was saved and any message associated with the commit operation. Has no affect on the profile from which this draft was created.
    api_response = api_instance.commit_draft(tenant_id, draft_id, git_commit_message_body_parameter)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->commit_draft: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 
 **git_commit_message_body_parameter** | [**GitCommitMessage**](GitCommitMessage.md)| A git commit message | 

### Return type

[**GitCommit**](GitCommit.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_profile**
> Profile create_profile(tenant_id, profile_type, profile_body_parameter)

Create a new profile.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
profile_type = 'profile_type_example' # str | sensor - Profile type to map to a deployed sensor bro - contains bro scripts, should be nested within a sensor profile as a submodule. intel - profile containing files conforming to the bro intel format. Should be mapped to a sensor as a submodule. script - profile containing bro script files. Should be mapped to a sensor as a submodule. 
profile_body_parameter = mixmode_api.ProfileAttributes() # ProfileAttributes | A Profile is a git repository with additional metadata. Profiles are mapped to sensors to define their behavior. You can modify Profiles by creating a Draft, adding/removing/changing files, then finalizing the draft.

try:
    # Create a new profile.
    api_response = api_instance.create_profile(tenant_id, profile_type, profile_body_parameter)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->create_profile: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **profile_type** | **str**| sensor - Profile type to map to a deployed sensor bro - contains bro scripts, should be nested within a sensor profile as a submodule. intel - profile containing files conforming to the bro intel format. Should be mapped to a sensor as a submodule. script - profile containing bro script files. Should be mapped to a sensor as a submodule.  | 
 **profile_body_parameter** | [**ProfileAttributes**](ProfileAttributes.md)| A Profile is a git repository with additional metadata. Profiles are mapped to sensors to define their behavior. You can modify Profiles by creating a Draft, adding/removing/changing files, then finalizing the draft. | 

### Return type

[**Profile**](Profile.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_profile_draft**
> Draft create_profile_draft(tenant_id, profile_id)

Begin editing a draft

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
profile_id = 56 # int | A Profile unique identifier.

try:
    # Begin editing a draft
    api_response = api_instance.create_profile_draft(tenant_id, profile_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->create_profile_draft: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **profile_id** | **int**| A Profile unique identifier. | 

### Return type

[**Draft**](Draft.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_sensor**
> SensorResponse create_sensor(tenant_id, sensor)

Create a new sensor.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor = mixmode_api.SensorAttributes() # SensorAttributes | A mixmode sensor.

try:
    # Create a new sensor.
    api_response = api_instance.create_sensor(tenant_id, sensor)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->create_sensor: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor** | [**SensorAttributes**](SensorAttributes.md)| A mixmode sensor. | 

### Return type

[**SensorResponse**](SensorResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_draft**
> delete_draft(tenant_id, draft_id)

Permanently delete a draft. Will have no affect on the profile from which the draft was created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier

try:
    # Permanently delete a draft. Will have no affect on the profile from which the draft was created.
    api_instance.delete_draft(tenant_id, draft_id)
except ApiException as e:
    print("Exception when calling SMFApi->delete_draft: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_draft_file**
> delete_draft_file(tenant_id, draft_id, path)

Permanently remove a file from a draft based on it's relative path ('*') from the root of the draft.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier
path = 'path_example' # str | The path of a file or directory relative to the root of profile or draft.

try:
    # Permanently remove a file from a draft based on it's relative path ('*') from the root of the draft.
    api_instance.delete_draft_file(tenant_id, draft_id, path)
except ApiException as e:
    print("Exception when calling SMFApi->delete_draft_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 
 **path** | **str**| The path of a file or directory relative to the root of profile or draft. | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_profile**
> delete_profile(tenant_id, profile_id)

Permanently delete a Profile and all of it's metadata.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
profile_id = 56 # int | A Profile unique identifier.

try:
    # Permanently delete a Profile and all of it's metadata.
    api_instance.delete_profile(tenant_id, profile_id)
except ApiException as e:
    print("Exception when calling SMFApi->delete_profile: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **profile_id** | **int**| A Profile unique identifier. | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_sensor**
> delete_sensor(tenant_id, sensor_id)

Delete a single Sensor by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 

try:
    # Delete a single Sensor by unique identifier.
    api_instance.delete_sensor(tenant_id, sensor_id)
except ApiException as e:
    print("Exception when calling SMFApi->delete_sensor: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_submodule**
> delete_submodule(tenant_id, draft_id, submodule_body_parameter)

Permanently remove the profile referenced by the submodule from the draft.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier
submodule_body_parameter = mixmode_api.GitSubmodule() # GitSubmodule | A submodule definition.

try:
    # Permanently remove the profile referenced by the submodule from the draft.
    api_instance.delete_submodule(tenant_id, draft_id, submodule_body_parameter)
except ApiException as e:
    print("Exception when calling SMFApi->delete_submodule: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 
 **submodule_body_parameter** | [**GitSubmodule**](GitSubmodule.md)| A submodule definition. | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **diff_draft**
> GitDiff diff_draft(tenant_id, draft_id)

Check for upstream changes.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier

try:
    # Check for upstream changes.
    api_response = api_instance.diff_draft(tenant_id, draft_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->diff_draft: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 

### Return type

[**GitDiff**](GitDiff.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **diff_profile**
> GitDiff diff_profile(tenant_id, profile_id)

Check for upstream changes.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
profile_id = 56 # int | A Profile unique identifier.

try:
    # Check for upstream changes.
    api_response = api_instance.diff_profile(tenant_id, profile_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->diff_profile: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **profile_id** | **int**| A Profile unique identifier. | 

### Return type

[**GitDiff**](GitDiff.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **finalize_draft**
> GitMerge finalize_draft(tenant_id, draft_id, git_commit_message_body_parameter, validation_type)

Commits all changes, performs an extensive validation test, and if validation succeeds, permanently merges the changes made to this draft into the profile from which it was created and deletes the draft. Following this call, if it succeeds, the draft unique identifier will no longer be valid.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier
git_commit_message_body_parameter = mixmode_api.GitCommitMessage() # GitCommitMessage | A git commit message
validation_type = 'none' # str | The type of validation to be performed on the repository. (default to none)

try:
    # Commits all changes, performs an extensive validation test, and if validation succeeds, permanently merges the changes made to this draft into the profile from which it was created and deletes the draft. Following this call, if it succeeds, the draft unique identifier will no longer be valid.
    api_response = api_instance.finalize_draft(tenant_id, draft_id, git_commit_message_body_parameter, validation_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->finalize_draft: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 
 **git_commit_message_body_parameter** | [**GitCommitMessage**](GitCommitMessage.md)| A git commit message | 
 **validation_type** | **str**| The type of validation to be performed on the repository. | [default to none]

### Return type

[**GitMerge**](GitMerge.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **fork_profile**
> Profile fork_profile(tenant_id, profile_id, named_object_body_parameter)

Create a copy of a profile.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
profile_id = 56 # int | A Profile unique identifier.
named_object_body_parameter = mixmode_api.NamedObject() # NamedObject | A name and a description

try:
    # Create a copy of a profile.
    api_response = api_instance.fork_profile(tenant_id, profile_id, named_object_body_parameter)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->fork_profile: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **profile_id** | **int**| A Profile unique identifier. | 
 **named_object_body_parameter** | [**NamedObject**](NamedObject.md)| A name and a description | 

### Return type

[**Profile**](Profile.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **form_draft_file_upload**
> PostResponse form_draft_file_upload(tenant_id, draft_id, process_intel=process_intel, overwrite=overwrite, basepath=basepath, file=file)

Form file upload. Accepts a form file upload named 'file'.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier
process_intel = false # bool | Whether or not to transform intel files. (optional) (default to false)
overwrite = true # bool | Whether or not to replace an existing file. (optional) (default to true)
basepath = '' # str | Root directory to place files. (optional) (default to )
file = '/path/to/file.txt' # file | The file to upload (optional)

try:
    # Form file upload. Accepts a form file upload named 'file'.
    api_response = api_instance.form_draft_file_upload(tenant_id, draft_id, process_intel=process_intel, overwrite=overwrite, basepath=basepath, file=file)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->form_draft_file_upload: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 
 **process_intel** | **bool**| Whether or not to transform intel files. | [optional] [default to false]
 **overwrite** | **bool**| Whether or not to replace an existing file. | [optional] [default to true]
 **basepath** | **str**| Root directory to place files. | [optional] [default to ]
 **file** | **file**| The file to upload | [optional] 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_all_profile_updates**
> PagedProfileUpdates get_all_profile_updates(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Get a list of all profiles that have upstream changes.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Get a list of all profiles that have upstream changes.
    api_response = api_instance.get_all_profile_updates(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->get_all_profile_updates: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedProfileUpdates**](PagedProfileUpdates.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_all_profiles**
> PagedProfiles get_all_profiles(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of Profile metadata objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of Profile metadata objects.
    api_response = api_instance.get_all_profiles(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->get_all_profiles: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedProfiles**](PagedProfiles.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_all_sensors**
> PagedSensors get_all_sensors(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of sensor metadata objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of sensor metadata objects.
    api_response = api_instance.get_all_sensors(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->get_all_sensors: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedSensors**](PagedSensors.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_dns_request**
> get_dns_request(tenant_id, sensor_id, dns)

Proxy Sensor DNS requests through the platform API.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'
# Configure API key authorization: SensorTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
dns = '' # str | A base64 encoded DNS over HTTP request (default to )

try:
    # Proxy Sensor DNS requests through the platform API.
    api_instance.get_dns_request(tenant_id, sensor_id, dns)
except ApiException as e:
    print("Exception when calling SMFApi->get_dns_request: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **dns** | **str**| A base64 encoded DNS over HTTP request | [default to ]

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity), [SensorTokenSecurity](../README.md#SensorTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_draft_file**
> get_draft_file(tenant_id, draft_id, path)

Retrieve the contents of a file based on it's relative path ('*') from the root of the draft.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier
path = 'path_example' # str | The path of a file or directory relative to the root of profile or draft.

try:
    # Retrieve the contents of a file based on it's relative path ('*') from the root of the draft.
    api_instance.get_draft_file(tenant_id, draft_id, path)
except ApiException as e:
    print("Exception when calling SMFApi->get_draft_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 
 **path** | **str**| The path of a file or directory relative to the root of profile or draft. | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/octet-stream

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_draft_file_list**
> PagedGitFiles get_draft_file_list(tenant_id, draft_id, path, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Recursively list the files beneath a path '*' in the current draft. Return a filtered, sorted, paged list of file metadata objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier
path = 'path_example' # str | The path of a file or directory relative to the root of profile or draft.
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Recursively list the files beneath a path '*' in the current draft. Return a filtered, sorted, paged list of file metadata objects.
    api_response = api_instance.get_draft_file_list(tenant_id, draft_id, path, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->get_draft_file_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 
 **path** | **str**| The path of a file or directory relative to the root of profile or draft. | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedGitFiles**](PagedGitFiles.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_draft_status**
> GitStatus get_draft_status(tenant_id, draft_id)

Return a list of changes made to the draft since it was created from a profile. This is effetively the differences between the draft and the profile from which it was created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier

try:
    # Return a list of changes made to the draft since it was created from a profile. This is effetively the differences between the draft and the profile from which it was created.
    api_response = api_instance.get_draft_status(tenant_id, draft_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->get_draft_status: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 

### Return type

[**GitStatus**](GitStatus.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_draft_submodules**
> PagedGitSubmodules get_draft_submodules(tenant_id, draft_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Get Submodules

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Get Submodules
    api_response = api_instance.get_draft_submodules(tenant_id, draft_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->get_draft_submodules: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedGitSubmodules**](PagedGitSubmodules.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_profile**
> Profile get_profile(tenant_id, profile_id)

Retrieve the metadata for a Profile by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
profile_id = 56 # int | A Profile unique identifier.

try:
    # Retrieve the metadata for a Profile by unique identifier.
    api_response = api_instance.get_profile(tenant_id, profile_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->get_profile: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **profile_id** | **int**| A Profile unique identifier. | 

### Return type

[**Profile**](Profile.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_profile_drafts**
> PagedDrafts get_profile_drafts(tenant_id, profile_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Return a filtered, sorted, paged list of draft metadata objects for drafts associated with this profile and the current logged on api user. Note that the profile metadata objects will also include a draftId attribute containing the id of any drafts for this profile that belong to the currently authenticated api user.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
profile_id = 56 # int | A Profile unique identifier.
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Return a filtered, sorted, paged list of draft metadata objects for drafts associated with this profile and the current logged on api user. Note that the profile metadata objects will also include a draftId attribute containing the id of any drafts for this profile that belong to the currently authenticated api user.
    api_response = api_instance.get_profile_drafts(tenant_id, profile_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->get_profile_drafts: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **profile_id** | **int**| A Profile unique identifier. | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedDrafts**](PagedDrafts.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_profile_file**
> get_profile_file(tenant_id, profile_id, path)

Retrieve the contents of a file based on it's relative path ('*') from the root of the profile.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
profile_id = 56 # int | A Profile unique identifier.
path = 'path_example' # str | The path of a file or directory relative to the root of profile or draft.

try:
    # Retrieve the contents of a file based on it's relative path ('*') from the root of the profile.
    api_instance.get_profile_file(tenant_id, profile_id, path)
except ApiException as e:
    print("Exception when calling SMFApi->get_profile_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **profile_id** | **int**| A Profile unique identifier. | 
 **path** | **str**| The path of a file or directory relative to the root of profile or draft. | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/octet-stream

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_profile_submodules**
> PagedGitSubmodules get_profile_submodules(tenant_id, profile_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Return a filtered, sorted, paged list of submodule metadata objects for submodules that have been added to this profile.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
profile_id = 56 # int | A Profile unique identifier.
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Return a filtered, sorted, paged list of submodule metadata objects for submodules that have been added to this profile.
    api_response = api_instance.get_profile_submodules(tenant_id, profile_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->get_profile_submodules: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **profile_id** | **int**| A Profile unique identifier. | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedGitSubmodules**](PagedGitSubmodules.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_profile_updates**
> PagedProfileUpdates get_profile_updates(tenant_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Get a list of all profiles that have upstream changes.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Get a list of all profiles that have upstream changes.
    api_response = api_instance.get_profile_updates(tenant_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->get_profile_updates: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedProfileUpdates**](PagedProfileUpdates.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_profiles**
> PagedProfiles get_profiles(tenant_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of Profile metadata objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of Profile metadata objects.
    api_response = api_instance.get_profiles(tenant_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->get_profiles: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedProfiles**](PagedProfiles.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_profiles_by_type**
> PagedProfiles get_profiles_by_type(tenant_id, profile_type, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system by profile type and returns a filtered, sorted, paged list of Profile metadata objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
profile_type = 'profile_type_example' # str | sensor - Profile type to map to a deployed sensor bro - contains bro scripts, should be nested within a sensor profile as a submodule. intel - profile containing files conforming to the bro intel format. Should be mapped to a sensor as a submodule. script - profile containing bro script files. Should be mapped to a sensor as a submodule. 
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system by profile type and returns a filtered, sorted, paged list of Profile metadata objects.
    api_response = api_instance.get_profiles_by_type(tenant_id, profile_type, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->get_profiles_by_type: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **profile_type** | **str**| sensor - Profile type to map to a deployed sensor bro - contains bro scripts, should be nested within a sensor profile as a submodule. intel - profile containing files conforming to the bro intel format. Should be mapped to a sensor as a submodule. script - profile containing bro script files. Should be mapped to a sensor as a submodule.  | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedProfiles**](PagedProfiles.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_sensor**
> SensorResponse get_sensor(tenant_id, sensor_id)

Get a single Sensor by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 

try:
    # Get a single Sensor by unique identifier.
    api_response = api_instance.get_sensor(tenant_id, sensor_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->get_sensor: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 

### Return type

[**SensorResponse**](SensorResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_sensor_configuration**
> BroSensorConfigurationAttributes get_sensor_configuration(tenant_id, sensor_id)

Get initial sensor configuration. Call this method when you have deployed a sensor and added the sensor to the API. This method will return data that is used to provision the deployed sensor to make it operational with the mixmode platform.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'
# Configure API key authorization: SensorTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 

try:
    # Get initial sensor configuration. Call this method when you have deployed a sensor and added the sensor to the API. This method will return data that is used to provision the deployed sensor to make it operational with the mixmode platform.
    api_response = api_instance.get_sensor_configuration(tenant_id, sensor_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->get_sensor_configuration: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 

### Return type

[**BroSensorConfigurationAttributes**](BroSensorConfigurationAttributes.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity), [SensorTokenSecurity](../README.md#SensorTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_sensor_file_proxy**
> get_sensor_file_proxy(tenant_id, sensor_id, path)

Sensor api proxy.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
path = 'path_example' # str | The path of a file or directory relative to the root of profile or draft.

try:
    # Sensor api proxy.
    api_instance.get_sensor_file_proxy(tenant_id, sensor_id, path)
except ApiException as e:
    print("Exception when calling SMFApi->get_sensor_file_proxy: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **path** | **str**| The path of a file or directory relative to the root of profile or draft. | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_sensors**
> PagedSensors get_sensors(tenant_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of sensor metadata objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of sensor metadata objects.
    api_response = api_instance.get_sensors(tenant_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->get_sensors: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedSensors**](PagedSensors.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_smf_archive**
> get_smf_archive(tenant_id, sensor_id)

Get a tarfile containing the SMF profile for a specific sensor.  Removes the need to 'git clone' in the sensor.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'
# Configure API key authorization: SensorTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 

try:
    # Get a tarfile containing the SMF profile for a specific sensor.  Removes the need to 'git clone' in the sensor.
    api_instance.get_smf_archive(tenant_id, sensor_id)
except ApiException as e:
    print("Exception when calling SMFApi->get_smf_archive: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity), [SensorTokenSecurity](../README.md#SensorTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/octet-stream

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_templates**
> PagedTemplates get_templates(tenant_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Returns all of the available templates available for profile creation.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Returns all of the available templates available for profile creation.
    api_response = api_instance.get_templates(tenant_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->get_templates: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedTemplates**](PagedTemplates.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_wss_connection**
> PostResponse get_wss_connection(tenant_id, sensor_id, connection, upgrade, sec_web_socket_key, sec_web_socket_version)

Create a new WebSocket Server connection

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'
# Configure API key authorization: SensorTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
connection = 'connection_example' # str | 
upgrade = 'upgrade_example' # str | 
sec_web_socket_key = 'sec_web_socket_key_example' # str | 
sec_web_socket_version = 56 # int | 

try:
    # Create a new WebSocket Server connection
    api_response = api_instance.get_wss_connection(tenant_id, sensor_id, connection, upgrade, sec_web_socket_key, sec_web_socket_version)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->get_wss_connection: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **connection** | **str**|  | 
 **upgrade** | **str**|  | 
 **sec_web_socket_key** | **str**|  | 
 **sec_web_socket_version** | **int**|  | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity), [SensorTokenSecurity](../README.md#SensorTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **lint_draft_file**
> BroValidateResponse lint_draft_file(tenant_id, draft_id, lint_type, path)

Perform validation of individual files based on their relative path ('*') from the root of a draft. Returns a result indicating whether or not the referenced file passes the chosen validation.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier
lint_type = 'lint_type_example' # str | The type of validation to be performed on the file.
path = 'path_example' # str | The path of a file or directory relative to the root of profile or draft.

try:
    # Perform validation of individual files based on their relative path ('*') from the root of a draft. Returns a result indicating whether or not the referenced file passes the chosen validation.
    api_response = api_instance.lint_draft_file(tenant_id, draft_id, lint_type, path)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->lint_draft_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 
 **lint_type** | **str**| The type of validation to be performed on the file. | 
 **path** | **str**| The path of a file or directory relative to the root of profile or draft. | 

### Return type

[**BroValidateResponse**](BroValidateResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_profile_files**
> PagedGitFiles list_profile_files(tenant_id, profile_id, path, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Recursively list the files beneath a path '*' in the current profile. Return a filtered, sorted, paged list of file metadata objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
profile_id = 56 # int | A Profile unique identifier.
path = 'path_example' # str | The path of a file or directory relative to the root of profile or draft.
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Recursively list the files beneath a path '*' in the current profile. Return a filtered, sorted, paged list of file metadata objects.
    api_response = api_instance.list_profile_files(tenant_id, profile_id, path, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->list_profile_files: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **profile_id** | **int**| A Profile unique identifier. | 
 **path** | **str**| The path of a file or directory relative to the root of profile or draft. | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedGitFiles**](PagedGitFiles.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **log_draft**
> GitLog log_draft(tenant_id, draft_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Show a log of changes committed to the draft since it was created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Show a log of changes committed to the draft since it was created.
    api_response = api_instance.log_draft(tenant_id, draft_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->log_draft: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**GitLog**](GitLog.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **log_profile**
> GitLog log_profile(tenant_id, profile_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Return a filtered, sorted, paged list of changes that have been applied to this profile since it was created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
profile_id = 56 # int | A Profile unique identifier.
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Return a filtered, sorted, paged list of changes that have been applied to this profile since it was created.
    api_response = api_instance.log_profile(tenant_id, profile_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->log_profile: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **profile_id** | **int**| A Profile unique identifier. | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**GitLog**](GitLog.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **move_draft_file**
> PostResponse move_draft_file(tenant_id, draft_id, _from, to, overwrite=overwrite)

Move a file from one directory to another.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier
_from = '_from_example' # str | The source file
to = 'to_example' # str | The destination file
overwrite = false # bool | Whether to overwrite an existing file or not. (optional) (default to false)

try:
    # Move a file from one directory to another.
    api_response = api_instance.move_draft_file(tenant_id, draft_id, _from, to, overwrite=overwrite)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->move_draft_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 
 **_from** | **str**| The source file | 
 **to** | **str**| The destination file | 
 **overwrite** | **bool**| Whether to overwrite an existing file or not. | [optional] [default to false]

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **processor_draft_file**
> ProcessorResponse processor_draft_file(tenant_id, draft_id, processor_type, path, desc=desc, severity=severity)

Perform processing of the file. This can be any transformation supported by the api.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier
processor_type = 'processor_type_example' # str | The type of processing to be performed on the file.
path = 'path_example' # str | The path of a file or directory relative to the root of profile or draft.
desc = 'desc_example' # str | Value for meta.desc field in INTEL file (optional)
severity = 'severity_example' # str | Value for meta.severity field in INTEL file (optional)

try:
    # Perform processing of the file. This can be any transformation supported by the api.
    api_response = api_instance.processor_draft_file(tenant_id, draft_id, processor_type, path, desc=desc, severity=severity)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->processor_draft_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 
 **processor_type** | **str**| The type of processing to be performed on the file. | 
 **path** | **str**| The path of a file or directory relative to the root of profile or draft. | 
 **desc** | **str**| Value for meta.desc field in INTEL file | [optional] 
 **severity** | **str**| Value for meta.severity field in INTEL file | [optional] 

### Return type

[**ProcessorResponse**](ProcessorResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **push_draft**
> push_draft(tenant_id, draft_id)

Send any committed changes made to this draft up to the server where the draft is stored.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier

try:
    # Send any committed changes made to this draft up to the server where the draft is stored.
    api_instance.push_draft(tenant_id, draft_id)
except ApiException as e:
    print("Exception when calling SMFApi->push_draft: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_sensor_mode**
> PostResponse set_sensor_mode(tenant_id, sensor_id, sensor_mode)

Put the sensor into an operational mode.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
sensor_mode = 'sensor_mode_example' # str | The operational mode to put the sensor in.

try:
    # Put the sensor into an operational mode.
    api_response = api_instance.set_sensor_mode(tenant_id, sensor_id, sensor_mode)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->set_sensor_mode: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **sensor_mode** | **str**| The operational mode to put the sensor in. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_sensor_profile**
> SensorResponse set_sensor_profile(tenant_id, sensor_id, profile_id)

Associate a Profile with a sensor. Only a single profile can be associated with a sensor, and this profile should be of type 'sensor'. Composition of profiles is handled by nesting additional profiles (as submodules) within the 'sensor' profile.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
profile_id = 56 # int | A Profile unique identifier.

try:
    # Associate a Profile with a sensor. Only a single profile can be associated with a sensor, and this profile should be of type 'sensor'. Composition of profiles is handled by nesting additional profiles (as submodules) within the 'sensor' profile.
    api_response = api_instance.set_sensor_profile(tenant_id, sensor_id, profile_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->set_sensor_profile: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **profile_id** | **int**| A Profile unique identifier. | 

### Return type

[**SensorResponse**](SensorResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_upload_type**
> PostResponse set_upload_type(tenant_id, sensor_id, upload_type, file=file)

Upload log files from a sensor.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'
# Configure API key authorization: SensorTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
upload_type = 'upload_type_example' # str | The type of file being uploaded to the platform.
file = '/path/to/file.txt' # file | The file to upload (optional)

try:
    # Upload log files from a sensor.
    api_response = api_instance.set_upload_type(tenant_id, sensor_id, upload_type, file=file)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->set_upload_type: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **upload_type** | **str**| The type of file being uploaded to the platform. | 
 **file** | **file**| The file to upload | [optional] 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity), [SensorTokenSecurity](../README.md#SensorTokenSecurity)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **sync_sensor**
> PostResponse sync_sensor(tenant_id, sensor_id)

Sends a message to the sensor to update from the latest profile version stored on the server. Use this command when you have made changes to a profile and want those changes to be pushed to any affected sensors.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 

try:
    # Sends a message to the sensor to update from the latest profile version stored on the server. Use this command when you have made changes to a profile and want those changes to be pushed to any affected sensors.
    api_response = api_instance.sync_sensor(tenant_id, sensor_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->sync_sensor: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **unset_sensor_profile**
> unset_sensor_profile(tenant_id, sensor_id)

Remove any profile from a sensor. This will make the sensor inoperational. A sensor should always have a profile associated with it to operate correctly.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 

try:
    # Remove any profile from a sensor. This will make the sensor inoperational. A sensor should always have a profile associated with it to operate correctly.
    api_instance.unset_sensor_profile(tenant_id, sensor_id)
except ApiException as e:
    print("Exception when calling SMFApi->unset_sensor_profile: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_draft**
> PostResponse update_draft(tenant_id, draft_id)

Merge upstream changes into this draft. This is how to receive updates from MixMode.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier

try:
    # Merge upstream changes into this draft. This is how to receive updates from MixMode.
    api_response = api_instance.update_draft(tenant_id, draft_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->update_draft: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_draft_submodules**
> GitUpdateDraftSubmodules update_draft_submodules(tenant_id, draft_id)

Get the latest version of all submodules.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier

try:
    # Get the latest version of all submodules.
    api_response = api_instance.update_draft_submodules(tenant_id, draft_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->update_draft_submodules: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 

### Return type

[**GitUpdateDraftSubmodules**](GitUpdateDraftSubmodules.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_profile**
> PostResponse update_profile(tenant_id, profile_id)

Merge upstream changes into this profile. This is how to receive updates from MixMode.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
profile_id = 56 # int | A Profile unique identifier.

try:
    # Merge upstream changes into this profile. This is how to receive updates from MixMode.
    api_response = api_instance.update_profile(tenant_id, profile_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->update_profile: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **profile_id** | **int**| A Profile unique identifier. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **upload_draft_archive**
> PostResponse upload_draft_archive(tenant_id, draft_id, path, file=file)

Upload an archive file to a path ('*') relative to the root of the draft. The archive will be extracted into the path. This is the standard way to introduce new files into a profile.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier
path = 'path_example' # str | The path of a file or directory relative to the root of profile or draft.
file = '/path/to/file.txt' # file | The archive file to upload (optional)

try:
    # Upload an archive file to a path ('*') relative to the root of the draft. The archive will be extracted into the path. This is the standard way to introduce new files into a profile.
    api_response = api_instance.upload_draft_archive(tenant_id, draft_id, path, file=file)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->upload_draft_archive: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 
 **path** | **str**| The path of a file or directory relative to the root of profile or draft. | 
 **file** | **file**| The archive file to upload | [optional] 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **upsert_draft_file**
> PostResponse upsert_draft_file(tenant_id, draft_id, path, file=file, overwrite=overwrite)

Upload the file contents to a path ('*') relative to the root of the draft. This is the standard way to introduce new files and/or update existing files into a profile.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier
path = 'path_example' # str | The path of a file or directory relative to the root of profile or draft.
file = 'file_example' # str | The file to upload (optional)
overwrite = true # bool | Whether or not to replace an existing file. (optional) (default to true)

try:
    # Upload the file contents to a path ('*') relative to the root of the draft. This is the standard way to introduce new files and/or update existing files into a profile.
    api_response = api_instance.upsert_draft_file(tenant_id, draft_id, path, file=file, overwrite=overwrite)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->upsert_draft_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 
 **path** | **str**| The path of a file or directory relative to the root of profile or draft. | 
 **file** | **str**| The file to upload | [optional] 
 **overwrite** | **bool**| Whether or not to replace an existing file. | [optional] [default to true]

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **upsert_draft_file_upload**
> PostResponse upsert_draft_file_upload(tenant_id, draft_id, path, process_intel=process_intel, overwrite=overwrite, file=file)

Upload a file to a path ('*') relative to the root of the draft. This is the standard way to introduce new files into a profile.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier
path = 'path_example' # str | The path of a file or directory relative to the root of profile or draft.
process_intel = false # bool | Whether or not to transform intel files. (optional) (default to false)
overwrite = true # bool | Whether or not to replace an existing file. (optional) (default to true)
file = '/path/to/file.txt' # file | The file to upload (optional)

try:
    # Upload a file to a path ('*') relative to the root of the draft. This is the standard way to introduce new files into a profile.
    api_response = api_instance.upsert_draft_file_upload(tenant_id, draft_id, path, process_intel=process_intel, overwrite=overwrite, file=file)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->upsert_draft_file_upload: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 
 **path** | **str**| The path of a file or directory relative to the root of profile or draft. | 
 **process_intel** | **bool**| Whether or not to transform intel files. | [optional] [default to false]
 **overwrite** | **bool**| Whether or not to replace an existing file. | [optional] [default to true]
 **file** | **file**| The file to upload | [optional] 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **upsert_draft_submodule**
> GitSubmodule upsert_draft_submodule(tenant_id, draft_id, submodule_body_parameter)

Add a submodule

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier
submodule_body_parameter = mixmode_api.GitSubmoduleParameter() # GitSubmoduleParameter | A submodule definition.

try:
    # Add a submodule
    api_response = api_instance.upsert_draft_submodule(tenant_id, draft_id, submodule_body_parameter)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->upsert_draft_submodule: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 
 **submodule_body_parameter** | [**GitSubmoduleParameter**](GitSubmoduleParameter.md)| A submodule definition. | 

### Return type

[**GitSubmodule**](GitSubmodule.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **upsert_profile**
> PostResponse upsert_profile(tenant_id, profile_id, profile_body_parameter)

Create or update a Profile. If the passed object has an id attribute, then an update is performed, otherwise a new Profile metadata object is created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
profile_id = 56 # int | A Profile unique identifier.
profile_body_parameter = mixmode_api.ProfileAttributes() # ProfileAttributes | A Profile is a git repository with additional metadata. Profiles are mapped to sensors to define their behavior. You can modify Profiles by creating a Draft, adding/removing/changing files, then finalizing the draft.

try:
    # Create or update a Profile. If the passed object has an id attribute, then an update is performed, otherwise a new Profile metadata object is created.
    api_response = api_instance.upsert_profile(tenant_id, profile_id, profile_body_parameter)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->upsert_profile: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **profile_id** | **int**| A Profile unique identifier. | 
 **profile_body_parameter** | [**ProfileAttributes**](ProfileAttributes.md)| A Profile is a git repository with additional metadata. Profiles are mapped to sensors to define their behavior. You can modify Profiles by creating a Draft, adding/removing/changing files, then finalizing the draft. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **upsert_sensor**
> PostResponse upsert_sensor(tenant_id, sensor_id, sensor)

Create or Update a sensor. If the object has an sensorId, then an update is performed, otherwise a new object is created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
sensor = mixmode_api.SensorAttributes() # SensorAttributes | A mixmode sensor.

try:
    # Create or Update a sensor. If the object has an sensorId, then an update is performed, otherwise a new object is created.
    api_response = api_instance.upsert_sensor(tenant_id, sensor_id, sensor)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->upsert_sensor: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **sensor** | [**SensorAttributes**](SensorAttributes.md)| A mixmode sensor. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **validate_draft**
> BroValidateResponse validate_draft(tenant_id, draft_id, validation_body_parameter, validation_type)

Validate this draft against a bro instance. The returned results indicate whether or not the draft successfully parsed and executed within a bro environment.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SMFApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
draft_id = 56 # int | A Draft unique identifier
validation_body_parameter = mixmode_api.BroValidateRequest() # BroValidateRequest | A request indicating which type of validation to perform.
validation_type = 'none' # str | The type of validation to be performed on the repository. (default to none)

try:
    # Validate this draft against a bro instance. The returned results indicate whether or not the draft successfully parsed and executed within a bro environment.
    api_response = api_instance.validate_draft(tenant_id, draft_id, validation_body_parameter, validation_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SMFApi->validate_draft: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **draft_id** | **int**| A Draft unique identifier | 
 **validation_body_parameter** | [**BroValidateRequest**](BroValidateRequest.md)| A request indicating which type of validation to perform. | 
 **validation_type** | **str**| The type of validation to be performed on the repository. | [default to none]

### Return type

[**BroValidateResponse**](BroValidateResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

