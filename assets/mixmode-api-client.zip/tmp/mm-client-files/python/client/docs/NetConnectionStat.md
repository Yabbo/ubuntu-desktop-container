# NetConnectionStat

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**family** | **int** |  | [optional] 
**fd** | **int** |  | [optional] 
**localaddr** | [**NetAddr**](NetAddr.md) |  | [optional] 
**pid** | **int** |  | [optional] 
**remoteaddr** | [**NetAddr**](NetAddr.md) |  | [optional] 
**status** | **str** |  | [optional] 
**type** | **int** |  | [optional] 
**uids** | **list[int]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


