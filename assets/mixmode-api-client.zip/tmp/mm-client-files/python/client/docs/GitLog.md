# GitLog

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**all** | [**list[GitMessage]**](GitMessage.md) | An array of git log messages | [optional] 
**latest** | [**GitMessage**](GitMessage.md) |  | [optional] 
**total** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


