# HasSensors

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sensors** | [**list[Sensor]**](Sensor.md) | An array of Sensors. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


