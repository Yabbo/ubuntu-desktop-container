# ProfileIdsBodyParameter

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**profile_ids** | **list[int]** | A list of profile ids to apply updates to | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


