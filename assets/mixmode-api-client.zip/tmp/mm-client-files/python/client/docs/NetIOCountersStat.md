# NetIOCountersStat

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bytes_recv** | **int** |  | [optional] 
**bytes_sent** | **int** |  | [optional] 
**dropin** | **int** |  | [optional] 
**dropout** | **int** |  | [optional] 
**errin** | **int** |  | [optional] 
**errout** | **int** |  | [optional] 
**fifoin** | **int** |  | [optional] 
**fifoout** | **int** |  | [optional] 
**name** | **str** |  | [optional] 
**packets_recv** | **int** |  | [optional] 
**packets_sent** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


