# IntegrationAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | The name of an object | 
**description** | **str** | A description of an object | [optional] 
**labels** | **list[str]** | A list of labels. | [optional] 
**enabled** | **bool** | Whether or not integration is disabled. Disabled integrations will not execute. | [default to True]
**template** | **str** | The URL template for calling an external REST service. The template must contain one parameterized field called {{value}}. | 
**fields** | **list[str]** | A list of valid field names that this integration applies to. | 
**data** | [**IntegrationMetadata**](IntegrationMetadata.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


