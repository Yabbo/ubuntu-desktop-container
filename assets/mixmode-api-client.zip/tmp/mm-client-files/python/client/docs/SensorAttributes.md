# SensorAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | The name of an object | 
**description** | **str** | A description of an object | [optional] 
**labels** | **list[str]** | A list of labels. | [optional] 
**profile_url** | **str** | A url suitable for performing git operations on this sensor | [optional] [default to ' ']
**profile_branch** | **str** | The branch of the repository to pull | [optional] [default to 'master']
**profile_hash** | **str** | A commit of this repository to pull | [optional] [default to 'HEAD']
**mode** | **str** | Sensor can be put into different operational modes. | [optional] [default to 'running']
**auto_sync** | **bool** | Automatically update this sensor when it&#39;s profile is modified | [optional] [default to True]
**interface** | **str** | The network interface this sensor is attached to | [optional] [default to 'eth1']
**port** | **int** | The reachback port for this sensor | [optional] [default to 8000]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


