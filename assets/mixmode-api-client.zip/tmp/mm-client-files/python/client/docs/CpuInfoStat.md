# CpuInfoStat

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cache_size** | **int** |  | [optional] 
**core_id** | **str** |  | [optional] 
**cores** | **int** |  | [optional] 
**cpu** | **int** |  | [optional] 
**family** | **str** |  | [optional] 
**flags** | **list[str]** |  | [optional] 
**mhz** | **float** |  | [optional] 
**microcode** | **str** |  | [optional] 
**model** | **str** |  | [optional] 
**model_name** | **str** |  | [optional] 
**physical_id** | **str** |  | [optional] 
**stepping** | **int** |  | [optional] 
**vendor_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


