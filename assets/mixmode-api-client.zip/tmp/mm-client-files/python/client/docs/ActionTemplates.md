# ActionTemplates

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**indicator_template** | [**IndicatorAction**](IndicatorAction.md) |  | [optional] 
**alert_template** | [**AlertAction**](AlertAction.md) |  | [optional] 
**report_template** | [**ReportAction**](ReportAction.md) |  | [optional] 
**stream_template** | [**StreamAction**](StreamAction.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


