# mixmode_api.DashboardsApi

All URIs are relative to *https://api.mixmode.ai/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_dashboards**](DashboardsApi.md#get_dashboards) | **GET** /dashboards | Get the dashboards configuration for the current user
[**upsert_dashboard**](DashboardsApi.md#upsert_dashboard) | **POST** /dashboards | Create or Update a Dashboard. If the object has an DashboardId, then an update is performed, otherwise a new object is created.


# **get_dashboards**
> Dashboard get_dashboards()

Get the dashboards configuration for the current user

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.DashboardsApi(mixmode_api.ApiClient(configuration))

try:
    # Get the dashboards configuration for the current user
    api_response = api_instance.get_dashboards()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DashboardsApi->get_dashboards: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Dashboard**](Dashboard.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **upsert_dashboard**
> Dashboard upsert_dashboard(dashboard)

Create or Update a Dashboard. If the object has an DashboardId, then an update is performed, otherwise a new object is created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.DashboardsApi(mixmode_api.ApiClient(configuration))
dashboard = mixmode_api.DashboardAttributes() # DashboardAttributes | An dashboard is a reusable container for data.

try:
    # Create or Update a Dashboard. If the object has an DashboardId, then an update is performed, otherwise a new object is created.
    api_response = api_instance.upsert_dashboard(dashboard)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DashboardsApi->upsert_dashboard: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **dashboard** | [**DashboardAttributes**](DashboardAttributes.md)| An dashboard is a reusable container for data. | 

### Return type

[**Dashboard**](Dashboard.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

