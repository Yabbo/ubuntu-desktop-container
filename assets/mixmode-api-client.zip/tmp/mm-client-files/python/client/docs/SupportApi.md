# mixmode_api.SupportApi

All URIs are relative to *https://api.mixmode.ai/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**request_support**](SupportApi.md#request_support) | **POST** /support/request | Request support.


# **request_support**
> SupportRequestResponse request_support(support_request)

Request support.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.SupportApi(mixmode_api.ApiClient(configuration))
support_request = mixmode_api.SupportRequest() # SupportRequest | A request for support sent to pre-configured email alias.

try:
    # Request support.
    api_response = api_instance.request_support(support_request)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SupportApi->request_support: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **support_request** | [**SupportRequest**](SupportRequest.md)| A request for support sent to pre-configured email alias. | 

### Return type

[**SupportRequestResponse**](SupportRequestResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

