# mixmode_api.BookmarksApi

All URIs are relative to *https://api.mixmode.ai/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_user_id_bookmark**](BookmarksApi.md#create_user_id_bookmark) | **POST** /bookmarks/id | Create a new bookmark.
[**create_user_pql_bookmark**](BookmarksApi.md#create_user_pql_bookmark) | **POST** /bookmarks/pql | Create a new pql bookmark.
[**delete_id_bookmark_from_user**](BookmarksApi.md#delete_id_bookmark_from_user) | **DELETE** /bookmarks/id/{BookmarkId} | Delete a single bookmark by unique identifier.
[**delete_pql_bookmark_from_user**](BookmarksApi.md#delete_pql_bookmark_from_user) | **DELETE** /bookmarks/pql/{BookmarkId} | Delete a single pql bookmark by unique identifier.
[**get_user_id_bookmark**](BookmarksApi.md#get_user_id_bookmark) | **GET** /bookmarks/id/{BookmarkId} | Get a bookmark by id.
[**get_user_id_bookmarks**](BookmarksApi.md#get_user_id_bookmarks) | **GET** /bookmarks/id | Queries the system and returns a filtered, sorted, paged list of bookmark metadata objects.
[**get_user_pql_bookmark**](BookmarksApi.md#get_user_pql_bookmark) | **GET** /bookmarks/pql/{BookmarkId} | Get a pql bookmark by id.
[**get_user_pql_bookmarks**](BookmarksApi.md#get_user_pql_bookmarks) | **GET** /bookmarks/pql | Queries the system and returns a filtered, sorted, paged list of bookmark metadata objects.
[**upsert_user_id_bookmark**](BookmarksApi.md#upsert_user_id_bookmark) | **POST** /bookmarks/id/{BookmarkId} | Create or Update a Bookmark. If the object has an BookmarkId, then an update is performed, otherwise a new object is created.
[**upsert_user_pql_bookmark**](BookmarksApi.md#upsert_user_pql_bookmark) | **POST** /bookmarks/pql/{BookmarkId} | Create or Update a Bookmark. If the object has an BookmarkId, then an update is performed, otherwise a new object is created.


# **create_user_id_bookmark**
> IdBookmark create_user_id_bookmark(bookmark)

Create a new bookmark.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.BookmarksApi(mixmode_api.ApiClient(configuration))
bookmark = mixmode_api.IdBookmarkAttributes() # IdBookmarkAttributes | A bookmark is link to a specific object in the datalake.

try:
    # Create a new bookmark.
    api_response = api_instance.create_user_id_bookmark(bookmark)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BookmarksApi->create_user_id_bookmark: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bookmark** | [**IdBookmarkAttributes**](IdBookmarkAttributes.md)| A bookmark is link to a specific object in the datalake. | 

### Return type

[**IdBookmark**](IdBookmark.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_user_pql_bookmark**
> PqlBookmark create_user_pql_bookmark(bookmark)

Create a new pql bookmark.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.BookmarksApi(mixmode_api.ApiClient(configuration))
bookmark = mixmode_api.PqlBookmarkAttributes() # PqlBookmarkAttributes | A bookmark is link to a specific object in the datalake.

try:
    # Create a new pql bookmark.
    api_response = api_instance.create_user_pql_bookmark(bookmark)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BookmarksApi->create_user_pql_bookmark: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bookmark** | [**PqlBookmarkAttributes**](PqlBookmarkAttributes.md)| A bookmark is link to a specific object in the datalake. | 

### Return type

[**PqlBookmark**](PqlBookmark.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_id_bookmark_from_user**
> delete_id_bookmark_from_user(bookmark_id)

Delete a single bookmark by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.BookmarksApi(mixmode_api.ApiClient(configuration))
bookmark_id = 56 # int | 

try:
    # Delete a single bookmark by unique identifier.
    api_instance.delete_id_bookmark_from_user(bookmark_id)
except ApiException as e:
    print("Exception when calling BookmarksApi->delete_id_bookmark_from_user: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bookmark_id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_pql_bookmark_from_user**
> delete_pql_bookmark_from_user(bookmark_id)

Delete a single pql bookmark by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.BookmarksApi(mixmode_api.ApiClient(configuration))
bookmark_id = 56 # int | 

try:
    # Delete a single pql bookmark by unique identifier.
    api_instance.delete_pql_bookmark_from_user(bookmark_id)
except ApiException as e:
    print("Exception when calling BookmarksApi->delete_pql_bookmark_from_user: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bookmark_id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_user_id_bookmark**
> IdBookmark get_user_id_bookmark(bookmark_id)

Get a bookmark by id.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.BookmarksApi(mixmode_api.ApiClient(configuration))
bookmark_id = 56 # int | 

try:
    # Get a bookmark by id.
    api_response = api_instance.get_user_id_bookmark(bookmark_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BookmarksApi->get_user_id_bookmark: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bookmark_id** | **int**|  | 

### Return type

[**IdBookmark**](IdBookmark.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_user_id_bookmarks**
> PagedIdBookmarks get_user_id_bookmarks(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of bookmark metadata objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.BookmarksApi(mixmode_api.ApiClient(configuration))
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of bookmark metadata objects.
    api_response = api_instance.get_user_id_bookmarks(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BookmarksApi->get_user_id_bookmarks: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedIdBookmarks**](PagedIdBookmarks.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_user_pql_bookmark**
> PqlBookmark get_user_pql_bookmark(bookmark_id)

Get a pql bookmark by id.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.BookmarksApi(mixmode_api.ApiClient(configuration))
bookmark_id = 56 # int | 

try:
    # Get a pql bookmark by id.
    api_response = api_instance.get_user_pql_bookmark(bookmark_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BookmarksApi->get_user_pql_bookmark: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bookmark_id** | **int**|  | 

### Return type

[**PqlBookmark**](PqlBookmark.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_user_pql_bookmarks**
> PagedPqlBookmarks get_user_pql_bookmarks(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of bookmark metadata objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.BookmarksApi(mixmode_api.ApiClient(configuration))
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of bookmark metadata objects.
    api_response = api_instance.get_user_pql_bookmarks(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BookmarksApi->get_user_pql_bookmarks: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedPqlBookmarks**](PagedPqlBookmarks.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **upsert_user_id_bookmark**
> PostResponse upsert_user_id_bookmark(bookmark_id, bookmark)

Create or Update a Bookmark. If the object has an BookmarkId, then an update is performed, otherwise a new object is created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.BookmarksApi(mixmode_api.ApiClient(configuration))
bookmark_id = 56 # int | 
bookmark = mixmode_api.IdBookmarkAttributes() # IdBookmarkAttributes | A bookmark is link to a specific object in the datalake.

try:
    # Create or Update a Bookmark. If the object has an BookmarkId, then an update is performed, otherwise a new object is created.
    api_response = api_instance.upsert_user_id_bookmark(bookmark_id, bookmark)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BookmarksApi->upsert_user_id_bookmark: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bookmark_id** | **int**|  | 
 **bookmark** | [**IdBookmarkAttributes**](IdBookmarkAttributes.md)| A bookmark is link to a specific object in the datalake. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **upsert_user_pql_bookmark**
> PostResponse upsert_user_pql_bookmark(bookmark_id, bookmark)

Create or Update a Bookmark. If the object has an BookmarkId, then an update is performed, otherwise a new object is created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.BookmarksApi(mixmode_api.ApiClient(configuration))
bookmark_id = 56 # int | 
bookmark = mixmode_api.PqlBookmarkAttributes() # PqlBookmarkAttributes | A bookmark is link to a specific object in the datalake.

try:
    # Create or Update a Bookmark. If the object has an BookmarkId, then an update is performed, otherwise a new object is created.
    api_response = api_instance.upsert_user_pql_bookmark(bookmark_id, bookmark)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BookmarksApi->upsert_user_pql_bookmark: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bookmark_id** | **int**|  | 
 **bookmark** | [**PqlBookmarkAttributes**](PqlBookmarkAttributes.md)| A bookmark is link to a specific object in the datalake. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

