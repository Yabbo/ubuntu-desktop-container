# mixmode_api.IntegrationsApi

All URIs are relative to *https://api.mixmode.ai/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add_sensor_to_integration**](IntegrationsApi.md#add_sensor_to_integration) | **POST** /integrations/{IntegrationId}/sensors/{SensorId} | Add a sensor to an integration.
[**add_tenant_to_integration**](IntegrationsApi.md#add_tenant_to_integration) | **POST** /integrations/{IntegrationId}/tenants/{TenantId} | Add a tenant to an integration.
[**clear_integration**](IntegrationsApi.md#clear_integration) | **POST** /integrations/{IntegrationId}/clear | Remove all direct associations with tenants and sensors. Will result in this integration being associated with all sensors by convention.
[**create_integration**](IntegrationsApi.md#create_integration) | **POST** /integrations | Create a new integration.
[**delete_integration**](IntegrationsApi.md#delete_integration) | **DELETE** /integrations/{IntegrationId} | Delete a single integration by unique identifier.
[**delete_sensor_from_integration**](IntegrationsApi.md#delete_sensor_from_integration) | **DELETE** /integrations/{IntegrationId}/sensors/{SensorId} | Remove a sensor from an integration.
[**delete_tenant_from_integration**](IntegrationsApi.md#delete_tenant_from_integration) | **DELETE** /integrations/{IntegrationId}/tenants/{TenantId} | Remove a tenant from an integration.
[**get_integration**](IntegrationsApi.md#get_integration) | **GET** /integrations/{IntegrationId} | Get a single integration by unique identifier.
[**get_integration_sensors**](IntegrationsApi.md#get_integration_sensors) | **GET** /integrations/{IntegrationId}/sensors | Return all sensors assigned to this integration.
[**get_integration_tenants**](IntegrationsApi.md#get_integration_tenants) | **GET** /integrations/{IntegrationId}/tenants | Return all tenants assigned to this integration.
[**get_integrations**](IntegrationsApi.md#get_integrations) | **GET** /integrations | Queries the system and returns a filtered, sorted, paged list of integration metadata objects.
[**upsert_integration**](IntegrationsApi.md#upsert_integration) | **POST** /integrations/{IntegrationId} | Create or Update a Integration. If the object has an IntegrationId, then an update is performed, otherwise a new object is created.


# **add_sensor_to_integration**
> PostResponse add_sensor_to_integration(integration_id, sensor_id)

Add a sensor to an integration.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IntegrationsApi(mixmode_api.ApiClient(configuration))
integration_id = 56 # int | 
sensor_id = 56 # int | 

try:
    # Add a sensor to an integration.
    api_response = api_instance.add_sensor_to_integration(integration_id, sensor_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IntegrationsApi->add_sensor_to_integration: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **integration_id** | **int**|  | 
 **sensor_id** | **int**|  | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **add_tenant_to_integration**
> PostResponse add_tenant_to_integration(integration_id, tenant_id)

Add a tenant to an integration.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IntegrationsApi(mixmode_api.ApiClient(configuration))
integration_id = 56 # int | 
tenant_id = 56 # int | 

try:
    # Add a tenant to an integration.
    api_response = api_instance.add_tenant_to_integration(integration_id, tenant_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IntegrationsApi->add_tenant_to_integration: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **integration_id** | **int**|  | 
 **tenant_id** | **int**|  | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **clear_integration**
> PostResponse clear_integration(integration_id)

Remove all direct associations with tenants and sensors. Will result in this integration being associated with all sensors by convention.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IntegrationsApi(mixmode_api.ApiClient(configuration))
integration_id = 56 # int | 

try:
    # Remove all direct associations with tenants and sensors. Will result in this integration being associated with all sensors by convention.
    api_response = api_instance.clear_integration(integration_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IntegrationsApi->clear_integration: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **integration_id** | **int**|  | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_integration**
> IntegrationResponse create_integration(integration)

Create a new integration.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IntegrationsApi(mixmode_api.ApiClient(configuration))
integration = mixmode_api.IntegrationAttributes() # IntegrationAttributes | An Integration is a named collection of patterns that can be used to label data according to tenant/sensor mappings.

try:
    # Create a new integration.
    api_response = api_instance.create_integration(integration)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IntegrationsApi->create_integration: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **integration** | [**IntegrationAttributes**](IntegrationAttributes.md)| An Integration is a named collection of patterns that can be used to label data according to tenant/sensor mappings. | 

### Return type

[**IntegrationResponse**](IntegrationResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_integration**
> delete_integration(integration_id)

Delete a single integration by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IntegrationsApi(mixmode_api.ApiClient(configuration))
integration_id = 56 # int | 

try:
    # Delete a single integration by unique identifier.
    api_instance.delete_integration(integration_id)
except ApiException as e:
    print("Exception when calling IntegrationsApi->delete_integration: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **integration_id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_sensor_from_integration**
> delete_sensor_from_integration(integration_id, sensor_id)

Remove a sensor from an integration.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IntegrationsApi(mixmode_api.ApiClient(configuration))
integration_id = 56 # int | 
sensor_id = 56 # int | 

try:
    # Remove a sensor from an integration.
    api_instance.delete_sensor_from_integration(integration_id, sensor_id)
except ApiException as e:
    print("Exception when calling IntegrationsApi->delete_sensor_from_integration: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **integration_id** | **int**|  | 
 **sensor_id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_tenant_from_integration**
> delete_tenant_from_integration(integration_id, tenant_id)

Remove a tenant from an integration.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IntegrationsApi(mixmode_api.ApiClient(configuration))
integration_id = 56 # int | 
tenant_id = 56 # int | 

try:
    # Remove a tenant from an integration.
    api_instance.delete_tenant_from_integration(integration_id, tenant_id)
except ApiException as e:
    print("Exception when calling IntegrationsApi->delete_tenant_from_integration: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **integration_id** | **int**|  | 
 **tenant_id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_integration**
> IntegrationResponse get_integration(integration_id)

Get a single integration by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IntegrationsApi(mixmode_api.ApiClient(configuration))
integration_id = 56 # int | 

try:
    # Get a single integration by unique identifier.
    api_response = api_instance.get_integration(integration_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IntegrationsApi->get_integration: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **integration_id** | **int**|  | 

### Return type

[**IntegrationResponse**](IntegrationResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_integration_sensors**
> PagedSensors get_integration_sensors(integration_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Return all sensors assigned to this integration.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IntegrationsApi(mixmode_api.ApiClient(configuration))
integration_id = 56 # int | 
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Return all sensors assigned to this integration.
    api_response = api_instance.get_integration_sensors(integration_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IntegrationsApi->get_integration_sensors: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **integration_id** | **int**|  | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedSensors**](PagedSensors.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_integration_tenants**
> PagedTenants get_integration_tenants(integration_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Return all tenants assigned to this integration.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IntegrationsApi(mixmode_api.ApiClient(configuration))
integration_id = 56 # int | 
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Return all tenants assigned to this integration.
    api_response = api_instance.get_integration_tenants(integration_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IntegrationsApi->get_integration_tenants: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **integration_id** | **int**|  | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedTenants**](PagedTenants.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_integrations**
> PagedIntegrations get_integrations(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of integration metadata objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IntegrationsApi(mixmode_api.ApiClient(configuration))
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of integration metadata objects.
    api_response = api_instance.get_integrations(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IntegrationsApi->get_integrations: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedIntegrations**](PagedIntegrations.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **upsert_integration**
> PostResponse upsert_integration(integration_id, integration)

Create or Update a Integration. If the object has an IntegrationId, then an update is performed, otherwise a new object is created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IntegrationsApi(mixmode_api.ApiClient(configuration))
integration_id = 56 # int | 
integration = mixmode_api.IntegrationAttributes() # IntegrationAttributes | An Integration is a named collection of patterns that can be used to label data according to tenant/sensor mappings.

try:
    # Create or Update a Integration. If the object has an IntegrationId, then an update is performed, otherwise a new object is created.
    api_response = api_instance.upsert_integration(integration_id, integration)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IntegrationsApi->upsert_integration: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **integration_id** | **int**|  | 
 **integration** | [**IntegrationAttributes**](IntegrationAttributes.md)| An Integration is a named collection of patterns that can be used to label data according to tenant/sensor mappings. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

