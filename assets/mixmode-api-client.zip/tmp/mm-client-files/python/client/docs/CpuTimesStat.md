# CpuTimesStat

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cpu** | **str** |  | [optional] 
**guest** | **float** |  | [optional] 
**guest_nice** | **float** |  | [optional] 
**idle** | **float** |  | [optional] 
**iowait** | **float** |  | [optional] 
**irq** | **float** |  | [optional] 
**nice** | **float** |  | [optional] 
**softirq** | **float** |  | [optional] 
**steal** | **float** |  | [optional] 
**stolen** | **float** |  | [optional] 
**system** | **float** |  | [optional] 
**user** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


