# MemVirtualMemoryStat

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**active** | **int** |  | [optional] 
**available** | **int** |  | [optional] 
**buffers** | **int** |  | [optional] 
**cached** | **int** |  | [optional] 
**dirty** | **int** |  | [optional] 
**free** | **int** |  | [optional] 
**inactive** | **int** |  | [optional] 
**pagetables** | **int** |  | [optional] 
**shared** | **int** |  | [optional] 
**slab** | **int** |  | [optional] 
**swapcached** | **int** |  | [optional] 
**total** | **int** |  | [optional] 
**used** | **int** |  | [optional] 
**used_percent** | **float** |  | [optional] 
**wired** | **int** |  | [optional] 
**writeback** | **int** |  | [optional] 
**writebacktmp** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


