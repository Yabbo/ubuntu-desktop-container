# mixmode_api.AssetsApi

All URIs are relative to *https://api.mixmode.ai/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**download_asset**](AssetsApi.md#download_asset) | **GET** /assets/download | Download an installation package by path.


# **download_asset**
> str download_asset(path)

Download an installation package by path.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'
# Configure API key authorization: SensorTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.AssetsApi(mixmode_api.ApiClient(configuration))
path = 'path_example' # str | The path of a file or directory relative to the root of profile or draft.

try:
    # Download an installation package by path.
    api_response = api_instance.download_asset(path)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AssetsApi->download_asset: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **path** | **str**| The path of a file or directory relative to the root of profile or draft. | 

### Return type

**str**

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity), [SensorTokenSecurity](../README.md#SensorTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/octet-stream

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

