# BroSensorConfigurationAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sshkey** | **str** | A key for connecting to git via ssh. | [optional] 
**token** | **str** | A reusable api token for connecting to the platform as this sensor. | [optional] 
**heartbeat_interval_seconds** | **int** | Period, in seconds, to emit heartbeats into the platform api. | [optional] 
**dns_proxy** | **str** | The comma separated list of ipv4 addresses to use as dns proxies. | [optional] 
**ip** | **str** | The ip address of the api server. | 
**bootstrap_package_url** | **str** | url for downloading the mmcli package | 
**hostname** | **str** | The dns resolvable hostname of the api server. | 
**git_server** | **str** | The dns resolvable hostname of the git server. | 
**sensor** | [**SensorResponse**](SensorResponse.md) |  | 
**provider_id** | **str** | The provider ID. | [optional] 
**transport** | [**SensorTransport**](SensorTransport.md) |  | [optional] 
**heartbeat_sys_stats** | **str** | The comma separated list of subsections from the /v2/sys_stats route that will be presented in each heartbeat | [optional] 
**wss_enabled** | **bool** | Configure the sensor to use the /wss_connect route | [optional] [default to True]
**container_oci** | **str** | The public path to the mixmode-sensor-chart oci | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


