# LoadAvgStat

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**load1** | **float** |  | [optional] 
**load15** | **float** |  | [optional] 
**load5** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


