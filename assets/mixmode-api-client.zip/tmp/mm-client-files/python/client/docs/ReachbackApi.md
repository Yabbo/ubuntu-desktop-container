# mixmode_api.ReachbackApi

All URIs are relative to *https://api.mixmode.ai/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_v2_ndr_stats**](ReachbackApi.md#get_v2_ndr_stats) | **GET** /tenants/{TenantId}/smf/sensors/{SensorId}/reachback/ndr/stats | Network Data Recorder Statistics
[**get_v2_sysstats**](ReachbackApi.md#get_v2_sysstats) | **GET** /tenants/{TenantId}/smf/sensors/{SensorId}/reachback/sys_stats | System Statistic Query
[**get_v2_version**](ReachbackApi.md#get_v2_version) | **GET** /tenants/{TenantId}/smf/sensors/{SensorId}/reachback/version | Version Query
[**post_v2_dir**](ReachbackApi.md#post_v2_dir) | **POST** /tenants/{TenantId}/smf/sensors/{SensorId}/reachback/dir | Directory Listing Interface
[**post_v2_ndr**](ReachbackApi.md#post_v2_ndr) | **POST** /tenants/{TenantId}/smf/sensors/{SensorId}/reachback/ndr | Network Data Recorder Query
[**post_v2_ndr_verify**](ReachbackApi.md#post_v2_ndr_verify) | **POST** /tenants/{TenantId}/smf/sensors/{SensorId}/reachback/ndr/verify | Network Data Recorder Verification
[**post_v2_sync**](ReachbackApi.md#post_v2_sync) | **POST** /tenants/{TenantId}/smf/sensors/{SensorId}/reachback/sync | Sensor Management Framework Synchronization Interface


# **get_v2_ndr_stats**
> MainndrV2statRet get_v2_ndr_stats(tenant_id, sensor_id)

Network Data Recorder Statistics

Network Data Recorder Statistics

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.ReachbackApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 

try:
    # Network Data Recorder Statistics
    api_response = api_instance.get_v2_ndr_stats(tenant_id, sensor_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ReachbackApi->get_v2_ndr_stats: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 

### Return type

[**MainndrV2statRet**](MainndrV2statRet.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_v2_sysstats**
> MainsysstatReturnV2 get_v2_sysstats(tenant_id, sensor_id)

System Statistic Query

System Statistic Query

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.ReachbackApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 

try:
    # System Statistic Query
    api_response = api_instance.get_v2_sysstats(tenant_id, sensor_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ReachbackApi->get_v2_sysstats: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 

### Return type

[**MainsysstatReturnV2**](MainsysstatReturnV2.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_v2_version**
> MainreturnV2 get_v2_version(tenant_id, sensor_id)

Version Query

Version Query

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.ReachbackApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 

try:
    # Version Query
    api_response = api_instance.get_v2_version(tenant_id, sensor_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ReachbackApi->get_v2_version: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 

### Return type

[**MainreturnV2**](MainreturnV2.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_v2_dir**
> MaindirReturnV2 post_v2_dir(tenant_id, sensor_id, body)

Directory Listing Interface

Directory Listing Interface

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.ReachbackApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
body = mixmode_api.MaindirBodyV2() # MaindirBodyV2 | Directory Listing Body

try:
    # Directory Listing Interface
    api_response = api_instance.post_v2_dir(tenant_id, sensor_id, body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ReachbackApi->post_v2_dir: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **body** | [**MaindirBodyV2**](MaindirBodyV2.md)| Directory Listing Body | 

### Return type

[**MaindirReturnV2**](MaindirReturnV2.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_v2_ndr**
> MainndrV2ret post_v2_ndr(tenant_id, sensor_id, body)

Network Data Recorder Query

Network Data Recorder Query

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.ReachbackApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
body = mixmode_api.MainndrBodyV2() # MainndrBodyV2 | Network Data Record Query Body

try:
    # Network Data Recorder Query
    api_response = api_instance.post_v2_ndr(tenant_id, sensor_id, body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ReachbackApi->post_v2_ndr: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **body** | [**MainndrBodyV2**](MainndrBodyV2.md)| Network Data Record Query Body | 

### Return type

[**MainndrV2ret**](MainndrV2ret.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_v2_ndr_verify**
> MainndrV2ret post_v2_ndr_verify(tenant_id, sensor_id, body)

Network Data Recorder Verification

Network Data Recorder Verification

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.ReachbackApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
body = mixmode_api.MainndrBodyV2() # MainndrBodyV2 | Network Data Record Query Body

try:
    # Network Data Recorder Verification
    api_response = api_instance.post_v2_ndr_verify(tenant_id, sensor_id, body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ReachbackApi->post_v2_ndr_verify: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **body** | [**MainndrBodyV2**](MainndrBodyV2.md)| Network Data Record Query Body | 

### Return type

[**MainndrV2ret**](MainndrV2ret.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_v2_sync**
> MainreturnV2 post_v2_sync(tenant_id, sensor_id, body)

Sensor Management Framework Synchronization Interface

SMF Interface

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.ReachbackApi(mixmode_api.ApiClient(configuration))
tenant_id = 56 # int | 
sensor_id = 56 # int | 
body = mixmode_api.MainsyncBodyV2() # MainsyncBodyV2 | Command to execute

try:
    # Sensor Management Framework Synchronization Interface
    api_response = api_instance.post_v2_sync(tenant_id, sensor_id, body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ReachbackApi->post_v2_sync: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant_id** | **int**|  | 
 **sensor_id** | **int**|  | 
 **body** | [**MainsyncBodyV2**](MainsyncBodyV2.md)| Command to execute | 

### Return type

[**MainreturnV2**](MainreturnV2.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

