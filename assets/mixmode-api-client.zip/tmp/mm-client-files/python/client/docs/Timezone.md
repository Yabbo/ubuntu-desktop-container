# Timezone

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_dst** | **bool** |  | [optional] 
**name** | **str** |  | [optional] 
**offset** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


