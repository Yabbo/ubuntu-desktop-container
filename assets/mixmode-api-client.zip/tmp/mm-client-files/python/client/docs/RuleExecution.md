# RuleExecution

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rule** | [**Rule**](Rule.md) |  | [optional] 
**executed_at** | **datetime** | Execution begin timestamp | [optional] 
**finished_at** | **datetime** | Execution finished timestamp | [optional] 
**indicators** | **list[int]** | A list of indicator ids created by this rule execution. | [optional] 
**alerts** | **list[int]** | A list of alerts ids created by this rule execution. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


