# SensorToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | A unique id for this token | [optional] 
**host** | **str** | The host on which this token is valid | [optional] 
**token** | **str** | the token used to authenticate a bootstrap request from a sensor | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


