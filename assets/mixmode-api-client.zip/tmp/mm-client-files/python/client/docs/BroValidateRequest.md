# BroValidateRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pcaps** | **list[int]** | A list of profile ids. The profiles must be of type pcap. For each profile id passed in, all pcap files contained within the profile will be sent to bro as part of the validation. The outputs will be placed in the folder named validation_results in the root directory of the draft. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


