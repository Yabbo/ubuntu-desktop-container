# IndicatorOverrides

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**list[IndicatorOverrideResponse]**](IndicatorOverrideResponse.md) | An array of IndicatorOverrides. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


