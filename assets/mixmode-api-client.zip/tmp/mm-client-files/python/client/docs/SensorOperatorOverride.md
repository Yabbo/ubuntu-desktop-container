# SensorOperatorOverride

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **datetime** | Creation timestamp | [optional] 
**updated_at** | **datetime** | Update timestamp | [optional] 
**enabled** | **bool** | Whether or not operator is disabled. Disabled operators will not execute. | [default to True]
**indicators** | **bool** | Whether or not operator should surface indicators. | [default to True]
**alerts** | **bool** | Whether or not operator should surface alerts. | [default to True]
**data** | **object** | Data for the operator configuration. | [optional] 
**operator_id** | **str** | The id of the operator being overridden. | 
**tenant_id** | **int** | The tenant id of the sensor being overridden. | [optional] 
**sensor_id** | **int** | The id of the sensor being overridden. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


