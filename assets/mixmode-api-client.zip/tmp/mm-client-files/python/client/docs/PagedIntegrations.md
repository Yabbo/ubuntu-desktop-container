# PagedIntegrations

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_items** | **int** | The total number of items matching the request | [optional] 
**total_pages** | **int** | The total number of pages that can be requested | [optional] 
**page_size** | **int** | The number of items per page | [optional] 
**page_number** | **int** | The current page number | [optional] 
**items** | [**list[IntegrationResponse]**](IntegrationResponse.md) | An array of Integrations. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


