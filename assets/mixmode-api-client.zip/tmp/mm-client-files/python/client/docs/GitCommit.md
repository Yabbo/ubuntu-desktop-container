# GitCommit

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**branch** | **str** | Results of a git commit, branch | [optional] 
**commit** | **str** | Results of a git commit, commit | [optional] 
**changes** | **int** | Results of a git commit, # of changes | [optional] 
**insertions** | **int** | Results of a git commit, # of insertions | [optional] 
**deletions** | **int** | Results of a git commit, # of deletions | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


