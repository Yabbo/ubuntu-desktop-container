# BulkQueryResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**list[SearchResults]**](SearchResults.md) | An array of queries. | [optional] 
**errors** | [**list[ApiError]**](ApiError.md) | An array of errors. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


