# OperatorOverride

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Unique Identifier representing a document | 
**created_at** | **datetime** | Creation timestamp | [optional] 
**updated_at** | **datetime** | Update timestamp | [optional] 
**enabled** | **bool** | Whether or not operator is disabled. Disabled operators will not execute. | [default to True]
**indicators** | **bool** | Whether or not operator should surface indicators. | [default to True]
**alerts** | **bool** | Whether or not operator should surface alerts. | [default to True]
**data** | **object** | Data for the operator configuration. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


