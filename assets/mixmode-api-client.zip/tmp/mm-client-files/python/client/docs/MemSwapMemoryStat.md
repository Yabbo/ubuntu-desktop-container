# MemSwapMemoryStat

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**free** | **int** |  | [optional] 
**sin** | **int** |  | [optional] 
**sout** | **int** |  | [optional] 
**total** | **int** |  | [optional] 
**used** | **int** |  | [optional] 
**used_percent** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


