# SensorMetricsResultsContext

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**document_count** | **float** |  | [optional] 
**bytes_recv** | **float** |  | [optional] 
**mbps_mean** | **float** |  | [optional] 
**mbps_peak** | **float** |  | [optional] 
**mbps_percentile_75** | **float** |  | [optional] 
**mbps_percentile_95** | **float** |  | [optional] 
**docs_mean** | **float** |  | [optional] 
**docs_peak** | **float** |  | [optional] 
**docs_percentile_75** | **float** |  | [optional] 
**docs_percentile_95** | **float** |  | [optional] 
**values** | [**list[SensorMetricValue]**](SensorMetricValue.md) | A list of sensor metrics by time | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


