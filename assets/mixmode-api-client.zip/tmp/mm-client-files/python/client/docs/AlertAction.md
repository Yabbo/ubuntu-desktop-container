# AlertAction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**severity** | **int** | The measure of how severe this alert is. Range is from 0 to 10, higher values are more serious. | [optional] 
**killchain_id** | **int** |  | [optional] 
**assignee** | **str** | The default user to assign the created alert to. | [optional] 
**name** | **str** |  | 
**description** | **str** |  | 
**labels** | **list[str]** |  | [optional] 
**data** | [**AlertActionData**](AlertActionData.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


