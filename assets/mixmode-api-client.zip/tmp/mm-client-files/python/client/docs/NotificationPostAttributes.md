# NotificationPostAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **str** | The message. | [optional] 
**assigned** | **str** |  | [optional] 
**labels** | **list[str]** |  | [optional] 
**status** | **str** |  | [optional] 
**data** | [**NotificationMetadata**](NotificationMetadata.md) |  | [optional] 
**notification_type_id** | **int** |  | [optional] 
**tenant_id** | **int** |  | [optional] 
**sensor_id** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


