# Indicator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Unique Identifier representing a document | 
**created_at** | **datetime** | Creation timestamp | [optional] 
**updated_at** | **datetime** | Update timestamp | [optional] 
**indicator_id** | **str** |  | 
**indicator_title** | **str** |  | 
**uid** | **str** |  | [optional] 
**tenant_name** | **str** |  | [optional] 
**tenant_id** | **int** |  | 
**sensor_name** | **str** |  | [optional] 
**sensor_id** | **int** |  | 
**ps_defining_query** | **str** |  | [optional] 
**entity** | **str** |  | [optional] 
**geo** | **str** |  | [optional] 
**killchain** | **str** |  | [optional] 
**log** | **str** |  | [optional] 
**key** | **str** |  | [optional] 
**value** | **str** |  | [optional] 
**severity** | **float** |  | [optional] 
**impact** | **str** |  | [optional] 
**risk_score** | **float** |  | [optional] 
**impact_score** | **float** |  | [optional] 
**ts** | **float** |  | 
**data** | **object** |  | [optional] 
**labels** | **list[str]** |  | [optional] 
**ailabels** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


