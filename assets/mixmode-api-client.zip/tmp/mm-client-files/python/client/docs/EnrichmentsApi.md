# mixmode_api.EnrichmentsApi

All URIs are relative to *https://api.mixmode.ai/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add_sensor_to_enrichment**](EnrichmentsApi.md#add_sensor_to_enrichment) | **POST** /enrichments/{EnrichmentId}/sensors/{SensorId} | Add a sensor to an enrichment.
[**add_tenant_to_enrichment**](EnrichmentsApi.md#add_tenant_to_enrichment) | **POST** /enrichments/{EnrichmentId}/tenants/{TenantId} | Add a tenant to an enrichment.
[**clear_enrichment**](EnrichmentsApi.md#clear_enrichment) | **POST** /enrichments/{EnrichmentId}/clear | Remove all direct associations with tenants and sensors. Will result in this enrichment being associated with all sensors by convention.
[**create_enrichment**](EnrichmentsApi.md#create_enrichment) | **POST** /enrichments | Create a new enrichment.
[**create_enrichment_item**](EnrichmentsApi.md#create_enrichment_item) | **POST** /enrichments/{EnrichmentId}/items | Create a new enrichment item.
[**delete_enrichment**](EnrichmentsApi.md#delete_enrichment) | **DELETE** /enrichments/{EnrichmentId} | Delete a single enrichment by unique identifier.
[**delete_enrichment_item**](EnrichmentsApi.md#delete_enrichment_item) | **DELETE** /enrichments/{EnrichmentId}/items/{EnrichmentItemId} | Delete a single enrichment by unique identifier.
[**delete_sensor_from_enrichment**](EnrichmentsApi.md#delete_sensor_from_enrichment) | **DELETE** /enrichments/{EnrichmentId}/sensors/{SensorId} | Remove a sensor from an enrichment.
[**delete_tenant_from_enrichment**](EnrichmentsApi.md#delete_tenant_from_enrichment) | **DELETE** /enrichments/{EnrichmentId}/tenants/{TenantId} | Remove a tenant from an enrichment.
[**get_enrichment**](EnrichmentsApi.md#get_enrichment) | **GET** /enrichments/{EnrichmentId} | Get a single enrichment by unique identifier.
[**get_enrichment_item**](EnrichmentsApi.md#get_enrichment_item) | **GET** /enrichments/{EnrichmentId}/items/{EnrichmentItemId} | Get a single enrichment by unique identifier.
[**get_enrichment_items**](EnrichmentsApi.md#get_enrichment_items) | **GET** /enrichments/{EnrichmentId}/items | Queries the system and returns a filtered, sorted, paged list of enrichment item objects.
[**get_enrichment_sensors**](EnrichmentsApi.md#get_enrichment_sensors) | **GET** /enrichments/{EnrichmentId}/sensors | Return all sensors assigned to this enrichment.
[**get_enrichment_tenants**](EnrichmentsApi.md#get_enrichment_tenants) | **GET** /enrichments/{EnrichmentId}/tenants | Return all tenants assigned to this enrichment.
[**get_enrichments**](EnrichmentsApi.md#get_enrichments) | **GET** /enrichments | Queries the system and returns a filtered, sorted, paged list of enrichment metadata objects.
[**import_enrichment_items**](EnrichmentsApi.md#import_enrichment_items) | **POST** /enrichments/{EnrichmentId}/import | Upload enrichment items from a file.
[**upsert_enrichment**](EnrichmentsApi.md#upsert_enrichment) | **POST** /enrichments/{EnrichmentId} | Create or Update a Enrichment. If the object has an EnrichmentId, then an update is performed, otherwise a new object is created.
[**upsert_enrichment_item**](EnrichmentsApi.md#upsert_enrichment_item) | **POST** /enrichments/{EnrichmentId}/items/{EnrichmentItemId} | Create or Update a Enrichment. If the object has an EnrichmentId, then an update is performed, otherwise a new object is created.


# **add_sensor_to_enrichment**
> PostResponse add_sensor_to_enrichment(enrichment_id, sensor_id)

Add a sensor to an enrichment.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EnrichmentsApi(mixmode_api.ApiClient(configuration))
enrichment_id = 56 # int | 
sensor_id = 56 # int | 

try:
    # Add a sensor to an enrichment.
    api_response = api_instance.add_sensor_to_enrichment(enrichment_id, sensor_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EnrichmentsApi->add_sensor_to_enrichment: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enrichment_id** | **int**|  | 
 **sensor_id** | **int**|  | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **add_tenant_to_enrichment**
> PostResponse add_tenant_to_enrichment(enrichment_id, tenant_id)

Add a tenant to an enrichment.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EnrichmentsApi(mixmode_api.ApiClient(configuration))
enrichment_id = 56 # int | 
tenant_id = 56 # int | 

try:
    # Add a tenant to an enrichment.
    api_response = api_instance.add_tenant_to_enrichment(enrichment_id, tenant_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EnrichmentsApi->add_tenant_to_enrichment: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enrichment_id** | **int**|  | 
 **tenant_id** | **int**|  | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **clear_enrichment**
> PostResponse clear_enrichment(enrichment_id)

Remove all direct associations with tenants and sensors. Will result in this enrichment being associated with all sensors by convention.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EnrichmentsApi(mixmode_api.ApiClient(configuration))
enrichment_id = 56 # int | 

try:
    # Remove all direct associations with tenants and sensors. Will result in this enrichment being associated with all sensors by convention.
    api_response = api_instance.clear_enrichment(enrichment_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EnrichmentsApi->clear_enrichment: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enrichment_id** | **int**|  | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_enrichment**
> EnrichmentResponse create_enrichment(enrichment)

Create a new enrichment.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EnrichmentsApi(mixmode_api.ApiClient(configuration))
enrichment = mixmode_api.EnrichmentUpdateAttributes() # EnrichmentUpdateAttributes | An Enrichment is a named collection of patterns that can be used to label data according to tenant/sensor mappings.

try:
    # Create a new enrichment.
    api_response = api_instance.create_enrichment(enrichment)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EnrichmentsApi->create_enrichment: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enrichment** | [**EnrichmentUpdateAttributes**](EnrichmentUpdateAttributes.md)| An Enrichment is a named collection of patterns that can be used to label data according to tenant/sensor mappings. | 

### Return type

[**EnrichmentResponse**](EnrichmentResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_enrichment_item**
> EnrichmentItemResponse create_enrichment_item(enrichment_id, enrichment_item)

Create a new enrichment item.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EnrichmentsApi(mixmode_api.ApiClient(configuration))
enrichment_id = 56 # int | 
enrichment_item = mixmode_api.EnrichmentItemUpdateAttributes() # EnrichmentItemUpdateAttributes | An EnrichmentItem is a single pattern that can be used to label data according to tenant/sensor mappings.

try:
    # Create a new enrichment item.
    api_response = api_instance.create_enrichment_item(enrichment_id, enrichment_item)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EnrichmentsApi->create_enrichment_item: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enrichment_id** | **int**|  | 
 **enrichment_item** | [**EnrichmentItemUpdateAttributes**](EnrichmentItemUpdateAttributes.md)| An EnrichmentItem is a single pattern that can be used to label data according to tenant/sensor mappings. | 

### Return type

[**EnrichmentItemResponse**](EnrichmentItemResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_enrichment**
> delete_enrichment(enrichment_id)

Delete a single enrichment by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EnrichmentsApi(mixmode_api.ApiClient(configuration))
enrichment_id = 56 # int | 

try:
    # Delete a single enrichment by unique identifier.
    api_instance.delete_enrichment(enrichment_id)
except ApiException as e:
    print("Exception when calling EnrichmentsApi->delete_enrichment: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enrichment_id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_enrichment_item**
> delete_enrichment_item(enrichment_id, enrichment_item_id)

Delete a single enrichment by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EnrichmentsApi(mixmode_api.ApiClient(configuration))
enrichment_id = 56 # int | 
enrichment_item_id = 56 # int | 

try:
    # Delete a single enrichment by unique identifier.
    api_instance.delete_enrichment_item(enrichment_id, enrichment_item_id)
except ApiException as e:
    print("Exception when calling EnrichmentsApi->delete_enrichment_item: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enrichment_id** | **int**|  | 
 **enrichment_item_id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_sensor_from_enrichment**
> delete_sensor_from_enrichment(enrichment_id, sensor_id)

Remove a sensor from an enrichment.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EnrichmentsApi(mixmode_api.ApiClient(configuration))
enrichment_id = 56 # int | 
sensor_id = 56 # int | 

try:
    # Remove a sensor from an enrichment.
    api_instance.delete_sensor_from_enrichment(enrichment_id, sensor_id)
except ApiException as e:
    print("Exception when calling EnrichmentsApi->delete_sensor_from_enrichment: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enrichment_id** | **int**|  | 
 **sensor_id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_tenant_from_enrichment**
> delete_tenant_from_enrichment(enrichment_id, tenant_id)

Remove a tenant from an enrichment.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EnrichmentsApi(mixmode_api.ApiClient(configuration))
enrichment_id = 56 # int | 
tenant_id = 56 # int | 

try:
    # Remove a tenant from an enrichment.
    api_instance.delete_tenant_from_enrichment(enrichment_id, tenant_id)
except ApiException as e:
    print("Exception when calling EnrichmentsApi->delete_tenant_from_enrichment: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enrichment_id** | **int**|  | 
 **tenant_id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_enrichment**
> EnrichmentResponse get_enrichment(enrichment_id)

Get a single enrichment by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EnrichmentsApi(mixmode_api.ApiClient(configuration))
enrichment_id = 56 # int | 

try:
    # Get a single enrichment by unique identifier.
    api_response = api_instance.get_enrichment(enrichment_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EnrichmentsApi->get_enrichment: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enrichment_id** | **int**|  | 

### Return type

[**EnrichmentResponse**](EnrichmentResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_enrichment_item**
> EnrichmentItemResponse get_enrichment_item(enrichment_id, enrichment_item_id)

Get a single enrichment by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EnrichmentsApi(mixmode_api.ApiClient(configuration))
enrichment_id = 56 # int | 
enrichment_item_id = 56 # int | 

try:
    # Get a single enrichment by unique identifier.
    api_response = api_instance.get_enrichment_item(enrichment_id, enrichment_item_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EnrichmentsApi->get_enrichment_item: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enrichment_id** | **int**|  | 
 **enrichment_item_id** | **int**|  | 

### Return type

[**EnrichmentItemResponse**](EnrichmentItemResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_enrichment_items**
> PagedEnrichmentItems get_enrichment_items(enrichment_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of enrichment item objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EnrichmentsApi(mixmode_api.ApiClient(configuration))
enrichment_id = 56 # int | 
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of enrichment item objects.
    api_response = api_instance.get_enrichment_items(enrichment_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EnrichmentsApi->get_enrichment_items: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enrichment_id** | **int**|  | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedEnrichmentItems**](PagedEnrichmentItems.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_enrichment_sensors**
> PagedSensors get_enrichment_sensors(enrichment_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Return all sensors assigned to this enrichment.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EnrichmentsApi(mixmode_api.ApiClient(configuration))
enrichment_id = 56 # int | 
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Return all sensors assigned to this enrichment.
    api_response = api_instance.get_enrichment_sensors(enrichment_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EnrichmentsApi->get_enrichment_sensors: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enrichment_id** | **int**|  | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedSensors**](PagedSensors.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_enrichment_tenants**
> PagedTenants get_enrichment_tenants(enrichment_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Return all tenants assigned to this enrichment.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EnrichmentsApi(mixmode_api.ApiClient(configuration))
enrichment_id = 56 # int | 
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Return all tenants assigned to this enrichment.
    api_response = api_instance.get_enrichment_tenants(enrichment_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EnrichmentsApi->get_enrichment_tenants: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enrichment_id** | **int**|  | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedTenants**](PagedTenants.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_enrichments**
> PagedEnrichments get_enrichments(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of enrichment metadata objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EnrichmentsApi(mixmode_api.ApiClient(configuration))
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of enrichment metadata objects.
    api_response = api_instance.get_enrichments(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EnrichmentsApi->get_enrichments: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedEnrichments**](PagedEnrichments.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **import_enrichment_items**
> ImportEnrichmentItemsResponse import_enrichment_items(enrichment_id, file=file)

Upload enrichment items from a file.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EnrichmentsApi(mixmode_api.ApiClient(configuration))
enrichment_id = 56 # int | 
file = '/path/to/file.txt' # file | The file to upload (optional)

try:
    # Upload enrichment items from a file.
    api_response = api_instance.import_enrichment_items(enrichment_id, file=file)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EnrichmentsApi->import_enrichment_items: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enrichment_id** | **int**|  | 
 **file** | **file**| The file to upload | [optional] 

### Return type

[**ImportEnrichmentItemsResponse**](ImportEnrichmentItemsResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **upsert_enrichment**
> PostResponse upsert_enrichment(enrichment_id, enrichment)

Create or Update a Enrichment. If the object has an EnrichmentId, then an update is performed, otherwise a new object is created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EnrichmentsApi(mixmode_api.ApiClient(configuration))
enrichment_id = 56 # int | 
enrichment = mixmode_api.EnrichmentUpdateAttributes() # EnrichmentUpdateAttributes | An Enrichment is a named collection of patterns that can be used to label data according to tenant/sensor mappings.

try:
    # Create or Update a Enrichment. If the object has an EnrichmentId, then an update is performed, otherwise a new object is created.
    api_response = api_instance.upsert_enrichment(enrichment_id, enrichment)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EnrichmentsApi->upsert_enrichment: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enrichment_id** | **int**|  | 
 **enrichment** | [**EnrichmentUpdateAttributes**](EnrichmentUpdateAttributes.md)| An Enrichment is a named collection of patterns that can be used to label data according to tenant/sensor mappings. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **upsert_enrichment_item**
> PostResponse upsert_enrichment_item(enrichment_id, enrichment_item_id, enrichment_item)

Create or Update a Enrichment. If the object has an EnrichmentId, then an update is performed, otherwise a new object is created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.EnrichmentsApi(mixmode_api.ApiClient(configuration))
enrichment_id = 56 # int | 
enrichment_item_id = 56 # int | 
enrichment_item = mixmode_api.EnrichmentItemUpdateAttributes() # EnrichmentItemUpdateAttributes | An EnrichmentItem is a single pattern that can be used to label data according to tenant/sensor mappings.

try:
    # Create or Update a Enrichment. If the object has an EnrichmentId, then an update is performed, otherwise a new object is created.
    api_response = api_instance.upsert_enrichment_item(enrichment_id, enrichment_item_id, enrichment_item)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EnrichmentsApi->upsert_enrichment_item: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enrichment_id** | **int**|  | 
 **enrichment_item_id** | **int**|  | 
 **enrichment_item** | [**EnrichmentItemUpdateAttributes**](EnrichmentItemUpdateAttributes.md)| An EnrichmentItem is a single pattern that can be used to label data according to tenant/sensor mappings. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

