# mixmode_api.IndicatorOverridesApi

All URIs are relative to *https://api.mixmode.ai/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add_sensor_to_indicator_override**](IndicatorOverridesApi.md#add_sensor_to_indicator_override) | **POST** /indicatoroverrides/{IndicatorOverrideId}/sensors/{SensorId} | Add a sensor to an indicatoroverride.
[**add_tenant_to_indicator_override**](IndicatorOverridesApi.md#add_tenant_to_indicator_override) | **POST** /indicatoroverrides/{IndicatorOverrideId}/tenants/{TenantId} | Add a tenant to an indicatoroverride.
[**clear_indicator_override**](IndicatorOverridesApi.md#clear_indicator_override) | **POST** /indicatoroverrides/{IndicatorOverrideId}/clear | Remove all direct associations with tenants and sensors. Will result in this indicatoroverride being associated with all sensors by convention.
[**create_indicator_override**](IndicatorOverridesApi.md#create_indicator_override) | **POST** /indicatoroverrides | Create a new indicatoroverride.
[**delete_indicator_override**](IndicatorOverridesApi.md#delete_indicator_override) | **DELETE** /indicatoroverrides/{IndicatorOverrideId} | Delete a single indicatoroverride by unique identifier.
[**delete_sensor_from_indicator_override**](IndicatorOverridesApi.md#delete_sensor_from_indicator_override) | **DELETE** /indicatoroverrides/{IndicatorOverrideId}/sensors/{SensorId} | Remove a sensor from an indicatoroverride.
[**delete_tenant_from_indicator_override**](IndicatorOverridesApi.md#delete_tenant_from_indicator_override) | **DELETE** /indicatoroverrides/{IndicatorOverrideId}/tenants/{TenantId} | Remove a tenant from an indicatoroverride.
[**get_indicator_override**](IndicatorOverridesApi.md#get_indicator_override) | **GET** /indicatoroverrides/{IndicatorOverrideId} | Get a single indicatoroverride by unique identifier.
[**get_indicator_override_sensors**](IndicatorOverridesApi.md#get_indicator_override_sensors) | **GET** /indicatoroverrides/{IndicatorOverrideId}/sensors | Return all sensors assigned to this indicatoroverride.
[**get_indicator_override_tenants**](IndicatorOverridesApi.md#get_indicator_override_tenants) | **GET** /indicatoroverrides/{IndicatorOverrideId}/tenants | Return all tenants assigned to this indicatoroverride.
[**get_indicator_overrides**](IndicatorOverridesApi.md#get_indicator_overrides) | **GET** /indicatoroverrides | Queries the system and returns a filtered, sorted, paged list of indicatoroverride metadata objects.
[**upsert_indicator_override**](IndicatorOverridesApi.md#upsert_indicator_override) | **POST** /indicatoroverrides/{IndicatorOverrideId} | Create or Update a IndicatorOverride. If the object has an IndicatorOverrideId, then an update is performed, otherwise a new object is created.


# **add_sensor_to_indicator_override**
> PostResponse add_sensor_to_indicator_override(indicator_override_id, sensor_id)

Add a sensor to an indicatoroverride.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IndicatorOverridesApi(mixmode_api.ApiClient(configuration))
indicator_override_id = 56 # int | 
sensor_id = 56 # int | 

try:
    # Add a sensor to an indicatoroverride.
    api_response = api_instance.add_sensor_to_indicator_override(indicator_override_id, sensor_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IndicatorOverridesApi->add_sensor_to_indicator_override: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **indicator_override_id** | **int**|  | 
 **sensor_id** | **int**|  | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **add_tenant_to_indicator_override**
> PostResponse add_tenant_to_indicator_override(indicator_override_id, tenant_id)

Add a tenant to an indicatoroverride.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IndicatorOverridesApi(mixmode_api.ApiClient(configuration))
indicator_override_id = 56 # int | 
tenant_id = 56 # int | 

try:
    # Add a tenant to an indicatoroverride.
    api_response = api_instance.add_tenant_to_indicator_override(indicator_override_id, tenant_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IndicatorOverridesApi->add_tenant_to_indicator_override: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **indicator_override_id** | **int**|  | 
 **tenant_id** | **int**|  | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **clear_indicator_override**
> PostResponse clear_indicator_override(indicator_override_id)

Remove all direct associations with tenants and sensors. Will result in this indicatoroverride being associated with all sensors by convention.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IndicatorOverridesApi(mixmode_api.ApiClient(configuration))
indicator_override_id = 56 # int | 

try:
    # Remove all direct associations with tenants and sensors. Will result in this indicatoroverride being associated with all sensors by convention.
    api_response = api_instance.clear_indicator_override(indicator_override_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IndicatorOverridesApi->clear_indicator_override: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **indicator_override_id** | **int**|  | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_indicator_override**
> IndicatorOverrideResponse create_indicator_override(indicator_override)

Create a new indicatoroverride.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IndicatorOverridesApi(mixmode_api.ApiClient(configuration))
indicator_override = mixmode_api.IndicatorOverrideUpdateAttributes() # IndicatorOverrideUpdateAttributes | An IndicatorOverride is a named collection of patterns that can be used to override fields of indicators according to tenant/sensor mappings.

try:
    # Create a new indicatoroverride.
    api_response = api_instance.create_indicator_override(indicator_override)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IndicatorOverridesApi->create_indicator_override: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **indicator_override** | [**IndicatorOverrideUpdateAttributes**](IndicatorOverrideUpdateAttributes.md)| An IndicatorOverride is a named collection of patterns that can be used to override fields of indicators according to tenant/sensor mappings. | 

### Return type

[**IndicatorOverrideResponse**](IndicatorOverrideResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_indicator_override**
> delete_indicator_override(indicator_override_id)

Delete a single indicatoroverride by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IndicatorOverridesApi(mixmode_api.ApiClient(configuration))
indicator_override_id = 56 # int | 

try:
    # Delete a single indicatoroverride by unique identifier.
    api_instance.delete_indicator_override(indicator_override_id)
except ApiException as e:
    print("Exception when calling IndicatorOverridesApi->delete_indicator_override: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **indicator_override_id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_sensor_from_indicator_override**
> delete_sensor_from_indicator_override(indicator_override_id, sensor_id)

Remove a sensor from an indicatoroverride.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IndicatorOverridesApi(mixmode_api.ApiClient(configuration))
indicator_override_id = 56 # int | 
sensor_id = 56 # int | 

try:
    # Remove a sensor from an indicatoroverride.
    api_instance.delete_sensor_from_indicator_override(indicator_override_id, sensor_id)
except ApiException as e:
    print("Exception when calling IndicatorOverridesApi->delete_sensor_from_indicator_override: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **indicator_override_id** | **int**|  | 
 **sensor_id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_tenant_from_indicator_override**
> delete_tenant_from_indicator_override(indicator_override_id, tenant_id)

Remove a tenant from an indicatoroverride.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IndicatorOverridesApi(mixmode_api.ApiClient(configuration))
indicator_override_id = 56 # int | 
tenant_id = 56 # int | 

try:
    # Remove a tenant from an indicatoroverride.
    api_instance.delete_tenant_from_indicator_override(indicator_override_id, tenant_id)
except ApiException as e:
    print("Exception when calling IndicatorOverridesApi->delete_tenant_from_indicator_override: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **indicator_override_id** | **int**|  | 
 **tenant_id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_indicator_override**
> IndicatorOverrideResponse get_indicator_override(indicator_override_id)

Get a single indicatoroverride by unique identifier.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IndicatorOverridesApi(mixmode_api.ApiClient(configuration))
indicator_override_id = 56 # int | 

try:
    # Get a single indicatoroverride by unique identifier.
    api_response = api_instance.get_indicator_override(indicator_override_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IndicatorOverridesApi->get_indicator_override: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **indicator_override_id** | **int**|  | 

### Return type

[**IndicatorOverrideResponse**](IndicatorOverrideResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_indicator_override_sensors**
> PagedSensors get_indicator_override_sensors(indicator_override_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Return all sensors assigned to this indicatoroverride.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IndicatorOverridesApi(mixmode_api.ApiClient(configuration))
indicator_override_id = 56 # int | 
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Return all sensors assigned to this indicatoroverride.
    api_response = api_instance.get_indicator_override_sensors(indicator_override_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IndicatorOverridesApi->get_indicator_override_sensors: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **indicator_override_id** | **int**|  | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedSensors**](PagedSensors.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_indicator_override_tenants**
> PagedTenants get_indicator_override_tenants(indicator_override_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Return all tenants assigned to this indicatoroverride.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IndicatorOverridesApi(mixmode_api.ApiClient(configuration))
indicator_override_id = 56 # int | 
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Return all tenants assigned to this indicatoroverride.
    api_response = api_instance.get_indicator_override_tenants(indicator_override_id, page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IndicatorOverridesApi->get_indicator_override_tenants: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **indicator_override_id** | **int**|  | 
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedTenants**](PagedTenants.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_indicator_overrides**
> PagedIndicatorOverrides get_indicator_overrides(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)

Queries the system and returns a filtered, sorted, paged list of indicatoroverride metadata objects.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IndicatorOverridesApi(mixmode_api.ApiClient(configuration))
page_size = 10000 # int | Number of items per page (optional) (default to 10000)
page_number = 1 # int | One-based initial page number (optional) (default to 1)
query_constraint = '{}' # str | A stringified JSON object containing attributes to match. ex: {\"name\": {\"$like\": \"%foobar%\"}} (optional) (default to {})
sort_constraint = '[]' # str | A stringified JSON array of arrays of attribute/direction to sort by. ex: [['createdAt', 'DESC']] (optional) (default to [])

try:
    # Queries the system and returns a filtered, sorted, paged list of indicatoroverride metadata objects.
    api_response = api_instance.get_indicator_overrides(page_size=page_size, page_number=page_number, query_constraint=query_constraint, sort_constraint=sort_constraint)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IndicatorOverridesApi->get_indicator_overrides: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of items per page | [optional] [default to 10000]
 **page_number** | **int**| One-based initial page number | [optional] [default to 1]
 **query_constraint** | **str**| A stringified JSON object containing attributes to match. ex: {\&quot;name\&quot;: {\&quot;$like\&quot;: \&quot;%foobar%\&quot;}} | [optional] [default to {}]
 **sort_constraint** | **str**| A stringified JSON array of arrays of attribute/direction to sort by. ex: [[&#39;createdAt&#39;, &#39;DESC&#39;]] | [optional] [default to []]

### Return type

[**PagedIndicatorOverrides**](PagedIndicatorOverrides.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **upsert_indicator_override**
> PostResponse upsert_indicator_override(indicator_override_id, indicator_override)

Create or Update a IndicatorOverride. If the object has an IndicatorOverrideId, then an update is performed, otherwise a new object is created.

### Example
```python
from __future__ import print_function
import time
import mixmode_api
from mixmode_api.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiHeaderTokenSecurity
configuration = mixmode_api.Configuration()
configuration.api_key['x-mixmode-api-token'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-mixmode-api-token'] = 'Bearer'

# create an instance of the API class
api_instance = mixmode_api.IndicatorOverridesApi(mixmode_api.ApiClient(configuration))
indicator_override_id = 56 # int | 
indicator_override = mixmode_api.IndicatorOverrideUpdateAttributes() # IndicatorOverrideUpdateAttributes | An IndicatorOverride is a named collection of patterns that can be used to override fields of indicators according to tenant/sensor mappings.

try:
    # Create or Update a IndicatorOverride. If the object has an IndicatorOverrideId, then an update is performed, otherwise a new object is created.
    api_response = api_instance.upsert_indicator_override(indicator_override_id, indicator_override)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IndicatorOverridesApi->upsert_indicator_override: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **indicator_override_id** | **int**|  | 
 **indicator_override** | [**IndicatorOverrideUpdateAttributes**](IndicatorOverrideUpdateAttributes.md)| An IndicatorOverride is a named collection of patterns that can be used to override fields of indicators according to tenant/sensor mappings. | 

### Return type

[**PostResponse**](PostResponse.md)

### Authorization

[ApiHeaderTokenSecurity](../README.md#ApiHeaderTokenSecurity)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

