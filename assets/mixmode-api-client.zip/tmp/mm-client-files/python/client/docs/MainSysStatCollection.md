# MainSysStatCollection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bandwidth** | **object** |  | [optional] 
**cpu_info** | [**list[CpuInfoStat]**](CpuInfoStat.md) |  | [optional] 
**cpu_times** | [**list[CpuTimesStat]**](CpuTimesStat.md) |  | [optional] 
**cpu_usage** | **object** |  | [optional] 
**_date** | **str** |  | [optional] 
**disk_io** | **object** |  | [optional] 
**disk_part** | [**list[DiskPartitionStat]**](DiskPartitionStat.md) |  | [optional] 
**disk_usage** | [**list[DiskUsageStat]**](DiskUsageStat.md) |  | [optional] 
**host_info** | [**HostInfoStat**](HostInfoStat.md) |  | [optional] 
**load_average** | [**LoadAvgStat**](LoadAvgStat.md) |  | [optional] 
**netstat** | [**list[NetConnectionStat]**](NetConnectionStat.md) |  | [optional] 
**network** | [**list[NetIOCountersStat]**](NetIOCountersStat.md) |  | [optional] 
**open_ports** | **str** |  | [optional] 
**packages** | [**list[MainRpmEntry]**](MainRpmEntry.md) |  | [optional] 
**password_changes** | **str** |  | [optional] 
**phy_cpu_count** | **int** |  | [optional] 
**ps** | [**list[MainPSaxInfo]**](MainPSaxInfo.md) |  | [optional] 
**sensor_version** | **str** |  | [optional] 
**swap_memory** | [**MemSwapMemoryStat**](MemSwapMemoryStat.md) |  | [optional] 
**var_log_messages** | **str** |  | [optional] 
**virtual_memory** | [**MemVirtualMemoryStat**](MemVirtualMemoryStat.md) |  | [optional] 
**vmstat** | **str** |  | [optional] 
**who** | [**list[HostUserStat]**](HostUserStat.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


