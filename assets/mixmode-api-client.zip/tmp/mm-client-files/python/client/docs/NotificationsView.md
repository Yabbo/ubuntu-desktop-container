# NotificationsView

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**created_at** | **datetime** | Creation timestamp | [optional] 
**updated_at** | **datetime** | Update timestamp | [optional] 
**notification_id** | **int** |  | [optional] 
**tenant_id** | **int** |  | [optional] 
**sensor_id** | **int** |  | [optional] 
**type_id** | **int** |  | [optional] 
**category_id** | **int** |  | [optional] 
**severity_id** | **int** |  | [optional] 
**tenant_name** | **str** |  | [optional] 
**sensor_name** | **str** |  | [optional] 
**type_name** | **str** |  | [optional] 
**category_name** | **str** |  | [optional] 
**severity_name** | **str** |  | [optional] 
**tenant_description** | **str** |  | [optional] 
**sensor_description** | **str** |  | [optional] 
**type_description** | **str** |  | [optional] 
**category_description** | **str** |  | [optional] 
**severity_description** | **str** |  | [optional] 
**user_id** | **int** |  | [optional] 
**username** | **str** |  | [optional] 
**acknowledged** | **bool** |  | [optional] 
**suppressed** | **bool** |  | [optional] 
**notification_permission_id** | **int** |  | [optional] 
**display_text** | **str** |  | [optional] 
**message** | **str** |  | [optional] 
**assigned** | **str** |  | [optional] 
**labels** | **list[str]** |  | [optional] 
**status** | **str** |  | [optional] 
**data** | [**NotificationMetadata**](NotificationMetadata.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


