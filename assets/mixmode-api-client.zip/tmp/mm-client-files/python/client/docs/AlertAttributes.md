# AlertAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entity** | **str** |  | 
**entity_type** | **str** |  | 
**entity_enrichment_labels** | **list[str]** |  | [optional] 
**entity_enrichment_severity** | **int** | The asset severity score assigned to items that match this pattern | [optional] 
**external_geo** | **list[str]** |  | [optional] 
**protocols** | **list[str]** |  | [optional] 
**external_entities** | **list[str]** |  | [optional] 
**epoch** | **datetime** | The beginning of the time aggregation interval. | [optional] 
**epoch_first_seen** | **datetime** | Time at which this alert was first observed. | 
**epoch_last_seen** | **datetime** | Time at which this alert was last observed. | 
**severity** | **int** | The severity for this alert. | [optional] 
**risk_score** | **int** | The measure of risk for this alert. | 
**count** | **int** | Number of times this alert was observed. | 
**status** | **str** | Status of alert. | [default to 'open']
**data** | **object** | Data for the Alert. | [optional] 
**correlated_indicator_count** | **int** | Number of other indicators that are correlated to this alert. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


