# AuditLog

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Unique Identifier representing a document | 
**created_at** | **datetime** | Creation timestamp | [optional] 
**updated_at** | **datetime** | Update timestamp | [optional] 
**table** | **str** |  | [optional] 
**rowid** | **str** |  | [optional] 
**username** | **str** |  | [optional] 
**attribute** | **str** |  | [optional] 
**before** | **str** |  | [optional] 
**after** | **str** |  | [optional] 
**comment** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


